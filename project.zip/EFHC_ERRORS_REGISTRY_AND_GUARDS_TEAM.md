# EFHC Bot — Реестр проявившихся ошибок CI/pytest и предохранителей (SSOT-команда)

Дата обновления: 2026-02-26

Назначение: общий командный документ. Содержит **только классы ошибок, которые
фактически проявлялись в реальных прогонах CI/pytest**, и предохранители,
которые не дают им возвращаться.

---

## 0) Правило пользования документом

- Каждая запись в реестре должна иметь подтверждение: `logs_*.zip` / CI-run.
- Фиксы выполняются **минимально** и **канонично**, без изменения бизнес-логики,
  если это не требуется для устранения падения.
- Предохранители (guards) должны быть автоматическими и воспроизводимыми.

---
---

## A. Ошибки CI-профиля/раннера (workflow), не связанные с бизнес-логикой

### A1. `pytest: command not found` (не установлен pytest в CI)
**Симптом:** `/bin/sh: pytest: command not found` (exit code 127).  
**Причина:** pytest не установлен в окружении workflow.  
**Предохранитель (MUST):**
- В workflow гарантированно устанавливать `pytest` (и плагины) после зависимостей проекта:
  - `pip install -U pytest pytest-asyncio`

### A2. Pytest exit code 5 (тесты «не найдены» из-за неверной рабочей директории)
**Симптом:** `pytest` завершается с code 5 (0 tests collected).  
**Причина:** запуск pytest не из корня проекта, где лежит `tests/`.  
**Предохранитель (MUST):**
- Запускать `pytest -q` из корня проекта (где `tests/`).
- `PYTHONPATH` должен включать корень проекта, если импорты вида `backend.app...` используются в тестах.

### A3. Недостающие runtime/test зависимости в CI (PyJWT / pytest-asyncio / aiosqlite)
**Симптомы:**
- `ModuleNotFoundError: No module named 'jwt'` (нужен пакет `PyJWT`)
- `PytestUnknownMarkWarning: Unknown pytest.mark.asyncio` (нужен `pytest-asyncio`)
- `ModuleNotFoundError: No module named 'aiosqlite'`
**Предохранитель (MUST):**
- В CI ставить явный «стек тестов» (минимум): `pytest`, `pytest-asyncio`, `PyJWT`, `aiosqlite`,
  либо включить их в `backend/requirements.txt` как обязательные зависимости тестов.


## B. Ошибки A2 (Frontend build) и правило про lockfile

### B1. `package-lock.json` с internal mirror ломает `npm ci`
**Симптом (CI/pytest):** `npm ci` падает (401/timeout) из-за `resolved` на internal/artifactory/mirror
(например, `applied-caas-gateway...`).  
**Предохранитель (MUST):**
- Для A2.2 `package-lock.json` **должен** содержать `resolved` только на `https://registry.npmjs.org/...`.
- Lockfile пересоздаётся в среде, где registry контролируется (CI/локально):
  - `npm config set registry https://registry.npmjs.org/`
  - `rm -f package-lock.json && rm -rf node_modules`
  - `npm install @tonconnect/ui-react@2.4.0 --save-exact`
  - `npm ci && npm run build`
- Перед публикацией: grep-guard на запрет internal mirrors в `frontend/package-lock.json`.

### B2. Запрет на vendor/file:-подмены и отключение проверок ради сборки
**Симптом:** сборка «проходит» за счёт подмены источника зависимости или обхода quality-checks.  
**Предохранитель (MUST NOT):**
- Запрещены `file:` зависимости, `frontend/vendor/*` как подмена npm-пакета,
и отключение typecheck/eslint для прохождения сборки.

---

## C. Ошибки импортов/экспортов (pytest падает на collection)

### C1. Несуществующий импорт AdminService
**Симптом:** `ModuleNotFoundError: backend.app.services.admin_service`
из `backend/app/services/__init__.py`.  
**Предохранитель (MUST):**
- Экспорт `AdminService` должен идти из каноничного фасада (например, `admin.admin_facade`),
и путь должен соответствовать реальным файлам.

### C2. Фасад импортирует символы, которых нет (AdminLotteriesService / LotteriestatusSummary)
**Симптом:** `ImportError: cannot import name ...` из `admin_lotteries_service.py`.  
**Предохранитель (MUST):**
- В сервисе должны существовать ожидаемые фасадом имена (через алиасы-экспорты,
  без смены поведения).
- `__all__` должен отражать реальные публичные экспорты.

### C3. Pagination отсутствует там, где её ожидают (`admin_logging.py`)
**Симптом:** `ImportError: cannot import name 'Pagination' ... admin_logging`.  
**Предохранитель (MUST):**
- Если фасад импортирует `Pagination` — он обязан существовать и экспортироваться.

---

### C4. Ожидаемый экспорт `services` из `backend.app` отсутствует
**Симптом:** `ImportError: cannot import name 'services' from 'backend.app'`
при `from backend.app import services`.  
**Предохранитель (MUST):**
- В `backend/app/__init__.py` должен существовать экспорт `services`
  (желательно ленивый через `__getattr__`), чтобы импорт не тянул тяжёлые зависимости на import-time.

### C5. Фасад импортирует символы, которых нет в `admin_bank_service.py` (AdminBankService/*DTO/*Request)
**Симптом:** `ImportError: cannot import name 'AdminBankService' ... admin_bank_service` (и связанные DTO/Request).  
**Предохранитель (MUST):**
- `admin_bank_service.py` должен экспортировать ожидаемые фасадом имена
  (через алиасы на существующие классы, без изменения поведения) и поддерживать `__all__`.


## D. Ошибки конфигурации/Settings

### D1. Отсутствует `parsed_ref_bonus_thresholds`
**Симптом:** `AttributeError: Settings has no attribute parsed_ref_bonus_thresholds`.  
**Предохранитель (MUST):**
- Любые методы, которые вызываются сервисами, должны быть частью Settings SSOT
и покрываться тестом, который импортирует сервис без выполнения бизнес-логики.

---

## E. База/SQLite vs Postgres (массовые падения тестов)

### E1. SQLite не поддерживает `FOR UPDATE` / `SKIP LOCKED`
**Симптом:** `sqlite3.OperationalError: near "FOR": syntax error`.  
**Предохранитель (MUST):**
- Если CI workflow гоняет SQLite, код в ветках тестов должен избегать
Postgres-only конструкций или иметь sqlite-safe ветвление.
- Либо CI должен быть явно Postgres-only (тогда sqlite smoke тесты отключаются канонично).
Важно: это должно быть зафиксировано как единый канон CI-профиля.

### E2. SQLite не знает `now()`, Postgres cast `::numeric`, и некоторые CTE-вставки
**Симптомы:**
- `no such function: now`
- `unrecognized token: ":"` (из-за `::numeric`)
- `near "INSERT": syntax error` в CTE-INSERT.
**Предохранитель (MUST):**
- Использовать параметризованный `utcnow()` на уровне Python, а не `now()` в SQL.
- Избегать `::numeric` в sqlite-профиле.
- Не использовать Postgres-only SQL-шаблоны в sqlite тестовом профиле.

---

## F. Ошибки валидации кошельков (TON)

### F1. Некорректная эвристика валидатора (например, запрет символа) ломает валидные адреса
**Симптом:** `InvalidWalletAddress: INVALID_WALLET_ADDRESS` для валидных TON-адресов.  
**Предохранитель (MUST):**
- Валидатор должен проверять формат TON-адреса корректным способом (тон-формат),
а не через запрет отдельных символов.

---

## G. Ошибки типов времени (Panels)

### G1. Сравнение `str` и `datetime`

### G2. В панелях начинается транзакция поверх уже начатой Session
**Симптом:** `PanelPurchaseError: A transaction is already begun on this Session.`
в тестах панелей.  
**Предохранитель (MUST):**
- Сервис панелей не должен открывать вложенную транзакцию поверх уже открытой.
- Использовать единый шаблон: либо сервис управляет транзакцией, либо вызывающий код,
  но не оба одновременно (зафиксировать в SSOT).



**Симптом:** `TypeError: '>' not supported between instances of 'str' and 'datetime'`.  
**Предохранитель (MUST):**
- Время в сервисах должно быть tz-aware UTC datetime (через `utcnow()`),
а входные строки времени должны парситься в datetime до сравнений.

---

## H. Миграции

### H1. Smoke-тест миграций падает на `NoneType`
**Симптом:** `TypeError: expected string or bytes-like object, got 'NoneType'`.  
**Предохранитель (MUST):**
- Тестовый режим миграций должен иметь чётко определённый источник DB URL
(или sqlite URL), и код не должен пытаться regex/parse по `None`.


### H2. SQLite падает на DDL с `SCHEMA` (Postgres-only)
**Симптом:** `sqlite3.OperationalError: near "SCHEMA": syntax error`
в smoke-тесте миграций на sqlite.  
**Предохранитель (MUST):**
- Либо CI-профиль миграций для sqlite должен использовать sqlite-safe DDL,
  либо smoke-тест миграций должен быть явно Postgres-only (зафиксировать в каноне CI).


---

## I. Канон запретов (grep/guard)

### I1. Запрещённые подстроки должны ловиться guard’ом
**Симптом:** сборка падает на repo-wide guards, либо запреты “проскальзывают”.  
**Предохранитель (MUST):**
- Repo-wide guard на banned substrings/identifiers обязателен.
- Любая правка должна проходить guard до запуска CI.

---


---

### I2. Line-length guard (72) ломает CI при одной длинной строке
**Симптом:** падение архитектурного теста/guard на строках длиной > 72 (пример: `line too long`).  
**Предохранитель (MUST):**
- Любые строки > 72 символов переносить (без изменения логики).
- Guard должен указывать файл/строку, а фиксы не должны использовать `(x as any)` ради «короткости».


## J. Concurrency / идемпотентность (реальные падения)

### J1. UNIQUE на `idempotency_key` в логах переводов (гонка)
**Симптом:** `sqlite UNIQUE constraint failed: efhc_transfers_log.idempotency_key`
в concurrency-тестах (два параллельных запроса пытаются вставить один и тот же ключ).  
**Предохранитель (MUST):**
- Идемпотентные операции должны обрабатывать повтор как replay без падения:
  - атомарная вставка/обновление по `idempotency_key` (UPSERT / INSERT OR IGNORE + SELECT),
  - обязательный аудит replay,
  - тест на конкурентный двойной вызов, который допускает ровно один “первичный” успех.

### J2. Инварианты обмена/вывода ломаются при конкуренции
**Симптомы:** `assert 0 == 1` (ожидали 1 успешную операцию), расхождение балансов.  
**Предохранитель (MUST):**
- Транзакционные операции exchange/withdraw должны быть атомарны и сериализуемы
  в выбранном CI-профиле (sqlite/postgres), а логика блокировок должна
  иметь sqlite-safe ветвление или единый Postgres-only профиль.

---

## K. Pytest warnings / unraisable exceptions превращаются в FAIL

### K1. `ExceptionGroup: unraisable exception warnings`
**Симптом:** тест падает из-за `ExceptionGroup: multiple unraisable exception warnings`
(обычно неосвобождённые ресурсы/соединения, исключения в `__del__`).  
**Предохранитель (MUST):**
- Все соединения/сессии/клиенты должны закрываться явным образом (context manager / finally).
- В тестах запрещать “тихие” утечки ресурсов: pytest должен оставаться зелёным
  при включённых warning-as-error режимах.

### K2. Pydantic deprecated warnings подняты до FAIL
**Симптом:** падения только из-за `pydantic.warnings.PydanticDeprecatedSince20`
(например, `GenericModel` → `BaseModel`).  
**Предохранитель (MUST):**
- Устранить использование `pydantic.generics.GenericModel` в пользу `BaseModel`
  (или обновить типы/модели до Pydantic v2-совместимого API).
- Не “глушить” warnings глобально; исправлять источник предупреждения.


## Приложение: подтверждённый свежий пример (последний лог)
`logs_58693507222.zip`: подтверждает классы E1/E2 + J1/J2 + K1/K2 + H2 + G2.


## Приложение: подтверждённый свежий пример (новый лог)
`logs_58695322208.zip`:

### P1 — SQLite несовместимость SQL в payment_intents_service
**Симптомы:**
- `sqlite3.OperationalError: unrecognized token: ":"` из-за `::numeric`
- `sqlite3.OperationalError: near "INSERT": syntax error` из-за data-modifying CTE
  (`WITH ... INSERT ... ON CONFLICT ... RETURNING`) в SQLite.

**Фикс (DONE):**
- Для SQLite убрать `::numeric` (использовать выражение без кастов).
- Для SQLite заменить CTE+RETURNING на схему `INSERT OR IGNORE` + `SELECT`.

### W1 — Неверная валидация TON адреса (ложный запрет букв E/e)
**Симптом:**
- `InvalidWalletAddress: INVALID_WALLET_ADDRESS` на валидном адресе, содержащем `E`.

**Фикс (DONE):**
- Удалить запрет на наличие `E/e` в строке адреса.
  Адрес TON — base64url, буквы допустимы.

### P2 — PydanticDeprecatedSince20 (GenericModel)
**Симптом:**
- тесты падают только на `pydantic.warnings.PydanticDeprecatedSince20`
  из-за `pydantic.generics.GenericModel`.

**Фикс (DONE):**
- `CursorPage(GenericModel, Generic[T])` → `CursorPage(BaseModel, Generic[T])`
  и убрать импорт `GenericModel`.


## CANON: CI DB PROFILE

**MUST:** CI DB profile = Postgres-only.

**MUST NOT:** SQLite in CI (tests/workflow) is forbidden.
