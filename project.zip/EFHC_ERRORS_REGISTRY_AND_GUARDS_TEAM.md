# EFHC Bot — Реестр проявившихся ошибок CI/pytest и предохранителей (SSOT-команда)

Дата обновления: 2026-02-26

Назначение: общий командный документ. Содержит **только классы ошибок, которые
фактически проявлялись в реальных прогонах CI/pytest**, и предохранители,
которые не дают им возвращаться.

---

## 0) Правило пользования документом

- Логи записываются 1:1 (как есть): excerpt из CI/traceback
  не редактируются и могут содержать любые строки.
- Каждая запись в реестре должна иметь подтверждение: `logs_*.zip` / CI-run.
- Фиксы выполняются **минимально** и **канонично**, без изменения бизнес-логики,
  если это не требуется для устранения падения.
- Предохранители (guards) должны быть автоматическими и воспроизводимыми.

---

## AA. Локальные падения (аудит ZIP в чате)

Примечание: эти записи подтверждены выводом команд в этом
чате (pytest/npm). При появлении соответствующих падений в
GitHub Actions, дополнить ссылкой на `logs_*.zip`.

### AA1. `pytest` падал на правиле `MAX_LEN=72`

**Симптом (pytest):**

```
FAILED tests/architecture/test_max_line_length_72.py
backend/app/core/config_core.py:128: L=84 > 72
```

**Причина:** строка описания `Field(... description=...)` длиннее 72.

**Фикс:** перенос строки через конкатенацию строк в `description=(...)`.

### AA2. `npm run build` падал на TypeScript типах

**Симптом (Next build):**

```
Type error: Property 'items' does not exist on type '{}'.
./src/components/DepositModal.tsx:49:27
Type error: Property 'wallets' does not exist on type '{}'.
./src/components/ProfileModal.tsx:98:25
```

**Причина:** вызовы `apiRequest()` без generic-типа приводили к
`{}` и ломали доступ к полям ответа.

**Фикс:** добавить типы ответов и вызывать
`apiRequest<...>(...)`.

### AA3. `npm run build` падал на несовпадении props

**Симптом (Next build):**

```
Property 'hint' does not exist on type ...
./src/pages/shop.tsx:307:17
```

**Фикс:** заменить `hint=` на каноничное `detail=`.

---
---

## A. Ошибки CI-профиля/раннера (workflow), не связанные с бизнес-логикой

### A1. `pytest: command not found` (не установлен pytest в CI)
**Симптом:** `/bin/sh: pytest: command not found` (exit code 127).  
**Причина:** pytest не установлен в окружении workflow.  
**Предохранитель (MUST):**
- В workflow гарантированно устанавливать `pytest` (и плагины) после зависимостей проекта:
  - `pip install -U pytest pytest-asyncio`

### A2. Pytest exit code 5 (тесты «не найдены» из-за неверной рабочей директории)
**Симптом:** `pytest` завершается с code 5 (0 tests collected).  
**Причина:** запуск pytest не из корня проекта, где лежит `tests/`.  
**Предохранитель (MUST):**
- Запускать `pytest -q` из корня проекта (где `tests/`).
- `PYTHONPATH` должен включать корень проекта, если импорты вида `backend.app...` используются в тестах.

### A3. Недостающие runtime/test зависимости в CI (PyJWT / pytest-asyncio / aiosqlite)
**Симптомы:**
- `ModuleNotFoundError: No module named 'jwt'` (нужен пакет `PyJWT`)
- `PytestUnknownMarkWarning: Unknown pytest.mark.asyncio` (нужен `pytest-asyncio`)
- `ModuleNotFoundError: No module named 'aiosqlite'`
**Предохранитель (MUST):**
- В CI ставить явный «стек тестов» (минимум): `pytest`, `pytest-asyncio`, `PyJWT`, `aiosqlite`,
  либо включить их в `backend/requirements.txt` как обязательные зависимости тестов.


## B. Ошибки A2 (Frontend build) и правило про lockfile

### B1. `package-lock.json` с internal mirror ломает `npm ci`
**Симптом (CI/pytest):** `npm ci` падает (401/timeout) из-за `resolved` на internal/artifactory/mirror
(например, `applied-caas-gateway...`).  
**Предохранитель (MUST):**
- Для A2.2 `package-lock.json` **должен** содержать `resolved` только на `https://registry.npmjs.org/...`.
- Lockfile пересоздаётся в среде, где registry контролируется (CI/локально):
  - `npm config set registry https://registry.npmjs.org/`
  - `rm -f package-lock.json && rm -rf node_modules`
  - `npm install @tonconnect/ui-react@2.4.0 --save-exact`
  - `npm ci && npm run build`
- Перед публикацией: grep-guard на запрет internal mirrors в `frontend/package-lock.json`.

### B2. Запрет на vendor/file:-подмены и отключение проверок ради сборки
**Симптом:** сборка «проходит» за счёт подмены источника зависимости или обхода quality-checks.  
**Предохранитель (MUST NOT):**
- Запрещены `file:` зависимости, `frontend/vendor/*` как подмена npm-пакета,
и отключение typecheck/eslint для прохождения сборки.

---

## C. Ошибки импортов/экспортов (pytest падает на collection)

### C1. Несуществующий импорт AdminService
**Симптом:** `ModuleNotFoundError: backend.app.services.admin_service`
из `backend/app/services/__init__.py`.  
**Предохранитель (MUST):**
- Экспорт `AdminService` должен идти из каноничного фасада (например, `admin.admin_facade`),
и путь должен соответствовать реальным файлам.

### C2. Фасад импортирует символы, которых нет (AdminLotteriesService / LotteriestatusSummary)
**Симптом:** `ImportError: cannot import name ...` из `admin_lotteries_service.py`.  
**Предохранитель (MUST):**
- В сервисе должны существовать ожидаемые фасадом имена (через алиасы-экспорты,
  без смены поведения).
- `__all__` должен отражать реальные публичные экспорты.

### C3. Pagination отсутствует там, где её ожидают (`admin_logging.py`)
**Симптом:** `ImportError: cannot import name 'Pagination' ... admin_logging`.  
**Предохранитель (MUST):**
- Если фасад импортирует `Pagination` — он обязан существовать и экспортироваться.

---

## AE. CI падение: Alembic не может импортировать `backend.*` при запуске из каталога `backend/`

**Симптом (GitHub Actions, alembic upgrade head):**

```
ModuleNotFoundError: No module named 'backend'
.../extracted/backend/migrations/versions/0001_init.py
```

**Причина:** workflow запускает Alembic из `extracted/backend`. В таком режиме
импорт `backend.migrations...` не работает, потому что `backend` перестаёт быть
пакетом верхнего уровня.

**Фикс:** в миграциях использовать импорт без префикса `backend.`:
`migrations.lib.safe` вместо `backend.migrations.lib.safe`.

**Excerpt из CI (сокращено):**

```
File ".../extracted/backend/migrations/versions/0001_init.py", line 25, in <module>
  from backend.migrations.lib.safe import (
ModuleNotFoundError: No module named 'backend'
```

---

### C4. Ожидаемый экспорт `services` из `backend.app` отсутствует
**Симптом:** `ImportError: cannot import name 'services' from 'backend.app'`
при `from backend.app import services`.  
**Предохранитель (MUST):**
- В `backend/app/__init__.py` должен существовать экспорт `services`
  (желательно ленивый через `__getattr__`), чтобы импорт не тянул тяжёлые зависимости на import-time.

### C5. Фасад импортирует символы, которых нет в `admin_bank_service.py` (AdminBankService/*DTO/*Request)
**Симптом:** `ImportError: cannot import name 'AdminBankService' ... admin_bank_service` (и связанные DTO/Request).  
**Предохранитель (MUST):**
- `admin_bank_service.py` должен экспортировать ожидаемые фасадом имена
  (через алиасы на существующие классы, без изменения поведения) и поддерживать `__all__`.


## D. Ошибки конфигурации/Settings

### D1. Отсутствует `parsed_ref_bonus_thresholds`
**Симптом:** `AttributeError: Settings has no attribute parsed_ref_bonus_thresholds`.  
**Предохранитель (MUST):**
- Любые методы, которые вызываются сервисами, должны быть частью Settings SSOT
и покрываться тестом, который импортирует сервис без выполнения бизнес-логики.

---

## E. База/SQLite vs Postgres (массовые падения тестов)

### E1. SQLite не поддерживает `FOR UPDATE` / `SKIP LOCKED`
**Симптом:** `sqlite3.OperationalError: near "FOR": syntax error`.  
**Предохранитель (MUST):**
- Если CI workflow гоняет SQLite, код в ветках тестов должен избегать
Postgres-only конструкций или иметь sqlite-safe ветвление.
- Либо CI должен быть явно Postgres-only (тогда sqlite smoke тесты отключаются канонично).
Важно: это должно быть зафиксировано как единый канон CI-профиля.

### E2. SQLite не знает `now()`, Postgres cast `::numeric`, и некоторые CTE-вставки
**Симптомы:**
- `no such function: now`
- `unrecognized token: ":"` (из-за `::numeric`)
- `near "INSERT": syntax error` в CTE-INSERT.
**Предохранитель (MUST):**
- Использовать параметризованный `utcnow()` на уровне Python, а не `now()` в SQL.
- Избегать `::numeric` в sqlite-профиле.
- Не использовать Postgres-only SQL-шаблоны в sqlite тестовом профиле.

---

## F. Ошибки валидации кошельков (TON)

### F1. Некорректная эвристика валидатора (например, запрет символа) ломает валидные адреса
**Симптом:** `InvalidWalletAddress: INVALID_WALLET_ADDRESS` для валидных TON-адресов.  
**Предохранитель (MUST):**
- Валидатор должен проверять формат TON-адреса корректным способом (тон-формат),
а не через запрет отдельных символов.

---

## G. Ошибки типов времени (Panels)

### G1. Сравнение `str` и `datetime`

### G2. В панелях начинается транзакция поверх уже начатой Session
**Симптом:** `PanelPurchaseError: A transaction is already begun on this Session.`
в тестах панелей.  
**Предохранитель (MUST):**
- Сервис панелей не должен открывать вложенную транзакцию поверх уже открытой.
- Использовать единый шаблон: либо сервис управляет транзакцией, либо вызывающий код,
  но не оба одновременно (зафиксировать в SSOT).



**Симптом:** `TypeError: '>' not supported between instances of 'str' and 'datetime'`.  
**Предохранитель (MUST):**
- Время в сервисах должно быть tz-aware UTC datetime (через `utcnow()`),
а входные строки времени должны парситься в datetime до сравнений.

---

## H. Миграции

### H1. Smoke-тест миграций падает на `NoneType`
**Симптом:** `TypeError: expected string or bytes-like object, got 'NoneType'`.  
**Предохранитель (MUST):**
- Тестовый режим миграций должен иметь чётко определённый источник DB URL
(или sqlite URL), и код не должен пытаться regex/parse по `None`.


### H2. SQLite падает на DDL с `SCHEMA` (Postgres-only)
**Симптом:** `sqlite3.OperationalError: near "SCHEMA": syntax error`
в smoke-тесте миграций на sqlite.  
**Предохранитель (MUST):**
- Либо CI-профиль миграций для sqlite должен использовать sqlite-safe DDL,
  либо smoke-тест миграций должен быть явно Postgres-only (зафиксировать в каноне CI).


---

## I. Канон запретов (grep/guard)

### I1. Запрещённые подстроки должны ловиться guard’ом
**Симптом:** сборка падает на repo-wide guards, либо запреты “проскальзывают”.  
**Предохранитель (MUST):**
- Repo-wide guard на banned substrings/identifiers обязателен.
- Любая правка должна проходить guard до запуска CI.

---


---

### I2. Line-length guard (72) ломает CI при одной длинной строке
**Симптом:** падение архитектурного теста/guard на строках длиной > 72 (пример: `line too long`).  
**Предохранитель (MUST):**
- Любые строки > 72 символов переносить (без изменения логики).
- Guard должен указывать файл/строку, а фиксы не должны использовать `(x as any)` ради «короткости».


## J. Concurrency / идемпотентность (реальные падения)

### J1. UNIQUE на `idempotency_key` в логах переводов (гонка)
**Симптом:** `sqlite UNIQUE constraint failed: efhc_transfers_log.idempotency_key`
в concurrency-тестах (два параллельных запроса пытаются вставить один и тот же ключ).  
**Предохранитель (MUST):**
- Идемпотентные операции должны обрабатывать повтор как replay без падения:
  - атомарная вставка/обновление по `idempotency_key` (UPSERT / INSERT OR IGNORE + SELECT),
  - обязательный аудит replay,
  - тест на конкурентный двойной вызов, который допускает ровно один “первичный” успех.

### J2. Инварианты обмена/вывода ломаются при конкуренции
**Симптомы:** `assert 0 == 1` (ожидали 1 успешную операцию), расхождение балансов.  
**Предохранитель (MUST):**
- Транзакционные операции exchange/withdraw должны быть атомарны и сериализуемы
  в выбранном CI-профиле (sqlite/postgres), а логика блокировок должна
  иметь sqlite-safe ветвление или единый Postgres-only профиль.

---

## K. Pytest warnings / unraisable exceptions превращаются в FAIL

### K1. `ExceptionGroup: unraisable exception warnings`
**Симптом:** тест падает из-за `ExceptionGroup: multiple unraisable exception warnings`
(обычно неосвобождённые ресурсы/соединения, исключения в `__del__`).  
**Предохранитель (MUST):**
- Все соединения/сессии/клиенты должны закрываться явным образом (context manager / finally).
- В тестах запрещать “тихие” утечки ресурсов: pytest должен оставаться зелёным
  при включённых warning-as-error режимах.

### K2. Pydantic deprecated warnings подняты до FAIL
**Симптом:** падения только из-за `pydantic.warnings.PydanticDeprecatedSince20`
(например, `GenericModel` → `BaseModel`).  
**Предохранитель (MUST):**
- Устранить использование `pydantic.generics.GenericModel` в пользу `BaseModel`
  (или обновить типы/модели до Pydantic v2-совместимого API).
- Не “глушить” warnings глобально; исправлять источник предупреждения.


## Приложение: подтверждённый свежий пример (последний лог)
`logs_58693507222.zip`: подтверждает классы E1/E2 + J1/J2 + K1/K2 + H2 + G2.


## Приложение: подтверждённый свежий пример (новый лог)
`logs_58695322208.zip`:

### P1 — SQLite несовместимость SQL в payment_intents_service
**Симптомы:**
- `sqlite3.OperationalError: unrecognized token: ":"` из-за `::numeric`
- `sqlite3.OperationalError: near "INSERT": syntax error` из-за data-modifying CTE
  (`WITH ... INSERT ... ON CONFLICT ... RETURNING`) в SQLite.

**Фикс (DONE):**
- Для SQLite убрать `::numeric` (использовать выражение без кастов).
- Для SQLite заменить CTE+RETURNING на схему `INSERT OR IGNORE` + `SELECT`.

### W1 — Неверная валидация TON адреса (ложный запрет букв E/e)
**Симптом:**
- `InvalidWalletAddress: INVALID_WALLET_ADDRESS` на валидном адресе, содержащем `E`.

**Фикс (DONE):**
- Удалить запрет на наличие `E/e` в строке адреса.
  Адрес TON — base64url, буквы допустимы.

### P2 — PydanticDeprecatedSince20 (GenericModel)
**Симптом:**
- тесты падают только на `pydantic.warnings.PydanticDeprecatedSince20`
  из-за `pydantic.generics.GenericModel`.

**Фикс (DONE):**
- `CursorPage(GenericModel, Generic[T])` → `CursorPage(BaseModel, Generic[T])`
  и убрать импорт `GenericModel`.


## CANON: CI DB PROFILE

**MUST:** CI DB profile = Postgres-only.

**MUST NOT:** SQLite in CI (tests/workflow) is forbidden.


---

## P-POSTGRES-ONLY / Alembic SSL mode mismatch (CI local Postgres без SSL)

**Run:** `logs_58700796381.zip`  
**Симптом (excerpt):**
```
psycopg.OperationalError: connection failed: connection to server at "127.0.0.1", port 5432 failed:
server does not support SSL, but SSL was required
```
**Root cause:** `backend/migrations/env.py` принудительно добавлял `sslmode=require` для любого non-sqlite URL, даже для `localhost`.  
**Fix:** добавлять `sslmode=require` только если хост не `localhost/127.0.0.1/::1` и параметр ещё не задан.

---

## T-PYTEST / IndentationError в helper `_init_sqlite_schema` (после перехода на Postgres-only)

**Run:** `logs_58700796378.zip`  
**Симптом (excerpt):**
```
File ".../tests/test_concurrency_exchange_all.py", line 53
  @event.listens_for(engine.sync_engine, "connect")
IndentationError: unexpected indent
```
**Root cause:** в нескольких тестах блок SQLite-init остался “обрубленным”: после `pytest.fail(...)` шёл неиндентированный код.  
**Fix:** для Postgres-only канона заменить `_init_sqlite_schema(...)` на 3 строки: `pytest.fail(...)` + `return`, без дальнейшего кода.


---

## CI Failure: logs_58702480076 (compileall)

**Symptom (excerpt):**

```text
2026-02-26T17:32:23.3594249Z *** Error compiling 'extracted/backend/migrations/env.py'...
2026-02-26T17:32:23.3595407Z Sorry: IndentationError: expected an indented block after 'if' statement on line 84 (env.py, line 85)
2026-02-26T17:32:23.3662990Z ##[error]Process completed with exit code 1.
```

**Root cause:** `backend/migrations/env.py` — broken indentation and duplicate assignment in sslmode block.

**Fix:** normalize sslmode-injection block for localhost/non-localhost and remove duplicate `if`/bad assignment.

**Status:** fixed in patch13.

---

## CI / flake8: массовые ошибки lint (F821/F722/F811) — logs_58704053518.zip

**Symptom (excerpt):**
```
backend/app/bot/handlers/balance_handlers.py:61:19: F821 undefined name 'sender'
backend/app/bot/handlers/ranks_handlers.py:102:15: F821 undefined name 'tg_id'
backend/app/routes/admin_routes.py:73:17: F722 syntax error in forward annotation '^(bank_to_user|user_to_bank)$'
backend/app/bot/states.py:586:5: F811 redefinition of unused '_set' from line 578
```

**Root cause:**
- handlers использовали несуществующие переменные (`sender`, `tg_id`, `t`),
- `admin_routes.py` использовал `constr(...pattern=...)` под `from __future__ import annotations`,
  что ломало парсер forward-annotations в flake8,
- в `states.py` был дублирован метод `_set`,
- ряд модулей имели реальные опечатки/недостающие импорты.

**Fix (patch15):**
- handlers: ввели `sender = message.from_user`, `tg_id = int(message.from_user.id)`, импортировали `t`,
- `admin_routes.py`: заменили `constr(...)` на `Field(..., pattern=...)`,
- `states.py`: удалили дублирование `_set`, восстановили fallback в `_get`,
- исправлены реальные опечатки/импорты (res_u→res, bank_id init, Request imports, timezone, datetime, и т.д.),
- добавлен `.flake8` с каноничным смысловым профилем:
  `select=E9,F7,F82` + `extend-ignore=F822`.

**Status:** fixed in patch15.



## AB. CI падение: отсутствует `project.zip` в корне репозитория

**Симптом (GitHub Actions):** шаг распаковки падает до любых guard/pytest/npm.

**Excerpt (logs_58712857957.zip / `canon/7_Unzip project.zip.txt`):**
```
2026-02-26T19:03:51.5530823Z   LD_LIBRARY_PATH: /opt/hostedtoolcache/Python/3.11.14/x64/lib
2026-02-26T19:03:51.5531115Z ##[endgroup]
2026-02-26T19:03:51.5603815Z ERROR: project.zip not found in repo root
2026-02-26T19:03:51.5616962Z ##[error]Process completed with exit code 1.
```

**Причина:** в корне репозитория нет файла `project.zip` (часто загружен/закоммичен ZIP с другим именем, например `EFHC_Bot_...zip`, либо файл лежит не в корне).

**Каноничное действие (MUST):**
- в корне репозитория должен лежать **ровно один** архив **с именем** `project.zip` (не папка, не другой путь).

**Предохранитель (рекомендуется):**
- в `.github/workflows/ci.yml` добавить fallback: если `project.zip` отсутствует, попытаться найти `EFHC_Bot_*.zip` и скопировать в `project.zip`, затем продолжать (с явным логом). Это не ослабляет канон, а делает CI самовосстанавливающимся при человеческой ошибке.


## AC — CI FAIL: guard bans false-positive in binary assets (png)

**Дата:** 2026-02-26  
**Симптом (GitHub Actions):** падение шага "Guard grep bans (repo-wide in extracted)" на случайном совпадении `\buid\b` внутри `frontend/public/skins/1.png`.

**Excerpt (CI):**
```
ERROR: forbidden identifiers found:
- \buid\b: ./frontend/public/skins/1.png @ 53039
##[error]Process completed with exit code 1.
```

**Причина:** guard в CI сканировал **все** файлы и декодировал бинарные как текст, поэтому случайные байты в PNG могли совпасть с banned-паттерном.

**Фикс (канон):** в workflow использовать ripgrep с флагом `-I` (ignore binary) и не сканировать бинарные файлы на banned-токены.
**Примечание:** pytest-guard `tests/architecture/test_forbidden_identifiers_repo.py` уже исключает бинарные суффиксы (png/jpg/woff и т.д.) и остаётся источником истины внутри `project.zip`.


### AD) CI FAIL: Canon bans scan обнаружил запрещённую подстроку `tg` + `Id` — 2026-02-26

Источник: `logs_58716260680.zip` → шаг `Canon bans scan (text-only)`.

Excerpt (сокращено):
```
- banned_ids: extracted/frontend/src/lib/admin.ts ... getAdminTg" + "Ids() ...
- banned_ids: extracted/frontend/src/pages/_app.tsx ... isAdminTg" + "Id ... setTg" + "Id ...
- banned_ids: extracted/frontend/src/pages/admin/logs.tsx ... setTg" + "Id ...
- banned_ids: extracted/frontend/src/pages/admin/panels.tsx ... setTg" + "Id ...
```

Fix (в ZIP v147_45):
- Удалены все вхождения подстроки `tg` + `Id` (любой регистр) во фронтенде.
- Переименование на каноничный `tg_id` (snake_case):
  - getAdminTg" + "Ids → get_admin_tg_ids
  - isAdminTg" + "Id → is_admin_tg_id
  - setTg" + "Id → set_tg_id

Проверки локально: repo-wide bans scan (text-only) — PASS.


## AF — CI: Alembic не находит модуль helpers при загрузке ревизии 0001_init — 2026-02-26

Источник: `logs_58718278834.zip` → шаг `Alembic upgrade head (Postgres)`.

Excerpt (сокращено):
```
File ".../extracted/backend/migrations/versions/0001_init.py", line 25, in <module>
  from migrations.lib.safe import (
ModuleNotFoundError: No module named 'migrations'
```

Причина:
- Ревизии Alembic загружаются как отдельные модули, и импорт helpers должен быть устойчивым к текущей рабочей директории.

Fix (в ZIP v147_47):
- В `backend/migrations/versions/0001_init.py` добавлена гарантия, что корень проекта (extracted/) добавлен в `sys.path`.
- Импорты helpers переведены на `backend.migrations.lib.safe` (без зависимостей от cwd).

## AG — 2026-02-26 — CI: Alembic init migration падает на ensure_table_with_basics(schema=...)

**Симптом (GitHub Actions):**
```
TypeError: ensure_table_with_basics() got an unexpected keyword argument 'schema'
```

**Причина:**
`backend/migrations/versions/0001_init.py` вызывает `ensure_table_with_basics(..., schema="efhc_admin")`,
а `backend/migrations/lib/safe.py` не поддерживал параметр `schema` и работал только в текущем search_path.

**Фикс:**
Добавлена schema-aware поддержка в `safe.py`:
- `table_exists/column_exists/index_exists/unique_constraint_exists` принимают `schema`
- `ensure_table/ensure_column/ensure_index/ensure_unique_constraint/ensure_table_with_basics` принимают `schema`
- DDL (`op.create_table/add_column/create_index/create_unique_constraint`) вызывается с `schema=schema`

**Статус:** patched in ZIP v147_48


### AH (2026-02-26) CI / Alembic: ensure_table_with_basics не умеет sa.Index

**Симптом (CI):** `TypeError: cannot unpack non-iterable Index object` в `backend/migrations/lib/safe.py` при обработке `indexes=[sa.Index(...)]` из `0001_init.py`.

**Причина:** helper `ensure_table_with_basics()` ожидал список кортежей `(name, [cols], unique)` и пытался распаковать `sa.Index` как кортеж.

**Фикс:** `ensure_table_with_basics()` теперь принимает и `sa.Index`, нормализует в `(name, cols, unique)` и вызывает `ensure_index()`.
## AC. CI падение: ложное срабатывание bans-guard по бинарному файлу

**Симптом (GitHub Actions):** guard-запреты падают на совпадении токена
в бинарном файле (PNG/шрифт), хотя в коде/доках нарушения нет.

**Excerpt (CI):**
```
ERROR: forbidden identifiers found:
- uid: ./frontend/public/skins/1.png ...
##[error]Process completed with exit code 1.
```

**Root cause:** репо-сканер читает бинарные файлы как текст и ловит
случайные байты.

**Что помогло (Fix that worked):**
- Перевести bans-scan в режим *text-only* (игнорировать бинарники),
  либо не сканировать `frontend/public/**` и иные бинарные каталоги.

**Verification:** после исключения бинарников guard перестаёт падать на PNG.


## AD. CI падение: запрещённые алиасы tgId в frontend

**Симптом (GitHub Actions):** bans-scan падает на подстроке tgId во
фронтенде.

**Root cause:** в `frontend/src/**` были функции/переменные в camelCase
с фрагментом tgId.

**Что помогло (Fix that worked):**
- Переименование на каноничный `tg_id` (snake_case) во фронтенде:
  - `frontend/src/lib/admin.ts`
  - `frontend/src/pages/_app.tsx`
  - `frontend/src/pages/admin/logs.tsx`
  - `frontend/src/pages/admin/panels.tsx`

**Verification:** bans-scan проходит, сборка двигается дальше.


## AE. CI падение: Alembic — ModuleNotFoundError из-за import path

**Симптом (GitHub Actions):** `alembic upgrade head` падает на импорте в
init-миграции.

**Excerpt (CI):**
```
ModuleNotFoundError: No module named 'backend'
```

**Root cause:** Alembic запускается не из того cwd/py-path, а ревизия
импортирует `backend.*`.

**Что помогло (Fix that worked):**
- Сделать ревизию cwd-независимой: добавлять корень проекта в `sys.path`
  перед импортами helper-функций миграций.

**Verification:** Alembic начинает исполнять upgrade(), а не падает на
import.


## AF. CI падение: Alembic — helper не принимает schema=

**Симптом (GitHub Actions):** TypeError в `ensure_table_with_basics()` при
вызове с `schema=...`.

**Root cause:** helper-функции `backend/migrations/lib/safe.py` не имели
параметра `schema`, но миграция вызывала их со schema.

**Что помогло (Fix that worked):**
- Добавить `schema: str | None = None` во все relevant helpers и
  пробрасывать `schema=` в `op.create_table/add_column/create_index/
  create_unique_constraint`.

**Verification:** Alembic проходит место с `schema=` и двигается дальше.


## AG. CI падение: Alembic — cannot unpack Index object

**Симптом (GitHub Actions):** TypeError: cannot unpack non-iterable Index
object в `ensure_table_with_basics()`.

**Root cause:** миграция передавала `indexes=[sa.Index(...)]`, а helper
ожидал список кортежей `(name, cols, unique)`.

**Что помогло (Fix that worked):**
- В `ensure_table_with_basics()` принять оба формата:
  - `sa.Index` → нормализовать в `(ix.name, [cols], ix.unique)`
  - кортежный формат оставить как есть.

**Verification:** Alembic проходит блок indexes и продолжает upgrade().

### [AI] CI: Alembic — script_location указывает на несуществующий путь

**Симптом:** Alembic upgrade head падает с сообщением, что путь scripts folder не найден.

**Причина:** в `backend/alembic.ini` `script_location` был задан как `backend/migrations`, а CI запускает Alembic из каталога `backend/`, поэтому ожидаемый путь становится `backend/backend/migrations`.

**Что помогло (Fix that worked):**
- В `backend/alembic.ini` `script_location` изменён на `migrations` (относительно `backend/`).

**Excerpt (CI, 1:1):**
```
FAILED: Path doesn't exist: backend/migrations.  Please use the 'init' command to create a new scripts folder.
```

### [AJ] CI: Alembic — ValueError unpack uniques (sa.UniqueConstraint)

**Симптом:** Alembic upgrade head падает в ensure_table_with_basics при обработке uniques (ValueError unpack).

**Причина:** init-миграция передала uniques как sa.UniqueConstraint(...), а helper ожидал кортеж (name, cols) и пытался распаковать объект.

**Что помогло (Fix that worked):**
- backend/migrations/lib/safe.py: ensure_table_with_basics теперь принимает uniques как:
  - кортежи ("uq_name", ["col1", ...])
  - sa.UniqueConstraint(...): нормализуем в (uq.name, [col names])

**Excerpt (CI, 1:1):**
```text
ValueError: not enough values to unpack (expected 2, got 0)
```

### [AK] CI: Alembic — UniqueConstraint columns пустые (pending colargs)

**Симптом:** Alembic upgrade head падает в `ensure_table_with_basics()` с исключением:
`RuntimeError: UniqueConstraint for payment_intents resolved to empty columns`.

**Причина:** `sa.UniqueConstraint("col", ...)`, созданный со строковыми именами колонок,
до привязки к `Table` хранит их в `._pending_colargs`, а `uq.columns` остаётся пустым.
В init-миграции мы передаём standalone `UniqueConstraint`, поэтому helper видел пустые колонки.

**Что помогло (Fix that worked):**
- `backend/migrations/lib/safe.py`: при нормализации `sa.UniqueConstraint` сначала читаем
  `uq.columns`, а если там пусто — берём строки из `uq._pending_colargs`.

**Excerpt (CI, 1:1):**
```text
RuntimeError: UniqueConstraint for payment_intents resolved to empty columns
```


### [AL] CI: pytest collection — missing freezegun and backend import path

**Симптом:** pytest прерывается на сборе тестов (8 ошибок коллекции).

**Причина:**
- `freezegun` не установлен (ModuleNotFoundError).
- модуль `backend` не находится при импортах из тестов в CI (ModuleNotFoundError), т.к. sys.path не гарантирует корень проекта.

**Что помогло (Fix that worked):**
- Добавлен `tests/conftest.py`, который добавляет корень проекта в `sys.path`.
- Добавлен `freezegun==1.5.1` в `backend/requirements.txt`.

**Excerpt (CI, 1:1):**
> tests/core/test_core_math_econ.py:23: in <module>
>     from freezegun import freeze_time
> E   ModuleNotFoundError: No module named 'freezegun'
> ...
> E   ModuleNotFoundError: No module named 'backend'
