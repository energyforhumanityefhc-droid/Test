"""
Backend package root.

This file intentionally contains *no* runtime side effects.
It exists to mark the `backend` directory as a Python package.
"""
__all__: list[str] = []
