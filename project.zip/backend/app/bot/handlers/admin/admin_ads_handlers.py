# -*- coding: utf-8 -*-
# backend/app/bot/handlers/admin/admin_ads_handlers.py
# ----------------------------------------------------------------------
# Назначение кода:
# /admin_ads — вход в раздел Admin → Ads в WebApp.
# ----------------------------------------------------------------------

from __future__ import annotations

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from backend.app.bot.keyboards import kb_main_menu
from backend.app.core.config_core import get_settings

router = Router()
settings = get_settings()


def _is_admin(tg_id: int) -> bool:
    """Проверяет tg_id на совпадение с ADMIN_TELEGRAM_ID."""
    admin_tg_id = int(getattr(settings, "ADMIN_TELEGRAM_ID", 0))
    return int(tg_id) == admin_tg_id


@router.message(Command("admin_ads"))
async def handler(message: Message) -> None:
    """Команда /admin_ads — отдаёт навигацию к WebApp."""
    if not message.from_user:
        return

    if not _is_admin(message.from_user.id):
        await message.answer("⛔ Нет доступа.")
        return

    await message.answer(
        "📢 Управление рекламой доступно в WebApp → Admin → Ads.",
        reply_markup=kb_main_menu(),
    )
