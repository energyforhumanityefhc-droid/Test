# -*- coding: utf-8 -*-
# backend/app/bot/handlers/shop_handlers.py
# ======================================================================
# Назначение кода:
# /shop — навигация в магазин WebApp.
# ======================================================================

from __future__ import annotations

from typing import Optional

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.bot.keyboards import kb_main_menu, kb_subscribe

router = Router()


async def _gate_subscribe(
    message: Message,
    required_channel_id: Optional[int],
    is_subscribed: bool,
    required_channel_username: Optional[str],
) -> bool:
    """Проверка подписки на обязательный канал (если он задан).

    Если канал обязателен и подписки нет — отправляет пользователю
    сообщение с кнопкой подписки и возвращает True.

    Инварианты:
    - Повторный вызов не создаёт дублей (идемпотентность по ключам).
    - Денежные значения учитываются с d8 и ROUND_DOWN (если применимо).
    """
    if required_channel_id and not is_subscribed:
        channel = required_channel_username or str(required_channel_id)
        await message.answer(
            t("subscribe.required", channel=channel),
            reply_markup=kb_subscribe(required_channel_username),
        )
        return True
    return False


@router.message(Command("shop"))
async def cmd_shop(
    message: Message,
    db: AsyncSession,  # noqa: F401
    is_subscribed: bool = True,
    required_channel_username: Optional[str] = None,
    required_channel_id: Optional[int] = None,
) -> None:
    """Открывает WebApp Shop (с проверкой подписки, если включена)."""
    if await _gate_subscribe(
        message,
        required_channel_id,
        is_subscribed,
        required_channel_username,
    ):
        return

    await message.answer(
        "🛒 Магазин открывается в WebApp 👇",
        reply_markup=kb_main_menu(
            require_subscribe=bool(required_channel_id),
        ),
    )
