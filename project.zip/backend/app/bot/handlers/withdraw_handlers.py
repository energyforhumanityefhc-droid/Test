# -*- coding: utf-8 -*-
# backend/app/bot/handlers/withdraw_handlers.py
# ----------------------------------------------------------------------
# Назначение кода:
# /withdraw — навигация к выводу EFHC через WebApp.
#
# Канон:
# • Заявка на вывод — денежная операция и делается только через API с
#   Idempotency-Key.
# ----------------------------------------------------------------------

from __future__ import annotations

from typing import Optional

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.bot.keyboards import kb_main_menu, kb_subscribe
from backend.app.bot.texts import t

router = Router()


async def _gate_subscribe(
    message: Message,
    required_channel_id: Optional[int],
    is_subscribed: bool,
    required_channel_username: Optional[str],
) -> bool:
    """Проверяет подписку и показывает кнопку
    подписки при необходимости.

    Инварианты:
    - Повторный вызов не должен создавать дубли (идемпотентность).
    - Денежные значения EFHC учитываются с точностью d8 и ROUND_DOWN.
    - Баланс/банк изменяются только через transactions_service.
    """
    if required_channel_id and not is_subscribed:
        channel = required_channel_username or str(required_channel_id)
        await message.answer(
            t("subscribe.required", channel=channel),
            reply_markup=kb_subscribe(required_channel_username),
        )
        return True
    return False


@router.message(Command("withdraw"))
async def cmd_withdraw(
    message: Message,
    db: AsyncSession,
    is_subscribed: bool = True,
    required_channel_username: Optional[str] = None,
    required_channel_id: Optional[int] = None,
) -> None:
    """Команда /withdraw — переводит пользователя
    в WebApp для вывода."""
    if await _gate_subscribe(
        message,
        required_channel_id,
        is_subscribed,
        required_channel_username,
    ):
        return

    require_subscribe = bool(required_channel_id)
    await message.answer(
        "💸 Вывод оформляется в WebApp 👇",
        reply_markup=kb_main_menu(require_subscribe=require_subscribe),
    )

    _ = db
