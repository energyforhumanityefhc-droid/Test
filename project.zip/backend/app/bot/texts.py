"""UI-тексты Telegram-бота.

Поддержка языков соответствует SUPPORTED_LANGS (см. config_core).
"""

from __future__ import annotations

from typing import Dict

TEXTS: Dict[str, Dict[str, str]] = {
    "ru": {
        "welcome": "Привет, {username}! ⚡",
        "menu": "Главное меню",
        "no_access": "⛔ Нет доступа.",
    },
    "en": {
        "welcome": "Hi, {username}! ⚡",
        "menu": "Main menu",
        "no_access": "⛔ Access denied.",
    },
    "ua": {
        "welcome": "Привіт, {username}! ⚡",
        "menu": "Головне меню",
        "no_access": "⛔ Немає доступу.",
    },
    "de": {
        "welcome": "Hallo, {username}! ⚡",
        "menu": "Hauptmenü",
        "no_access": "⛔ Kein Zugriff.",
    },
    "fr": {
        "welcome": "Salut, {username}! ⚡",
        "menu": "Menu principal",
        "no_access": "⛔ Accès refusé.",
    },
    "es": {
        "welcome": "Hola, {username}! ⚡",
        "menu": "Menú principal",
        "no_access": "⛔ Acceso denegado.",
    },
    "it": {
        "welcome": "Ciao, {username}! ⚡",
        "menu": "Menu principale",
        "no_access": "⛔ Accesso negato.",
    },
    "tr": {
        "welcome": "Merhaba, {username}! ⚡",
        "menu": "Ana menü",
        "no_access": "⛔ Erişim yok.",
    },
    "pl": {
        "welcome": "Cześć, {username}! ⚡",
        "menu": "Menu główne",
        "no_access": "⛔ Brak dostępu.",
    },
    "da": {
        "welcome": "Hej, {username}! ⚡",
        "menu": "Hovedmenu",
        "no_access": "⛔ Ingen adgang.",
    },
}


def t(lang: str, key: str, **fmt: str) -> str:
    """Вернуть локализованный UI-текст (fallback: ru)."""
    d = TEXTS.get(lang) or TEXTS["ru"]
    template = d.get(key) or TEXTS["ru"].get(key) or key
    return template.format(**fmt)

