# -*- coding: utf-8 -*-
# backend/app/crud/transfers_crud.py
# ======================================================================
# Назначение кода:
# Доменные выборки переводов/операций. В каноне EFHC нет P2P, но есть
# логи «банк ↔ пользователь». Этот модуль — тонкий слой чтения логов.
# ======================================================================

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.models.bank_models import BankLedger


async def list_user_ledger(
    db: AsyncSession,
    *,
    tg_id: int,
    limit: int = 200,
) -> list[BankLedger]:
    """Список записей банковского журнала по tg_id (desc)."""

    stmt = (
        select(BankLedger)
        .where(BankLedger.tg_id == tg_id)
        .order_by(BankLedger.id.desc())
        .limit(limit)
    )
    res = await db.execute(stmt)
    return list(res.scalars().all())
