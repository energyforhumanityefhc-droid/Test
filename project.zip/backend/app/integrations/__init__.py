"""Package marker.

Этот файл закрепляет пакетность директории по канону
(см. ARCHITECTURAL_LOCKS.md).
"""


__all__ = []
