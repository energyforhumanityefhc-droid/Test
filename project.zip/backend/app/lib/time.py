# -*- coding: utf-8 -*-
# backend/app/lib/time.py

"""SSOT UTC time helper.

Business logic must use tz-aware UTC time only.
"""

from __future__ import annotations

from datetime import datetime, timezone


def utcnow() -> datetime:
    """Return tz-aware current UTC time."""

    return datetime.now(timezone.utc)
