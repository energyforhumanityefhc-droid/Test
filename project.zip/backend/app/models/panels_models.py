# -*- coding: utf-8 -*-
# backend/app/models/panels_models.py
# ======================================================================
# Назначение кода:
# ORM-модель домена «Панели» EFHC Bot:
# • Panel — панели пользователя в одной таблице.
# • Канон SSOT для Panels опирается на activated_at/expires_at и
#   вычисляет Active/Archive через сравнение server_now_utc
#   с expires_at.
# • Некоторые поля ниже могут быть legacy-совместимостью (не SSOT)
#   и должны постепенно выводиться из использования на уровне сервисов.
#
# Канон/инварианты:
# • Генерация энергии считается только в сервисах (per-sec ставки
# GEN_PER_SEC_BASE_KWH / GEN_PER_SEC_VIP_KWH).
# • Никаких «суточных» полей. Все суммы энергии — Decimal(30,8), без
# отрицательных значений.
# • Архивация панели: is_active=false, archived_at NOT NULL;
#   покупка новой — через банк (в сервисах).
# через банк (в сервисах).
# • Лимит на пользователя: 1000 активных панелей
#   (контроль — в сервисах).
#
# ИИ-защиты:
# • Индексы под курсорную пагинацию (created_at,id) и выборки по
# пользователю/активности/сроку.
# • Поля last_generated_at и generated_kwh — для «догон-начисления» при
# сбоях/перезапусках.
# • meta(JSONB) — безопасное расширение (например, источник покупки,
#   SKU, примечания аудита).
# примечания аудита).
#
# Запреты:
# • Модель НЕ выполняет расчётов/списаний/начислений и не проверяет
#   лимиты — это делает сервис.
# это делает сервис.
# • Никакой автокоррекции балансов пользователя — только чтение и
#   хранение фактов о панелях.
# ======================================================================

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Optional

from sqlalchemy import (
    BigInteger,
    CheckConstraint,
    Index,
    String,
    UniqueConstraint,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB, TIMESTAMP
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.types import Numeric

from backend.app.core.config_core import get_settings
from . import Base  # единый declarative Base проекта

settings = get_settings()
CORE_SCHEMA = settings.DB_SCHEMA_CORE  # например, "efhc_core"


class Panel(Base):
    """
    Панель пользователя (активная или архивная).

    Поля:
      • tg_id            — Telegram ID владельца.
      • is_active          — флаг активности; FALSE ⇒ панель в архиве.
      • created_at         — дата создания (момент покупки).
      • expires_at — дата окончания срока (например, +180 дней).
      • archived_at — дата архивирования (для неактивных панелей).
      • last_generated_at — последний момент, до которого начислена
        энергия «догоном».
      • base_gen_per_sec — ставка генерации, зафиксированная при
        создании (аудитное поле).
      • generated_kwh — накопленная энергия по панели (d8, ≥ 0).
      • title — имя/серия (опционально для UI).
      • meta — расширения (SKU, источник заказа и т.д.).
    """

    __tablename__ = "panels"
    __table_args__ = (
        # Никаких отрицательных энергий/ставок
        CheckConstraint(
            "generated_kwh >= 0",
            name="ck_panels_generated_nonneg",
        ),
        CheckConstraint(
            "base_gen_per_sec >= 0",
            name="ck_panels_base_rate_nonneg",
        ),
        # Каноничный инвариант времени для SSOT Panels
        CheckConstraint(
            "expires_at > activated_at",
            name="ck_panels_expires_gt_activated",
        ),
        UniqueConstraint(
            "public_id",
            name="uq_panels_public_id",
        ),
        {"schema": CORE_SCHEMA},
    )

    id: Mapped[int] = mapped_column(
        BigInteger,
        primary_key=True,
        autoincrement=True,
    )

    # Идентификация владельца
    tg_id: Mapped[int] = mapped_column(
        BigInteger,
        nullable=False,
        index=True,
    )

    # Статус жизненного цикла
    is_active: Mapped[bool] = mapped_column(
        nullable=False,
        default=True,
        server_default="true",
        index=True,
    )

    # Глобальный публичный идентификатор панели (SSOT: ID########)
    # В PostgreSQL допускается NULL до заполнения в той же транзакции
    # сервиса создания панели (UNIQUE с множественными NULL).
    public_id: Mapped[Optional[str]] = mapped_column(
        String(16),
        nullable=True,
        index=True,
    )
    created_at: Mapped[datetime] = mapped_column(
        TIMESTAMP(timezone=True),
        server_default=func.now(),
        nullable=False,
    )

    # Канон SSOT: дата активации панели = дата покупки/создания
    activated_at: Mapped[Optional[datetime]] = mapped_column(
        TIMESTAMP(timezone=True),
        nullable=True,
        index=True,
    )
    expires_at: Mapped[Optional[datetime]] = mapped_column(
        TIMESTAMP(timezone=True),
        nullable=True,
        index=True,
    )
    archived_at: Mapped[Optional[datetime]] = mapped_column(
        TIMESTAMP(timezone=True),
        nullable=True,
        index=True,
    )

    # Данные для «догон-начисления»
    last_generated_at: Mapped[Optional[datetime]] = mapped_column(
        TIMESTAMP(timezone=True),
        nullable=True,
        index=True,
    )

    # Ставка (для аудита) и накопленная энергия
    base_gen_per_sec: Mapped[str] = mapped_column(
        Numeric(30, 8),
        nullable=False,
        default="0",
        server_default="0",
    )
    generated_kwh: Mapped[str] = mapped_column(
        Numeric(30, 8),
        nullable=False,
        default="0",
        server_default="0",
    )

    # UI/расширения
    title: Mapped[Optional[str]] = mapped_column(
        String(64),
        nullable=True,
    )
    meta: Mapped[Optional[Dict[str, Any]]] = mapped_column(
        JSONB,
        nullable=True,
    )

    # Авто-обновление updated_at
    updated_at: Mapped[datetime] = mapped_column(
        TIMESTAMP(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )

    def __repr__(self) -> str:
        """Диагностическое представление панели для логов."""
        st = "active" if self.is_active else "archived"
        return (
            f"<Panel id={self.id} tg_id={self.tg_id} "
            f"{st} gen={self.generated_kwh}>"
        )

# Индексы под курсоры и быстрые выборки
Index(
    "ix_panels_created_id",
    Panel.created_at,
    Panel.id,
    postgresql_using="btree",
    schema=CORE_SCHEMA,
)
Index(
    "ix_panels_user_active",
    Panel.tg_id,
    Panel.is_active,
    postgresql_using="btree",
    schema=CORE_SCHEMA,
)
Index(
    "ix_panels_user_expire",
    Panel.tg_id,
    Panel.expires_at,
    postgresql_using="btree",
    schema=CORE_SCHEMA,
)

Index(
    "ix_panels_user_activated",
    Panel.tg_id,
    Panel.activated_at,
    postgresql_using="btree",
    schema=CORE_SCHEMA,
)

__all__ = [
    "Panel",
]
# ======================================================================
# Пояснения «для чайника»:
# • Где хранится «архив»?
# В той же таблице: is_active=false и заполнено archived_at.
# Это упрощает
# витрины и миграции.
#
# • Зачем base_gen_per_sec в панели, если расчёт по пользователю?
# Это аудиторское поле и подсказка для UI. Фактическое
# начисление делает energy_service, опираясь на текущий
# is_vip пользователя и канонические GEN_PER_SEC_*.
#
# • Что делает last_generated_at?
# Помогает планировщику «догонять» начисления: сколько
# времени с последнего тика надо
# домножить на ставку при восстановлении после сбоя/перезапуска.
# ======================================================================

