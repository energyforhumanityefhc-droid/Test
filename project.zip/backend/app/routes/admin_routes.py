# -*- coding: utf-8 -*-
# backend/app/routes/admin_routes.py
# ======================================================================
# Назначение:
# Админ-API EFHC Bot: корректировки балансов «банк↔пользователь»,
# ручная реконсиляция входящих TON, сводные отчёты, тех.диагностика.
#
# Канон:
# - Любые денежные операции идут только через transactions_service.
# - Денежные POST требуют Idempotency-Key (строгая идемпотентность).
# - Пользователи не могут уходить в минус (правило сервисов/БД).
# - Банк может быть в минусе (фиксируется в логах).
# - Доступ: require_admin_or_nft_or_key.
#
# Запреты:
# - Никаких прямых SQL для денег из роутов; только сервисные функции.
# - Никаких P2P user→user; корректировки только «пользователь↔банк».
# ======================================================================

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field, conint, constr
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.core.logging_core import get_logger
from backend.app.core.security_core import require_admin_or_nft_or_key
from backend.app.deps import (
    d8,
    get_db,
    require_idempotency_key_header_only,
)
from backend.app.models.lotteries_models import (
    Lotteries,
    LotteriesNFTClaim,
)
from backend.app.services.admin.admin_bank_service import (
    AdminBankService,
    MintBurnRequest,
)
from backend.app.services.lotteries_service import (
    svc_admin_set_auto_lotteries,
    svc_list_lotteries_history,
)
from backend.app.services.transactions_service import (
    credit_user_bonus_from_bank_by_tg_id,
    credit_user_main_from_bank_by_tg_id,
    debit_user_bonus_to_bank_by_tg_id,
    debit_user_main_to_bank_by_tg_id,
)
from backend.app.services.watcher_service import (
    process_incoming_payments,
    reconcile_last_hours,
)
from backend.app.utils.cursor_codec import decode_cursor, encode_cursor

logger = get_logger(__name__)
router = APIRouter(prefix="/admin", tags=["admin"])


class AdminTransferIn(BaseModel):
    tg_id: int = Field(
        ...,
        description="TG ID пользователя (каноничный идентификатор)",
    )
    direction: constr(
        strip_whitespace=True,
        pattern=r"^(bank_to_user|user_to_bank)$",
    )
    balance: constr(
        strip_whitespace=True,
        pattern=r"^(main|bonus)$",
    ) = "main"
    amount: Decimal = Field(..., description="Сумма EFHC (>= 0)")
    reason: Optional[constr(
        strip_whitespace=True,
        max_length=255,
    )] = Field(
        None,
        description="Причина/комментарий (логируется)",
    )


class AdminTransferOut(BaseModel):
    ok: bool
    tg_id: int
    balance: str
    direction: str
    amount: str
    bank_balance_after: Optional[str] = None
    user_main_after: Optional[str] = None
    user_bonus_after: Optional[str] = None
    idempotency_key: str


class TonReconcileIn(BaseModel):
    """Режимы реконсиляции входящих TON."""

    since_utime: Optional[conint(ge=0)] = None
    last_hours: Optional[conint(ge=1, le=168)] = 6
    limit: conint(ge=1, le=5000) = 1000


class TonReconcileOut(BaseModel):
    ok: bool
    processed: int
    parsed: int
    credited: int
    duplicates: int
    errors: int
    note: Optional[str] = None


class ReportsOverviewOut(BaseModel):
    ok: bool
    ts: datetime
    counters: Dict[str, int]
    notes: Optional[str] = None


@router.post(
    "/transfer",
    response_model=AdminTransferOut,
    summary=(
        "Корректировка «банк↔пользователь» "
        "(только через банк, read-through идемпотентность)"
    ),
)
async def admin_transfer(
    payload: AdminTransferIn,
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin_or_nft_or_key),
    idempotency_key: str = Depends(require_idempotency_key_header_only),
) -> AdminTransferOut:
    if payload.amount is None or Decimal(payload.amount) < Decimal("0"):
        raise HTTPException(
            status_code=400,
            detail="Сумма должна быть ≥ 0.",
        )

    tg_id = int(payload.tg_id)
    amount_q8 = d8(payload.amount)

    try:
        if payload.direction == "bank_to_user":
            if payload.balance == "main":
                res = await credit_user_main_from_bank_by_tg_id(
                    db=db,
                    tg_id=tg_id,
                    amount=amount_q8,
                    reason=payload.reason or "ADMIN_CORRECTION_MAIN",
                    idempotency_key=idempotency_key,
                )
            else:
                res = await credit_user_bonus_from_bank_by_tg_id(
                    db=db,
                    tg_id=tg_id,
                    amount=amount_q8,
                    reason=payload.reason or "ADMIN_CORRECTION_BONUS",
                    idempotency_key=idempotency_key,
                )
        else:
            if payload.balance == "main":
                res = await debit_user_main_to_bank_by_tg_id(
                    db=db,
                    tg_id=tg_id,
                    amount=amount_q8,
                    reason=payload.reason or "ADMIN_DEBIT_MAIN_TO_BANK",
                    idempotency_key=idempotency_key,
                )
            else:
                res = await debit_user_bonus_to_bank_by_tg_id(
                    db=db,
                    tg_id=tg_id,
                    amount=amount_q8,
                    reason=(
                        payload.reason or "ADMIN_DEBIT_BONUS_TO_BANK"
                    ),
                    idempotency_key=idempotency_key,
                )
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("admin_transfer failed: %s", exc)
        raise HTTPException(
            status_code=500,
            detail="Не удалось выполнить корректировку.",
        )

    try:
        q = text(
            "\n".join(
                [
                    "select main_balance, bonus_balance",
                    "from efhc_core.users",
                    "where tg_id = :tg",
                ]
            )
        )
        row = await db.execute(q, {"tg": tg_id})
        mb, bb = row.fetchone() or (Decimal("0"), Decimal("0"))
    except Exception:
        mb, bb = Decimal("0"), Decimal("0")

    bank_after = None
    if isinstance(res, dict):
        bank_after = res.get("bank_balance_after")

    return AdminTransferOut(
        ok=True,
        tg_id=tg_id,
        balance=payload.balance,
        direction=payload.direction,
        amount=str(d8(payload.amount)),
        bank_balance_after=(
            str(bank_after) if bank_after is not None else None
        ),
        user_main_after=str(d8(mb)),
        user_bonus_after=str(d8(bb)),
        idempotency_key=idempotency_key,
    )


@router.get(
    "/bank/balance",
    summary="Баланс банка EFHC (efhc_admin.bank_balances)",
)
async def admin_bank_balance(
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin_or_nft_or_key),
) -> Dict[str, Any]:
    bal = await AdminBankService.get_bank_balance(db)
    return {
        "tg_id": int(bal.tg_id),
        "efhc_balance": str(bal.efhc_balance),
    }


@router.post(
    "/bank/mint",
    summary="Эмиссия EFHC в банк (Idempotency-Key обязателен)",
)
async def admin_bank_mint(
    payload: MintBurnRequest,
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin_or_nft_or_key),
    idempotency_key: str = Depends(require_idempotency_key_header_only),
) -> Dict[str, Any]:
    payload.idempotency_key = idempotency_key
    res = await AdminBankService.mint_efhc(
        db,
        req=payload,
        admin_tg_id=0,
    )
    return {
        "ok": True,
        "bank_balance_after": str(res.efhc_balance),
    }


@router.post(
    "/bank/burn",
    summary="Сжигание EFHC в банке (Idempotency-Key обязателен)",
)
async def admin_bank_burn(
    payload: MintBurnRequest,
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin_or_nft_or_key),
    idempotency_key: str = Depends(require_idempotency_key_header_only),
) -> Dict[str, Any]:
    payload.idempotency_key = idempotency_key
    res = await AdminBankService.burn_efhc(
        db,
        req=payload,
        admin_tg_id=0,
    )
    return {
        "ok": True,
        "bank_balance_after": str(res.efhc_balance),
    }


@router.post(
    "/ton/reconcile",
    response_model=TonReconcileOut,
    summary=(
        "Реконсиляция входящих TON "
        "(since_utime/last_hours) + limit"
    ),
)
async def ton_reconcile(
    payload: TonReconcileIn,
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin_or_nft_or_key),
) -> TonReconcileOut:
    if payload.since_utime is None and payload.last_hours is None:
        raise HTTPException(
            status_code=400,
            detail="Укажите since_utime или last_hours.",
        )

    try:
        if payload.since_utime is not None:
            stats = await process_incoming_payments(
                db=db,
                limit=int(payload.limit),
                since_utime=int(payload.since_utime),
            )
        else:
            stats = await reconcile_last_hours(
                db=db,
                hours=int(payload.last_hours),
            )
    except Exception as exc:
        logger.exception("ton_reconcile failed: %s", exc)
        raise HTTPException(
            status_code=500,
            detail="Ошибка реконсиляции входящих TON.",
        )

    return TonReconcileOut(
        ok=True,
        processed=int(stats.get("processed", 0)),
        parsed=int(stats.get("parsed", 0)),
        credited=int(stats.get("credited", 0)),
        duplicates=int(stats.get("duplicates", 0)),
        errors=int(stats.get("errors", 0)),
        note=stats.get("note"),
    )


@router.get(
    "/reports/overview",
    response_model=ReportsOverviewOut,
    summary="Быстрый обзор ключевых счётчиков",
)
async def reports_overview(
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin_or_nft_or_key),
) -> ReportsOverviewOut:
    counters: Dict[str, int] = {
        "ton_inbox_total": 0,
        "ton_inbox_errors": 0,
        "efhc_transfers_total": 0,
        "efhc_transfers_deficit": 0,
        "users_total": 0,
    }
    notes: Optional[str] = None

    try:
        row = await db.execute(
            text("select count(*) from efhc_core.ton_inbox_logs")
        )
        counters["ton_inbox_total"] = int(row.scalar() or 0)

        row = await db.execute(
            text(
                "\n".join(
                    [
                        "select count(*)",
                        "from efhc_core.ton_inbox_logs",
                        "where status like 'error_%'",
                    ]
                )
            )
        )
        counters["ton_inbox_errors"] = int(row.scalar() or 0)

        row = await db.execute(
            text("select count(*) from efhc_core.efhc_transfers_log")
        )
        counters["efhc_transfers_total"] = int(row.scalar() or 0)

        q = "\n".join(
            [
                "select count(*)",
                "from efhc_core.efhc_transfers_log",
                "where extra_info like '%processed_with_deficit%'",
            ]
        )
        row = await db.execute(text(q))
        counters["efhc_transfers_deficit"] = int(row.scalar() or 0)

        row = await db.execute(
            text("select count(*) from efhc_core.users")
        )
        counters["users_total"] = int(row.scalar() or 0)

    except Exception as exc:
        logger.warning("reports_overview partial: %s", exc)
        notes = (
            "Таблицы ещё не инициализированы или "
            "миграции не применены. "
            "Проверьте alembic."
        )

    return ReportsOverviewOut(
        ok=True,
        ts=datetime.utcnow(),
        counters=counters,
        notes=notes,
    )


class AdminLotteriesResultOut(BaseModel):
    winning_ticket_id: int
    winner_tg_id: int
    completed_at: str


class AdminLotteriesHistoryOut(BaseModel):
    id: int
    title: str
    prize_type: str
    prize_value: str
    ticket_price: str
    total_tickets: int
    tickets_sold: int
    status: str
    created_at: datetime
    result: AdminLotteriesResultOut | None = None


class AdminPaginatedLotteriesHistoryOut(BaseModel):
    items: list[AdminLotteriesHistoryOut]
    next_cursor: str | None = None


@router.get(
    "/lotteries/history",
    response_model=AdminPaginatedLotteriesHistoryOut,
    summary="История lotteries с победителями (если завершён)",
)
async def admin_lotteries_history(
    limit: int = Query(50, ge=1, le=200),
    cursor: str | None = None,
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin_or_nft_or_key),
) -> AdminPaginatedLotteriesHistoryOut:
    after: Dict[str, Any] | None = None
    if cursor:
        try:
            after = decode_cursor(cursor)
        except Exception:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Некорректный cursor",
            )

    items, next_after = await svc_list_lotteries_history(
        db,
        limit=int(limit),
        cursor=after,
    )

    out_items = [AdminLotteriesHistoryOut(**it) for it in items]
    next_cursor = encode_cursor(next_after) if next_after else None
    return AdminPaginatedLotteriesHistoryOut(
        items=out_items,
        next_cursor=next_cursor,
    )


class AdminNFTClaimOut(BaseModel):
    id: int
    lotteries_id: int
    winner_tg_id: int
    wallet_address: str | None
    status: str
    created_at: datetime
    updated_at: datetime


class AdminSetAutoLotteriesIn(BaseModel):
    enabled: bool


@router.get(
    "/lotteries/nft-claims",
    response_model=list[AdminNFTClaimOut],
    summary=(
        "Очередь заявок на выдачу NFT-приза "
        "(pending/sent/rejected)"
    ),
)
async def admin_list_nft_claims(
    status_: str | None = None,
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin_or_nft_or_key),
) -> list[AdminNFTClaimOut]:
    q = select(LotteriesNFTClaim).order_by(
        LotteriesNFTClaim.created_at.desc()
    )
    if status_:
        q = q.where(LotteriesNFTClaim.status == str(status_).lower())
    rows = (await db.execute(q)).scalars().all()
    return [
        AdminNFTClaimOut(
            id=int(r.id),
            lotteries_id=int(r.lotteries_id),
            winner_tg_id=int(r.winner_tg_id),
            wallet_address=r.wallet_address,
            status=str(r.status),
            created_at=r.created_at,
            updated_at=r.updated_at,
        )
        for r in rows
    ]


@router.post(
    "/lotteries/nft-claims/{claim_id}/mark-sent",
    summary="Отметить NFT-claim как отправленный",
)
async def admin_mark_nft_claim_sent(
    claim_id: int,
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin_or_nft_or_key),
    idempotency_key: str = Depends(require_idempotency_key_header_only),
) -> Dict[str, Any]:
    q = (
        select(LotteriesNFTClaim)
        .where(LotteriesNFTClaim.id == int(claim_id))
        .with_for_update(skip_locked=True)
    )
    claim = (await db.execute(q)).scalar_one_or_none()
    if not claim:
        raise HTTPException(status_code=404, detail="Claim не найден.")

    if str(claim.status).lower() == "sent":
        return {
            "ok": True,
            "claim_id": int(claim.id),
            "status": "sent",
            "idempotency": "read-through",
        }

    claim.status = "sent"
    claim.updated_at = datetime.now(timezone.utc)
    return {
        "ok": True,
        "claim_id": int(claim.id),
        "status": "sent",
        "idempotency_key": idempotency_key,
    }


@router.post(
    "/lotteries/{lotteries_id}/auto-lotteries",
    summary="Тумблер autorun для лотереи",
)
async def admin_set_lotteries_auto_lotteries(
    lotteries_id: int,
    payload: AdminSetAutoLotteriesIn,
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin_or_nft_or_key),
    idempotency_key: str = Depends(require_idempotency_key_header_only),
) -> Dict[str, Any]:
    res = await svc_admin_set_auto_lotteries(
        db=db,
        admin_tg_id=0,
        lotteries_id=int(lotteries_id),
        enabled=bool(payload.enabled),
    )
    res["idempotency_key"] = idempotency_key
    return res
