# -*- coding: utf-8 -*-
# backend/app/routes/admin_tasks_routes.py
# ======================================================================
# Админские HTTP-ручки блока «Задания» (Tasks) EFHC Bot.
#
# Назначение:
# - CRUD заданий.
# - Просмотр пользовательских заявок (submissions) с курсорами.
# - Модерация заявок (approve/reject) с безопасной выплатой через банк.
#
# Канон:
# - Денежные операции требуют Idempotency-Key.
# - Денежные эффекты выполняет только банк (transactions_service).
# - Пагинация без OFFSET: только курсоры encode_cursor/decode_cursor.
# - ETag для кэша списков.
# ======================================================================

from datetime import datetime
from decimal import Decimal
from typing import Any, Dict, List, Optional

from fastapi import (
    APIRouter,
    Depends,
    Header,
    HTTPException,
    Query,
    Response,
    status,
)
from pydantic import BaseModel, Field, conint, constr, field_validator
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.core.logging_core import get_logger
from backend.app.deps import (
    d8,
    decode_cursor_or_400,
    get_db,
    make_etag,
    require_admin,
)
from backend.app.utils.cursor_codec import encode_cursor

logger = get_logger(__name__)
router = APIRouter(prefix="/api/admin", tags=["admin:tasks"])


def _etag_payload(payload: Dict[str, Any]) -> str:
    """ETag хелпер для ответов (детерминированный)."""
    return make_etag(payload)


# ----------------------------------------------------------------------
# «Мягкие» импорты сервисов.
# Если сервис недоступен/не импортируется — возвращаем 503.
# ----------------------------------------------------------------------
try:
    from backend.app.services.tasks_service import (  # type: ignore
        admin_create_task,
        admin_delete_task,
        admin_get_task,
        admin_list_submissions,
        admin_list_tasks,
        admin_update_task,
        moderate_submission_and_pay,
    )

    _TASK_SVC_AVAILABLE = True
except Exception:
    admin_create_task = None
    admin_update_task = None
    admin_delete_task = None
    admin_get_task = None
    admin_list_tasks = None
    admin_list_submissions = None
    moderate_submission_and_pay = None
    _TASK_SVC_AVAILABLE = False


# ----------------------------------------------------------------------
# Pydantic-схемы (локально, без зависимости от app/schemas).
# ----------------------------------------------------------------------


class TaskCreate(BaseModel):
    """Создание задания (без денежных эффектов)."""

    title: constr(strip_whitespace=True, min_length=1, max_length=200)
    description: Optional[str] = None
    is_active: bool = True
    reward_efhc: constr(strip_whitespace=True) = Field(
        ...,
        description=(
            "Номинальная награда EFHC (строка Decimal(30,8))"
        ),
    )
    kind: constr(
        strip_whitespace=True, min_length=1, max_length=50,
    ) = "generic"
    meta: Optional[Dict[str, Any]] = None

    @field_validator("reward_efhc")
    def _v_reward(cls, v: str) -> str:
        """Валидирует reward_efhc и нормализует к d8 (ROUND_DOWN)."""
        amt = d8(v)
        if amt <= Decimal("0"):
            raise ValueError("reward_efhc должен быть > 0")
        return str(amt)


class TaskUpdate(BaseModel):
    """Частичное редактирование задания (без немедленной выплаты)."""

    title: Optional[
        constr(strip_whitespace=True, min_length=1, max_length=200)
    ] = None
    description: Optional[str] = None
    is_active: Optional[bool] = None
    reward_efhc: Optional[constr(strip_whitespace=True)] = None
    kind: Optional[
        constr(strip_whitespace=True, min_length=1, max_length=50)
    ] = None
    meta: Optional[Dict[str, Any]] = None

    @field_validator("reward_efhc")
    def _v_reward(cls, v: Optional[str]) -> Optional[str]:
        """Валидирует reward_efhc и нормализует к d8 (ROUND_DOWN)."""
        if v is None:
            return v
        amt = d8(v)
        if amt <= Decimal("0"):
            raise ValueError("reward_efhc должен быть > 0")
        return str(amt)


class TaskOut(BaseModel):
    """DTO задания для админ-витрины."""

    id: int
    title: str
    description: Optional[str] = None
    is_active: bool
    reward_efhc: str
    kind: str
    meta: Optional[Dict[str, Any]] = None
    created_at: datetime
    updated_at: datetime


class PaginatedTasks(BaseModel):
    """Ответ со списком заданий (курсоры)."""

    items: List[TaskOut]
    next_cursor: Optional[str] = None


class SubmissionOut(BaseModel):
    """DTO пользовательской заявки на задание."""

    id: int
    task_id: int
    tg_id: int
    status: str
    proof_url: Optional[str] = None
    submitted_at: datetime
    reviewed_at: Optional[datetime] = None
    reward_efhc: Optional[str] = None
    moderator_tg_id: Optional[int] = None


class PaginatedSubmissions(BaseModel):
    """Ответ со списком заявок (курсоры)."""

    items: List[SubmissionOut]
    next_cursor: Optional[str] = None


class SubmissionModerateIn(BaseModel):
    """Вход модерации: approve/reject (+опциональная ручная сумма)."""

    approve: bool
    moderator_tg_id: Optional[int] = Field(
        None,
        description="Telegram ID модератора для аудита",
    )
    reward_override_efhc: Optional[
        constr(strip_whitespace=True)
    ] = Field(
        None,
        description=(
            "Необязательная ручная сумма награды "
            "(строка Decimal(30,8))"
        ),
    )

    @field_validator("reward_override_efhc")
    def _v_override(cls, v: Optional[str]) -> Optional[str]:
        """Валидирует reward_override_efhc и нормализует к d8."""
        if v is None:
            return v
        amt = d8(v)
        if amt <= Decimal("0"):
            raise ValueError("reward_override_efhc должен быть > 0")
        return str(amt)


# ----------------------------------------------------------------------
# CRUD заданий (без прямых денежных действий)
# ----------------------------------------------------------------------


@router.post(
    "/tasks",
    response_model=TaskOut,
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(require_admin)],
)
async def create_task_admin(
    payload: TaskCreate,
    db: AsyncSession = Depends(get_db),
) -> TaskOut:
    """Создать задание (денег не трогает)."""
    if not _TASK_SVC_AVAILABLE or admin_create_task is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="tasks_service недоступен",
        )
    try:
        obj = await admin_create_task(db, payload.model_dump())
        return TaskOut(**obj)
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("admin_create_task failed: %s", e)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Временная ошибка создания задания",
        )


@router.get(
    "/tasks",
    response_model=PaginatedTasks,
    dependencies=[Depends(require_admin)],
)
async def list_tasks_admin(
    response: Response,
    limit: conint(ge=1, le=200) = 50,
    cursor: Optional[str] = None,
    q: Optional[str] = Query(None, description="Поиск по названию"),
    active: Optional[bool] = Query(
        None, description="Фильтр по активности"
    ),
    db: AsyncSession = Depends(get_db),
) -> PaginatedTasks:
    """Список заданий с курсорами + ETag."""
    if not _TASK_SVC_AVAILABLE or admin_list_tasks is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="tasks_service недоступен",
        )

    after: Optional[Dict[str, Any]] = None
    if cursor:
        after = decode_cursor_or_400(cursor)

    try:
        data = await admin_list_tasks(
            db,
            limit=int(limit),
            after=after,
            q=q,
            active=active,
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("admin_list_tasks failed: %s", e)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Временная ошибка списка заданий",
        )

    items_raw: List[Dict[str, Any]] = list(data.get("items") or [])
    items = [TaskOut(**it) for it in items_raw]
    next_after = data.get("next_after")

    next_cursor: Optional[str]
    if next_after:
        next_cursor = encode_cursor({"after_id": int(next_after)})
    else:
        next_cursor = None

    body = PaginatedTasks(items=items, next_cursor=next_cursor)

    try:
        response.headers["ETag"] = _etag_payload(body.model_dump())
    except Exception:
        logger.warning("ETag compute failed", exc_info=True)

    return body


@router.get(
    "/tasks/{task_id}",
    response_model=TaskOut,
    dependencies=[Depends(require_admin)],
)
async def get_task_admin(
    task_id: int,
    db: AsyncSession = Depends(get_db),
) -> TaskOut:
    """Получить задание по ID."""
    if not _TASK_SVC_AVAILABLE or admin_get_task is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="tasks_service недоступен",
        )
    try:
        obj = await admin_get_task(db, int(task_id))
        if not obj:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Задание не найдено",
            )
        return TaskOut(**obj)
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("admin_get_task failed: %s", e)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Временная ошибка получения задания",
        )


@router.patch(
    "/tasks/{task_id}",
    response_model=TaskOut,
    dependencies=[Depends(require_admin)],
)
async def update_task_admin(
    task_id: int,
    payload: TaskUpdate,
    db: AsyncSession = Depends(get_db),
) -> TaskOut:
    """Обновить поля задания (без выплат)."""
    if not _TASK_SVC_AVAILABLE or admin_update_task is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="tasks_service недоступен",
        )
    try:
        patch = payload.model_dump(exclude_unset=True)
        obj = await admin_update_task(db, int(task_id), dict(patch))
        if not obj:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Задание не найдено",
            )
        return TaskOut(**obj)
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("admin_update_task failed: %s", e)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Временная ошибка обновления задания",
        )


@router.delete(
    "/tasks/{task_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    dependencies=[Depends(require_admin)],
)
async def delete_task_admin(
    task_id: int,
    db: AsyncSession = Depends(get_db),
) -> None:
    """Удалить задание (денежных побочных эффектов нет)."""
    if not _TASK_SVC_AVAILABLE or admin_delete_task is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="tasks_service недоступен",
        )
    try:
        ok = await admin_delete_task(db, int(task_id))
        if not ok:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Задание не найдено",
            )
        return None
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("admin_delete_task failed: %s", e)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Временная ошибка удаления задания",
        )


# ----------------------------------------------------------------------
# Витрина заявок по заданию (просмотр)
# ----------------------------------------------------------------------


@router.get(
    "/tasks/{task_id}/subs",
    response_model=PaginatedSubmissions,
    dependencies=[Depends(require_admin)],
)
async def list_task_submissions_admin(
    response: Response,
    task_id: int,
    limit: conint(ge=1, le=200) = 50,
    cursor: Optional[str] = None,
    status_filter: Optional[str] = Query(
        None,
        alias="status",
        description="PENDING/APPROVED/REJECTED",
    ),
    db: AsyncSession = Depends(get_db),
) -> PaginatedSubmissions:
    """Список заявок по конкретному заданию (курсоры + ETag)."""
    if not _TASK_SVC_AVAILABLE or admin_list_submissions is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="tasks_service недоступен",
        )

    after: Optional[Dict[str, Any]] = None
    if cursor:
        after = decode_cursor_or_400(cursor)

    try:
        data = await admin_list_submissions(
            db,
            task_id=int(task_id),
            limit=int(limit),
            after=after,
            status=status_filter,
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("admin_list_submissions failed: %s", e)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Временная ошибка списка заявок",
        )

    items_raw: List[Dict[str, Any]] = list(data.get("items") or [])
    items = [SubmissionOut(**it) for it in items_raw]
    next_after = data.get("next_after")

    next_cursor: Optional[str]
    if next_after:
        next_cursor = encode_cursor({"after_id": int(next_after)})
    else:
        next_cursor = None

    body = PaginatedSubmissions(items=items, next_cursor=next_cursor)

    try:
        response.headers["ETag"] = _etag_payload(body.model_dump())
    except Exception:
        logger.warning("ETag compute failed", exc_info=True)

    return body


# ----------------------------------------------------------------------
# Модерация заявки (approve/reject) + ВЫПЛАТА бонуса (денежная операция)
# ----------------------------------------------------------------------


@router.post(
    "/submissions/{submission_id}/moderate",
    response_model=SubmissionOut,
    dependencies=[Depends(require_admin)],
)
async def moderate_submission_admin(
    submission_id: int,
    payload: SubmissionModerateIn,
    idempotency_key: Optional[str] = Header(
        None, alias="Idempotency-Key"
    ),
    db: AsyncSession = Depends(get_db),
) -> SubmissionOut:
    """Модерация заявки.

    - approve=True: выплата бонуса через банк идемпотентно.
    - approve=False: отклонение без денежных последствий.

    Требование: Idempotency-Key обязателен для денежных операций.
    """
    if not idempotency_key or not idempotency_key.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                "Idempotency-Key обязателен для денежных операций"
            ),
        )

    if not _TASK_SVC_AVAILABLE or moderate_submission_and_pay is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="tasks_service недоступен",
        )

    try:
        override: Optional[Decimal]
        if payload.reward_override_efhc:
            override = d8(payload.reward_override_efhc)
        else:
            override = None

        mod_tg: Optional[int]
        if payload.moderator_tg_id is not None:
            mod_tg = int(payload.moderator_tg_id)
        else:
            mod_tg = None

        sub = await moderate_submission_and_pay(
            db=db,
            submission_id=int(submission_id),
            approve=bool(payload.approve),
            moderator_tg_id=mod_tg,
            reward_override_efhc=override,
            idempotency_key=idempotency_key.strip(),
        )
        return SubmissionOut(**sub)
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("moderate_submission_and_pay failed: %s", e)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Временная ошибка модерации",
        )
