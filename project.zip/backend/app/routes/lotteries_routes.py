# -*- coding: utf-8 -*-
# backend/app/routes/lotteries_routes.py
# ======================================================================
# Публичные ручки lotteries: витрина, статус, мои билеты, покупка.
#
# Канон:
# • TG-ID only (никакого public tg_id).
# • Курсоры: encode_cursor/decode_cursor возвращают dict.
# • Денежные POST: MUST Idempotency-Key.
# ======================================================================

from __future__ import annotations

from typing import Any, Dict, Optional

from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    Query,
    Response,
    status,
)
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.core.logging_core import get_logger
from backend.app.deps import (
    decode_cursor,
    encode_cursor,
    etag,
    get_current_tg_id,
    get_db,
    require_idempotency_key,
)
from backend.app.schemas.lotteries_schemas import (
    BuyTicketsIn,
    BuyTicketsOut,
    LotteriestatusOut,
    PaginatedLotteriesHistoryOut,
    PaginatedLotteriesOut,
    PaginatedTicketsOut,
)
from backend.app.services.lotteries_service import (
    svc_buy_tickets,
    svc_get_lotteries_status,
    svc_list_active_lotteries,
    svc_list_lotteries_history,
    svc_list_user_tickets,
)

logger = get_logger(__name__)
router = APIRouter(prefix="/api", tags=["lotteries"])


@router.get("/lotteries", response_model=PaginatedLotteriesOut)
async def list_active_lotteries(
    response: Response,
    limit: int = Query(20, ge=1, le=100),
    cursor: Optional[str] = Query(
        None,
        description="Cursor (base64url(json dict))",
    ),
    db: AsyncSession = Depends(get_db),
) -> PaginatedLotteriesOut:
    after: Optional[Dict[str, Any]] = None
    if cursor:
        try:
            after = decode_cursor(cursor)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Некорректный cursor",
            )

    items, next_after = await svc_list_active_lotteries(
        db,
        limit=int(limit),
        cursor=after,
    )
    body = PaginatedLotteriesOut(
        items=items,
        next_cursor=(encode_cursor(next_after) if next_after else None),
    )

    try:
        response.headers["ETag"] = etag(body.model_dump())
    except Exception:
        logger.warning(
            "ETag compute failed for /lotteries",
            exc_info=True,
        )

    return body


@router.get(
    "/lotteries/history",
    response_model=PaginatedLotteriesHistoryOut,
)
async def list_lotteries_history(
    response: Response,
    limit: int = Query(20, ge=1, le=100),
    cursor: Optional[str] = Query(
        None,
        description="Cursor (base64url(json dict))",
    ),
    db: AsyncSession = Depends(get_db),
) -> PaginatedLotteriesHistoryOut:
    """История завершённых lotteries с результатами."""
    after: Optional[Dict[str, Any]] = None
    if cursor:
        try:
            after = decode_cursor(cursor)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Некорректный cursor",
            )

    items, next_after = await svc_list_lotteries_history(
        db,
        limit=int(limit),
        cursor=after,
        status_in=["finished", "archived"],
    )
    body = PaginatedLotteriesHistoryOut(
        items=items,
        next_cursor=(encode_cursor(next_after) if next_after else None),
    )

    try:
        response.headers["ETag"] = etag(body.model_dump())
    except Exception:
        logger.warning(
            "ETag compute failed for /lotteries/history",
            exc_info=True,
        )

    return body


@router.get(
    "/lotteries/{lotteries_id}",
    response_model=LotteriestatusOut,
)
async def get_lotteries_status(
    response: Response,
    lotteries_id: int,
    db: AsyncSession = Depends(get_db),
) -> LotteriestatusOut:
    st = await svc_get_lotteries_status(db, int(lotteries_id))
    if not st:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Lotteries not found",
        )

    body = LotteriestatusOut(**st)
    try:
        response.headers["ETag"] = etag(body.model_dump())
    except Exception:
        logger.warning(
            "ETag compute failed for /lotteries/{lotteries_id}",
            exc_info=True,
        )

    return body


@router.get(
    "/lotteries/{lotteries_id}/my-tickets",
    response_model=PaginatedTicketsOut,
)
async def list_my_tickets(
    response: Response,
    lotteries_id: int,
    limit: int = Query(50, ge=1, le=200),
    cursor: Optional[str] = Query(
        None,
        description="Cursor (base64url(json dict))",
    ),
    tg_id: int = Depends(get_current_tg_id),
    db: AsyncSession = Depends(get_db),
) -> PaginatedTicketsOut:
    after: Optional[Dict[str, Any]] = None
    if cursor:
        try:
            after = decode_cursor(cursor)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Некорректный cursor",
            )

    tickets, next_after = await svc_list_user_tickets(
        db,
        lotteries_id=int(lotteries_id),
        tg_id=int(tg_id),
        limit=int(limit),
        cursor=after,
    )

    body = PaginatedTicketsOut(
        items=tickets,
        next_cursor=(encode_cursor(next_after) if next_after else None),
    )
    try:
        response.headers["ETag"] = etag(body.model_dump())
    except Exception:
        logger.warning(
            (
                "ETag compute failed for "
                "/lotteries/{lotteries_id}/my-tickets"
            ),
            exc_info=True,
        )

    return body


@router.post(
    "/lotteries/{lotteries_id}/buy",
    response_model=BuyTicketsOut,
)
async def buy_tickets(
    request: Request,
    response: Response,
    lotteries_id: int,
    body: BuyTicketsIn,
    tg_id: int = Depends(get_current_tg_id),
    db: AsyncSession = Depends(get_db),
    idk: str = Depends(require_idempotency_key),
) -> BuyTicketsOut:
    from backend.app.deps import require_wallet_connected

    await require_wallet_connected(
        request,
        db=db,
        current_tg_id=tg_id,
        feature="lotteries",
    )
    try:
        res = await svc_buy_tickets(
            db,
            lotteries_id=int(lotteries_id),
            tg_id=int(tg_id),
            qty=int(body.qty),
            idempotency_key=str(idk),
            wallet_address=(
                str(body.wallet_address).strip()
                if body.wallet_address
                else None
            ),
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("buy_tickets failed: %s", e)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Временная ошибка покупки",
        )

    out = BuyTicketsOut(**res)
    try:
        response.headers["ETag"] = etag(out.model_dump())
    except Exception:
        logger.warning(
            "ETag compute failed for /lotteries/{lotteries_id}/buy",
            exc_info=True,
        )

    return out
