# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------
# Назначение кода:
# Bridge-job: вызывает run_once() из
# backend.app.scheduler.generate_energy.
# ---------------------------------------------------------------------

from __future__ import annotations

from backend.app.scheduler.generate_energy import run_once
