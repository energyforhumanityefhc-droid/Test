# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------
# Назначение кода:
# Bridge-job: вызывает run_once() из
# backend.app.scheduler.check_ton_inbox.
# ---------------------------------------------------------------------

from __future__ import annotations

from backend.app.scheduler.check_ton_inbox import run_once
