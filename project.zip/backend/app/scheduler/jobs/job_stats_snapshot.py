# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------
# Назначение кода:
# Bridge-job: вызывает run_once() из
# backend.app.scheduler.update_ranks.
# ---------------------------------------------------------------------

from __future__ import annotations

from backend.app.scheduler.update_ranks import run_once
