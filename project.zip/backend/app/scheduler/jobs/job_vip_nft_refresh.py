# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# Назначение кода:
# Bridge-job: вызывает run_once() из
# backend.app.scheduler.check_vip_nft.
# ----------------------------------------------------------------------

from __future__ import annotations

from backend.app.scheduler.check_vip_nft import run_once
