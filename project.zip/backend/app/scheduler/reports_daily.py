# -*- coding: utf-8 -*-
# backend/app/scheduler/reports_daily.py
# ======================================================================
# Назначение кода:
# Ежедневный отчёт для администратора.
#
# Подтверждено пользователем:
# • Храним в логах (таблица админ-уведомлений/логов) И
# • Отправляем админу в Telegram (ADMIN_TELEGRAM_ID) через Bot API.
#
# Канон:
# • Без секретов в коде. BOT_TOKEN, ADMIN_TELEGRAM_ID — только из ENV.
# ======================================================================

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.core.config_core import get_settings
from backend.app.core.database_core import get_db
from backend.app.core.logging_core import get_logger
from backend.app.services.admin.admin_notifications import AdminNotifier
from backend.app.services.reports_service import daily_admin_summary

logger = get_logger("efhc.scheduler.reports_daily")


async def _write_log(
    db: AsyncSession,
    title: str,
    payload: dict[str, Any],
) -> None:
    """Запись отчёта в админ - лог (таблица admin_events, если есть)."""
    s = get_settings()
    schema = getattr(s, "DB_SCHEMA_CORE", "efhc_core")
    # best-effort: если таблицы нет — просто логируем
    try:
        from sqlalchemy import text

        q = text(
            f"INSERT INTO {schema}.admin_events "
            "(event_type, title, payload, created_at) "
            "VALUES (:t, :title, :payload, NOW())"
        )
        await db.execute(
            q,
            {
                "t": "daily_report",
                "title": title,
                "payload": json.dumps(payload, ensure_ascii=False),
            },
        )
        await db.commit()
    except Exception:
        await db.rollback()
        logger.info(
            "daily_report: admin_events table not available; "
            "stored in logs only"
        )


async def run_once() -> dict[str, Any]:
    """Собирает ежедневный отчёт и отправляет админу."""
    s = get_settings()

    async with get_db() as db:
        report = await daily_admin_summary(db, days=1)

        title = (
            f"EFHC Daily Report • "
            f"{datetime.now(timezone.utc).date().isoformat()}"
        )
        await _write_log(db, title=title, payload=report)

        # Отправка в Telegram админу
        notifier = AdminNotifier()
        msg = notifier.format_daily_report(report)
        await notifier.notify_generic(title=title, message=msg)

        return {
            "report": report,
            "sent_to_admin": bool(s.BOT_TOKEN and s.ADMIN_TELEGRAM_ID),
        }


__all__ = ["run_once"]

