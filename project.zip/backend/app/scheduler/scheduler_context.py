# -*- coding: utf-8 -*-
# backend/app/scheduler/scheduler_context.py
# ----------------------------------------------------------------------
# Назначение кода:
# Контекст для совместимого API планировщика.
# Сейчас не используется напрямую.
# ----------------------------------------------------------------------

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime


@dataclass
class TickContext:
    started_at: datetime
