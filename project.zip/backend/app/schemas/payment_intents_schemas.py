# -*- coding: utf-8 -*-
# backend/app/schemas/payment_intents_schemas.py
# ---------------------------------------------------------------------
# SSOT schema: Payment Intent status view (owner-only).
# ---------------------------------------------------------------------

from __future__ import annotations

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field


class PaymentIntentStatusOut(BaseModel):
    id: int
    purpose: str
    asset: str
    amount_asset_d8: str
    efhc_amount_d8: Optional[str] = None
    status: str
    payload: str
    to_address: str
    external_tx_hash: Optional[str] = None
    created_at: datetime
    expires_at: datetime

    class Config:
        json_schema_extra = {
            "example": {
                "id": 12,
                "purpose": "deposit_efhc",
                "asset": "TON",
                "amount_asset_d8": "1.00000000",
                "efhc_amount_d8": "10.00000000",
                "status": "SENT",
                "payload": "EFHC:deposit_efhc:12:9001",
                "to_address": "EQ...",
                "external_tx_hash": None,
                "created_at": "2026-02-25T00:00:00Z",
                "expires_at": "2026-02-25T00:15:00Z",
            }
        }
