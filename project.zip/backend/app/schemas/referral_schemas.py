# -*- coding: utf-8 -*-
# backend/app/schemas/referral_schemas.py
# ----------------------------------------------------------------------
# Pydantic-схемы для раздела "Рефералы": витрины, курсоры, sync-ответы.
# ----------------------------------------------------------------------

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any, Literal, Optional

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    conint,
    constr,
    field_validator,
)

from backend.app.schemas.common_schemas import (
    CursorPage,
    IdempotencyContract,
    OkMeta,
    d8_str,
)

TabName = Literal["active", "inactive"]


class ReferralRow(BaseModel):
    """Карточка реферала в списках "Активные/Неактивные"."""

    referee_tg_id: int = Field(..., description="tg_id реферала.")
    username: Optional[str] = Field(
        None,
        description="Никнейм (если есть).",
    )
    is_active: bool = Field(
        ...,
        description="True, если реферал купил панель хотя бы раз.",
    )
    joined_at: Optional[datetime] = Field(
        None,
        description="Когда реферал присоединился.",
    )
    became_active_at: Optional[datetime] = Field(
        None,
        description="Когда реферал стал активным.",
    )
    panels_count: int = Field(
        ...,
        ge=0,
        description="Сколько панелей купил реферал.",
    )
    total_bonus_earned_by_referrer: str = Field(
        ...,
        description="Сколько бонусов начислено пригласившему (str, 8).",
    )

    @field_validator("total_bonus_earned_by_referrer", mode="before")
    def _q8(cls, v: Any) -> str:
        return d8_str(v)

    model_config = ConfigDict(extra="ignore")


ActiveReferralsPage = CursorPage[ReferralRow]
InactiveReferralsPage = CursorPage[ReferralRow]


class MyReferralInfoOut(BaseModel):
    """Шапка раздела: код/ссылка + агрегаты."""

    meta: OkMeta = Field(default_factory=OkMeta)
    my_tg_id: int = Field(
        ...,
        description="tg_id текущего пользователя.",
    )
    referral_code: str = Field(
        ...,
        description="Мой рефкод (стабилен).",
    )
    deep_link: str = Field(
        ...,
        description="Готовая deeplink-ссылка для приглашения.",
    )
    active_count: int = Field(
        ...,
        ge=0,
        description="Активных рефералов.",
    )
    inactive_count: int = Field(
        ...,
        ge=0,
        description="Неактивных рефералов.",
    )
    total_bonus_earned: str = Field(
        ...,
        description="Суммарно бонусов начислено мне (str, 8).",
    )
    last_bonus_at: Optional[datetime] = Field(
        None,
        description="Когда последний раз начисляли бонус.",
    )

    @field_validator("total_bonus_earned", mode="before")
    def _q8(cls, v: Any) -> str:
        return d8_str(v)

    model_config = ConfigDict(extra="ignore")


class ReferralsQueryIn(BaseModel):
    """Запрос списка рефералов для вкладки."""

    tab: TabName = Field(..., description="active | inactive.")
    next_cursor: Optional[str] = Field(
        None,
        description="Курсор следующей страницы (base64).",
    )
    limit: Optional[conint(ge=1, le=200)] = Field(
        None,
        description="Размер страницы (1..200).",
    )

    model_config = ConfigDict(extra="ignore")


class ReferralsSyncOut(BaseModel):
    """Служебная синхронизация при открытии раздела."""

    meta: OkMeta = Field(default_factory=OkMeta)
    refreshed: int = Field(..., ge=0, description="Сколько освежено.")
    errors: int = Field(..., ge=0, description="Сколько ошибок.")
    note: Optional[str] = Field(
        None,
        description="Короткая приметка ('ok'/'partial').",
    )

    model_config = ConfigDict(extra="ignore")


class ReferralAttachIn(BaseModel):
    """Привязка рефкода при старте через deeplink."""

    referral_code: constr(
        strip_whitespace=True,
        min_length=4,
        max_length=64,
    ) = Field(..., description="Код из deeplink.")


class ReferralAttachOut(BaseModel):
    meta: OkMeta = Field(default_factory=OkMeta)
    attached: bool = Field(
        ...,
        description="True, если привязали впервые.",
    )
    reason: Optional[str] = Field(
        None,
        description="Причина отказа (self_ref/already_set и т.п.).",
    )

    model_config = ConfigDict(extra="ignore")


class ReferralClaimIn(IdempotencyContract):
    """Идемпотентный клейм (если такая механика появится)."""

    claim_code: constr(
        strip_whitespace=True,
        min_length=6,
        max_length=64,
    ) = Field(..., description="Идентификатор клейма/условия.")


class ReferralClaimOut(BaseModel):
    meta: OkMeta = Field(default_factory=OkMeta)
    claimed: bool = Field(
        ...,
        description="True, если клейм состоялся.",
    )
    detail: Optional[str] = Field(
        None,
        description="Короткое пояснение (already_claimed/ok и т.п.).",
    )

    model_config = ConfigDict(extra="ignore")


class BonusRecordCreate(BaseModel):
    """Запись в журнал бонусов (НЕ баланс и НЕ банковская операция)."""

    tg_id: int
    amount_efhc: Decimal
    kind: constr(
        strip_whitespace=True,
        min_length=1,
        max_length=32,
    ) = Field(..., description="Тип записи (например 'rank').")
    meta: Optional[dict[str, Any]] = None

    model_config = ConfigDict(extra="ignore")
