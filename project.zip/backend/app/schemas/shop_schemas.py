# -*- coding: utf-8 -*-
# backend/app/schemas/shop_schemas.py
# ----------------------------------------------------------------------
# Pydantic-схемы: каталог, покупка за EFHC, TON-интент, NFT.
# внешние заказы и списки.
# ----------------------------------------------------------------------

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any, List, Literal, Optional

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    conint,
    constr,
    field_validator,
)

from backend.app.deps import d8
from backend.app.schemas.common_schemas import CursorPage

# ----------------------------------------------------------------------
# Литералы домена
# ----------------------------------------------------------------------

ShopItemType = Literal[
    "EFHC_PACKAGE",
    "NFT_VIP",
    "VIRTUAL_GOOD",
    "DIGITAL_SERVICE",
]

ShopOrderStatus = Literal[
    "PENDING",
    "PAID_AUTO",
    "PAID_PENDING_MANUAL",
    "APPROVED",
    "REJECTED",
    "CANCELLED",
]

PayMethod = Literal["EFHC", "TON"]

SKU_MAX_LEN = 64


# ----------------------------------------------------------------------
# Витрина каталога
# ----------------------------------------------------------------------


class ShopCatalogItemOut(BaseModel):
    """Элемент витрины Shop (карточка товара)."""

    id: int = Field(..., description="ID товара.")
    type: ShopItemType = Field(..., description="Тип товара.")
    sku: constr(
        strip_whitespace=True,
        min_length=1,
        max_length=SKU_MAX_LEN,
    ) = Field(..., description="Уникальный SKU (заказы/мемо).")
    title: constr(strip_whitespace=True, min_length=1, max_length=255)
    description: Optional[str] = None
    active: bool = True

    price_efhc: Optional[Decimal] = Field(
        None,
        description=(
            "Цена в EFHC (Decimal/8). "
            "None - за EFHC не купить."
        ),
    )

    ton_enabled: bool = Field(
        False,
        description="Можно оплатить через TON (обычно EFHC-пакеты).",
    )
    ton_dest_address: Optional[str] = Field(
        None,
        description="TON-адрес проекта (проверяется watcher).",
    )
    ton_price_hint: Optional[Decimal] = Field(
        None,
        description="Ориентировочная цена в TON (информативно).",
    )
    memo_template: Optional[str] = Field(
        None,
        description=(
            "Шаблон MEMO для TON (например "
            "'SKU:EFHC|Q:{qty}|TG:{tg_id}')."
        ),
    )

    max_per_user: Optional[conint(ge=0)] = Field(
        None,
        description=(
            "Лимит на пользователя (0 запрет, "
            "None без лимита)."
        ),
    )
    stock_total: Optional[conint(ge=0)] = None
    stock_left: Optional[conint(ge=0)] = None

    image_url: Optional[str] = None

    created_at: datetime
    updated_at: datetime

    @field_validator("price_efhc", "ton_price_hint", mode="before")
    def _q8(
        cls,
        v: Optional[Decimal],
    ) -> Optional[Decimal]:
        """Квантизация Decimal до 8 знаков (ROUND_DOWN)."""
        return None if v is None else d8(v)

    model_config = ConfigDict(extra="ignore")


class ShopCatalogOut(BaseModel):
    items: List[ShopCatalogItemOut]


# ----------------------------------------------------------------------
# Покупка внутри бота за EFHC
# ----------------------------------------------------------------------


class ShopPurchaseByEFHCIn(BaseModel):
    """Покупка за EFHC внутри бота (денежный POST: Idempotency-Key)."""

    sku: constr(
        strip_whitespace=True,
        min_length=1,
        max_length=SKU_MAX_LEN,
    )
    quantity: conint(gt=0) = Field(..., description="Штуки > 0.")
    prefer_bonus_first: bool = Field(
        True,
        description="Сначала списать бонусы (канон).",
    )
    client_nonce: Optional[constr(
        strip_whitespace=True,
        min_length=1,
        max_length=128,
    )] = None


class ShopPurchaseByEFHCOut(BaseModel):
    """Результат покупки за EFHC (через банковский сервис)."""

    ok: bool = True
    sku: str
    quantity: int
    debited_bonus_efhc: Decimal = Field(Decimal("0"))
    debited_main_efhc: Decimal = Field(Decimal("0"))
    total_debited_efhc: Decimal = Field(Decimal("0"))
    bank_transfer_log_id: int = Field(
        ...,
        description="ID в efhc_transfers_log.",
    )
    idempotency_key: str
    message: str = ""
    processed_at: datetime

    @field_validator(
        "debited_bonus_efhc",
        "debited_main_efhc",
        "total_debited_efhc",
        mode="before",
    )
    def _q8(cls, v: Decimal) -> Decimal:
        return d8(v)

    model_config = ConfigDict(extra="ignore")


# Backward-compat (часть роутов ещё использует старые имена)
class ShopPurchaseEFHCIn(ShopPurchaseByEFHCIn):
    pass


class ShopPurchaseEFHCOut(ShopPurchaseByEFHCOut):
    pass


# ----------------------------------------------------------------------
# TON-интент (EFHC-пакеты за TON)
# ----------------------------------------------------------------------


class TonPaymentIntentIn(BaseModel):
    """Запрос параметров оплаты EFHC-пакета через TON (без списаний)."""

    sku: constr(
        strip_whitespace=True,
        min_length=1,
        max_length=SKU_MAX_LEN,
    )
    quantity: conint(gt=0) = Field(
        ...,
        description="Сколько единиц пакета покупаем.",
    )
    client_nonce: Optional[constr(
        strip_whitespace=True,
        min_length=1,
        max_length=128,
    )] = None


class TonPaymentIntentOut(BaseModel):
    """Параметры оплаты в TON: адрес, MEMO, подсказка суммы."""

    ok: bool = True
    dest_address: str = Field(
        ...,
        description="TON-адрес проекта (из конфигурации).",
    )
    memo: str = Field(
        ...,
        description="Строгий MEMO (например 'SKU:EFHC|Q:100|TG:123').",
    )
    ton_amount_due_hint: Optional[Decimal] = Field(
        None,
        description="Подсказка по сумме TON, если есть прайс.",
    )
    expires_at: Optional[datetime] = Field(
        None,
        description="Время жизни интента (информативно).",
    )
    created_order_id: Optional[int] = Field(
        None,
        description=(
            "ID предварительного заказа "
            "(если создаётся запись)."
        ),
    )

    @field_validator("ton_amount_due_hint", mode="before")
    def _q8(
        cls,
        v: Optional[Decimal],
    ) -> Optional[Decimal]:
        return None if v is None else d8(v)

    model_config = ConfigDict(extra="ignore")


# ----------------------------------------------------------------------
# Заявка на NFT (ручная обработка)
# ----------------------------------------------------------------------


class NftRequestCreateIn(BaseModel):
    """Заявка на NFT (VIP). Автовыдачи NFT нет, только ручной аппрув."""

    sku: constr(
        strip_whitespace=True,
        min_length=1,
        max_length=SKU_MAX_LEN,
    ) = Field("NFT_VIP", description="По канону: 'NFT_VIP'.")
    quantity: conint(gt=0) = Field(1, description="Обычно 1.")
    client_nonce: Optional[constr(
        strip_whitespace=True,
        min_length=1,
        max_length=128,
    )] = None


class NftRequestOut(BaseModel):
    id: int
    sku: str
    quantity: int
    status: ShopOrderStatus
    user_tg_id: int
    tx_hash: Optional[str] = None
    created_at: datetime
    updated_at: datetime


# ----------------------------------------------------------------------
# Просмотр/история заказов
# ----------------------------------------------------------------------


class ShopOrderViewOut(BaseModel):
    id: int
    type: ShopItemType
    sku: str
    quantity: int
    status: ShopOrderStatus
    user_tg_id: int

    tx_hash: Optional[str] = Field(
        None,
        description="Хэш платежа TON (если применимо).",
    )
    debited_bonus_efhc: Optional[Decimal] = Field(
        None,
        description="Списано бонусов (если применимо).",
    )
    debited_main_efhc: Optional[Decimal] = Field(
        None,
        description="Списано основного баланса (если применимо).",
    )
    idempotency_key: Optional[str] = Field(
        None,
        description="Ключ идемпотентности (если применялся).",
    )

    created_at: datetime
    updated_at: datetime

    @field_validator(
        "debited_bonus_efhc",
        "debited_main_efhc",
        mode="before",
    )
    def _q8(
        cls,
        v: Optional[Decimal],
    ) -> Optional[Decimal]:
        return None if v is None else d8(v)

    model_config = ConfigDict(extra="ignore")


ShopOrdersPage = CursorPage[ShopOrderViewOut]


# ----------------------------------------------------------------------
# External order DTO (старые схемы для части роутов)
# ----------------------------------------------------------------------


class ShopOrderExternalIn(BaseModel):
    sku: str
    quantity: int = Field(..., ge=1)
    pay_method: str = Field(
        ...,
        description="TON|USDT|... (в зависимости от реализации).",
    )


class ShopOrderPayloadOut(BaseModel):
    data: dict[str, Any] = Field(default_factory=dict)
    model_config = ConfigDict(extra="allow")


class ShopPayOut(BaseModel):
    data: dict[str, Any] = Field(default_factory=dict)
    model_config = ConfigDict(extra="allow")


class ShopOrderExternalOut(BaseModel):
    order: Any
    pay: Any
    model_config = ConfigDict(extra="allow")


class ShopOrderListOut(BaseModel):
    items: List[Any]
    next_cursor: Optional[str] = None
    model_config = ConfigDict(extra="allow")
