# -*- coding: utf-8 -*-
# backend/app/schemas/withdraw_schemas.py
# ----------------------------------------------------------------------
# Схемы вывода EFHC (Jetton): заявки, модерация, витрины.
# ----------------------------------------------------------------------

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Optional

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    condecimal,
    conint,
    constr,
    field_validator,
)

from backend.app.deps import d8
from backend.app.schemas.common_schemas import (
    CursorPage,
    OkMeta,
    StrictIn,
    d8_str,
)

WithdrawStatus = str

MemoStr140 = constr(strip_whitespace=True, max_length=140)
ReasonStr240 = constr(strip_whitespace=True, max_length=240)



def _is_lite_ton_address(addr: str) -> bool:
    """Мини-валидация TON-адреса без внешних зависимостей."""

    if not isinstance(addr, str) or not addr:
        return False
    if not (48 <= len(addr) <= 68):
        return False

    allowed = (
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        "abcdefghijklmnopqrstuvwxyz"
        "0123456789_-+="
    )
    return all(c in allowed for c in addr)


class WithdrawCreateIn(StrictIn):
    """Создание заявки на вывод EFHC (Idempotency-Key)."""

    amount_efhc: condecimal(
        gt=Decimal("0"),
        max_digits=30,
        decimal_places=10,
    ) = Field(
        ...,
        description="Сумма EFHC к выводу (>0). Округление вниз до 8.",
    )
    dest_ton_address: constr(
        strip_whitespace=True,
        min_length=48,
        max_length=68,
    ) = Field(
        ...,
        description="Целевой TON-адрес для перевода EFHC (Jetton).",
    )
    memo: Optional[MemoStr140] = Field(
        None,
        description="Необязательное примечание пользователя.",
    )
    client_nonce: Optional[constr(
        strip_whitespace=True,
        min_length=1,
        max_length=128,
    )] = Field(
        None,
        description="Доп. предохранитель, не заменяет Idempotency-Key.",
    )

    @field_validator("amount_efhc", mode="before")
    def _q8_amount(cls, v: Decimal) -> Decimal:
        return d8(v)

    @field_validator("dest_ton_address")
    def _check_addr(cls, v: str) -> str:
        if not _is_lite_ton_address(v):
            raise ValueError("Некорректный формат TON-адреса.")
        return v


class WithdrawPublicOut(BaseModel):
    """Публичная витрина заявки на вывод."""

    meta: OkMeta = Field(default_factory=OkMeta)
    id: int
    tg_id: int
    status: str

    amount_efhc: str
    dest_ton_address: str
    memo: Optional[str] = None

    tx_hash: Optional[str] = None
    fee_efhc: Optional[str] = None
    operator_tg_id: Optional[int] = None

    created_at: datetime
    updated_at: datetime

    @field_validator("amount_efhc", "fee_efhc", mode="before")
    def _q8_str(cls, v: Optional[Decimal]) -> Optional[str]:
        if v is None:
            return None
        return d8_str(v)

    model_config = ConfigDict(extra="ignore")


WithdrawListOut = CursorPage[WithdrawPublicOut]


class AdminWithdrawTakeIn(StrictIn):
    """Взять заявку в обработку (UNDER_REVIEW)."""

    operator_tg_id: int = Field(
        ...,
        description="tg_id оператора, взявшего в работу.",
    )


class AdminWithdrawDecisionIn(StrictIn):
    """Одобрить или отклонить заявку."""

    approved: bool = Field(
        ...,
        description="True - одобрить; False - отклонить.",
    )
    operator_tg_id: int = Field(..., description="tg_id оператора.")
    reason: Optional[ReasonStr240] = Field(
        None,
        description="Причина/комментарий.",
    )

class AdminWithdrawMarkPaidIn(StrictIn):
    """Отметить заявку как PAID (денежный POST: Idempotency-Key)."""

    operator_tg_id: int = Field(..., description="tg_id оператора.")
    tx_hash: constr(
        strip_whitespace=True,
        min_length=16,
        max_length=128,
    ) = Field(
        ...,
        description="Хэш Jetton-транзакции выплаты EFHC.",
    )
    fee_efhc: Optional[condecimal(
        ge=Decimal("0"),
        max_digits=30,
        decimal_places=10,
    )] = Field(
        None,
        description="Комиссия EFHC, если применима (>=0).",
    )
    admin_memo: Optional[ReasonStr240] = Field(
        None,
        description="Комментарий оператора/админа.",
    )
    client_nonce: Optional[constr(
        strip_whitespace=True,
        min_length=1,
        max_length=128,
    )] = Field(
        None,
        description="Доп. предохранитель идемпотентности.",
    )

    @field_validator("fee_efhc", mode="before")
    def _q8_fee(cls, v: Optional[Decimal]) -> Optional[Decimal]:
        return None if v is None else d8(v)

