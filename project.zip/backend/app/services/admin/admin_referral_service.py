# -*- coding: utf-8 -*-

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Any

from sqlalchemy import text
from sqlalchemy.engine import Result
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.core.config_core import get_settings
from backend.app.core.logging_core import get_logger
from backend.app.core.utils_core import format_decimal_str
from backend.app.core.utils_core import quantize_decimal
from backend.app.services.admin.admin_notifications import AdminNotifier
from backend.app.services.transactions_service import (
    credit_user_bonus_from_bank,
)

logger = get_logger(__name__)
S = get_settings()

SCHEMA_CORE: str = (
    getattr(S, "DB_SCHEMA_CORE", "efhc_core")
    or "efhc_core"
)
SCHEMA_REF: str = (
    getattr(S, "DB_SCHEMA_REFERRAL", "efhc_referral")
    or "efhc_referral"
)

_REF_DIRECT_DEFAULT = "0.1"


def _ref_direct_bonus_str() -> str:
    v = getattr(S, "REFERRAL_DIRECT_BONUS_EFHC", None)
    if v is None:
        v = getattr(
            S,
            "REF_BONUS_ON_ACTIVATION_EFHC",
            _REF_DIRECT_DEFAULT,
        )
    return str(v)


REF_DIRECT_BONUS: Decimal = quantize_decimal(
    _ref_direct_bonus_str(),
    8,
    "DOWN",
)

REF_THRESHOLDS: list[tuple[int, Decimal]] = [
    (int(k), quantize_decimal(v, 8, "DOWN"))
    for (k, v) in S.parsed_ref_bonus_thresholds()
]


class ReferralError(Exception):
    pass


class ReferralConfigError(ReferralError):
    pass


class ReferralDataError(ReferralError):
    pass


@dataclass
class DirectReferralResult:
    paid: bool
    referrer_id: int
    invitee_id: int
    amount_bonus: str
    idempotency_key: str


@dataclass
class ThresholdsReferralResult:
    referrer_id: int
    thresholds_paid: list[int]


class AdminReferralService:
    @staticmethod
    async def award_direct_on_first_panel(
        db: AsyncSession,
        *,
        referrer_id: int,
        invitee_id: int,
    ) -> DirectReferralResult:
        """Award one-time bonus on invitee's first panel purchase."""

        if REF_DIRECT_BONUS <= 0:
            raise ReferralConfigError(
                "REF_DIRECT_BONUS_EFHC must be > 0"
            )

        referrer_id = int(referrer_id)
        invitee_id = int(invitee_id)
        idem = f"ref:direct:{referrer_id}:{invitee_id}"

        q = text(
            "\n".join(
                [
                    f"INSERT INTO {SCHEMA_REF}.ref_first_activation (",
                    "  referrer_id, invitee_id, created_at",
                    ") VALUES (:",
                    "  rid, :iid, NOW() AT TIME ZONE 'UTC'",
                    ")",
                    "ON CONFLICT (invitee_id) DO NOTHING",
                    "RETURNING invitee_id",
                ]
            )
        )
        r: Result = await db.execute(
            q,
            {"rid": referrer_id, "iid": invitee_id},
        )
        inserted = r.fetchone()
        if not inserted:
            return DirectReferralResult(
                paid=False,
                referrer_id=referrer_id,
                invitee_id=invitee_id,
                amount_bonus=format_decimal_str(REF_DIRECT_BONUS, 8),
                idempotency_key=idem,
            )

        amount = quantize_decimal(REF_DIRECT_BONUS, 8, "DOWN")

        try:
            await credit_user_bonus_from_bank(
                db,
                tg_id=referrer_id,
                amount=amount,
                reason="ref_direct_bonus",
                idempotency_key=idem,
                meta={
                    "kind": "ref_direct",
                    "invitee_id": invitee_id,
                },
            )
        except Exception as e:
            logger.error(
                "Referrals: direct bonus failed rid=%s iid=%s: %s",
                referrer_id,
                invitee_id,
                e,
            )
            raise

        try:
            msg = (
                "👥 Прямой реф-бонус\n"
                f"Реферер: <code>{referrer_id}</code>\n"
                f"Реферал: <code>{invitee_id}</code>\n"
                f"Бонус: <b>{format_decimal_str(amount, 8)} EFHC "
                "(bonus)</b>"
            )
            payload = (
                f'{{"referrer_id":{referrer_id},'
                f'"invitee_id":{invitee_id},'
                f'"amount":"{format_decimal_str(amount, 8)}"}}'
            )
            await AdminNotifier.notify_generic(
                db,
                event="REF_DIRECT_PAID",
                message=msg,
                payload_json=payload,
                send_telegram=True,
            )
        except Exception as e:
            logger.warning("Referrals: notify failed: %s", e)

        return DirectReferralResult(
            paid=True,
            referrer_id=referrer_id,
            invitee_id=invitee_id,
            amount_bonus=format_decimal_str(amount, 8),
            idempotency_key=idem,
        )

    @staticmethod
    async def award_threshold_bonuses(
        db: AsyncSession,
        *,
        referrer_id: int,
    ) -> ThresholdsReferralResult:
        """Award threshold bonuses to bonus balance via the bank."""

        referrer_id = int(referrer_id)
        if not REF_THRESHOLDS:
            return ThresholdsReferralResult(
                referrer_id=referrer_id,
                thresholds_paid=[],
            )

        q_total = text(
            "\n".join(
                [
                    "SELECT COUNT(1) AS cnt",
                    f"FROM {SCHEMA_REF}.ref_links",
                    "WHERE referrer_id = :rid",
                ]
            )
        )
        r_total: Result = await db.execute(
            q_total,
            {"rid": referrer_id},
        )
        total_row = r_total.fetchone()
        total_refs = int(getattr(total_row, "cnt", 0) or 0)
        if total_refs <= 0:
            return ThresholdsReferralResult(
                referrer_id=referrer_id,
                thresholds_paid=[],
            )

        q_paid = text(
            "\n".join(
                [
                    "SELECT threshold",
                    f"FROM {SCHEMA_REF}.ref_threshold_rewards",
                    "WHERE referrer_id = :rid",
                ]
            )
        )
        r_paid: Result = await db.execute(q_paid, {"rid": referrer_id})
        paid_rows = r_paid.fetchall()
        already_paid: set[int] = {
            int(getattr(row, "threshold")) for row in paid_rows
        }

        newly_paid: list[int] = []

        for threshold, bonus in REF_THRESHOLDS:
            thr = int(threshold)
            if total_refs < thr:
                continue
            if thr in already_paid:
                continue

            bonus_q = quantize_decimal(bonus, 8, "DOWN")
            if bonus_q <= 0:
                logger.warning(
                    "Referrals: skip non-positive bonus rid=%s thr=%s",
                    referrer_id,
                    thr,
                )
                continue

            idem = f"ref:threshold:{referrer_id}:{thr}"
            try:
                await credit_user_bonus_from_bank(
                    db,
                    tg_id=referrer_id,
                    amount=bonus_q,
                    reason="ref_threshold_bonus",
                    idempotency_key=idem,
                    meta={
                        "kind": "ref_threshold",
                        "threshold": thr,
                        "total_refs": total_refs,
                    },
                )
            except Exception as e:
                logger.error(
                    "Referrals: thr bonus failed rid=%s thr=%s: %s",
                    referrer_id,
                    thr,
                    e,
                )
                continue

            q_ins = text(
                "\n".join(
                    [
                        f"INSERT INTO {SCHEMA_REF}.",
                        "ref_threshold_rewards ",
                        "(",
                        "  referrer_id, threshold, paid_at",
                        ") VALUES (:",
                        "  rid, :thr, NOW() AT TIME ZONE 'UTC'",
                        ")",
                        "ON CONFLICT (referrer_id, threshold)",
                        "DO NOTHING",
                    ]
                )
            )
            try:
                await db.execute(
                    q_ins,
                    {"rid": referrer_id, "thr": thr},
                )
            except Exception as e:
                logger.error(
                    "Referrals: record failed rid=%s thr=%s: %s",
                    referrer_id,
                    thr,
                    e,
                )
                newly_paid.append(thr)
                continue

            newly_paid.append(thr)

            try:
                await AdminNotifier.notify_ref_level(
                    db,
                    referrer_id=referrer_id,
                    threshold=thr,
                    bonus_efhc=format_decimal_str(bonus_q, 8),
                )
            except Exception as e:
                logger.warning("Referrals: notify level failed: %s", e)

        return ThresholdsReferralResult(
            referrer_id=referrer_id,
            thresholds_paid=newly_paid,
        )


__all__ = [
    "ReferralError",
    "ReferralConfigError",
    "ReferralDataError",
    "DirectReferralResult",
    "ThresholdsReferralResult",
    "AdminReferralService",
]
