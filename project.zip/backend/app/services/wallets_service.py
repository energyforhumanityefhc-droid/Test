# -*- coding: utf-8 -*-
"""Wallet bindings service for TonConnect.

SSOT rules:
- User identifier is tg_id only (server-auth).
- wallet_connected := at least one active wallet binding.
- /wallets/connect requires Idempotency-Key and is idempotent by
  (tg_id, normalized_address).

This module is infrastructure for wallet bindings only.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List, Optional

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.core.config_core import get_settings
from backend.app.core.logging_core import get_logger
from backend.app.lib.time import utcnow


logger = get_logger(__name__)
settings = get_settings()
CORE_SCHEMA: str = getattr(settings, "DB_SCHEMA_CORE", "efhc_core")


class WalletConflict(Exception):
    pass


class InvalidWalletAddress(Exception):
    pass


_ADDR_RE = re.compile(r"^[A-Za-z0-9_\-]{20,128}$")


def normalize_wallet_address(raw: str) -> str:
    """Normalize a TON address string.

    We avoid aggressive transformations because base64 strings are
    case-sensitive. Validation is conservative.
    """
    addr = str(raw or "").strip()
    if not addr:
        raise InvalidWalletAddress("INVALID_WALLET_ADDRESS")
    if not _ADDR_RE.match(addr):
        raise InvalidWalletAddress("INVALID_WALLET_ADDRESS")
    return addr


@dataclass(slots=True)
class WalletBindingOut:
    id: int
    wallet_address: str
    wallet_app: Optional[str]
    is_primary: bool
    is_active: bool
    created_at: str


async def list_wallets(
    db: AsyncSession,
    *,
    tg_id: int,
) -> List[WalletBindingOut]:
    q = text(
        f"""
        SELECT id,
               wallet_address,
               wallet_app,
               is_primary,
               is_active,
               created_at
          FROM {CORE_SCHEMA}.wallet_bindings
         WHERE tg_id = :tg_id
         ORDER BY is_primary DESC, id DESC
        """
    )
    rows = (await db.execute(q, {"tg_id": tg_id})).mappings().all()
    out: List[WalletBindingOut] = []
    for r in rows:
        out.append(
            WalletBindingOut(
                id=int(r["id"]),
                wallet_address=str(r["wallet_address"]),
                wallet_app=(
                    str(r["wallet_app"]) if r["wallet_app"] else None
                ),
                is_primary=bool(r["is_primary"]),
                is_active=bool(r["is_active"]),
                created_at=str(r["created_at"]),
            )
        )
    return out


async def has_active_wallet(
    db: AsyncSession,
    *,
    tg_id: int,
) -> bool:
    q = text(
        f"""
        SELECT 1
          FROM {CORE_SCHEMA}.wallet_bindings
         WHERE tg_id = :tg_id AND is_active = true
         LIMIT 1
        """
    )
    return bool((await db.execute(q, {"tg_id": tg_id})).first())


async def connect_wallet(
    db: AsyncSession,
    *,
    tg_id: int,
    address: str,
    wallet_app: Optional[str],
    idempotency_key: str,
) -> dict:
    logger.info(
        "wallet.connect attempt",
        extra={
            "audit_schema_version": "v1",
            "tg_id": tg_id,
            "event": "wallet_connect",
            "result": "attempt",
        },
    )

    if not idempotency_key:
        raise ValueError("IDEMPOTENCY_REQUIRED")

    q_idk = text(
        f"""
        SELECT wallet_id, wallet_address
          FROM {CORE_SCHEMA}.wallet_connect_idempotency
         WHERE tg_id = :tg_id AND idempotency_key = :ik
         LIMIT 1
        """
    )
    idk_row = (
        await db.execute(q_idk, {"tg_id": tg_id, "ik": idempotency_key})
    ).mappings().first()
    if idk_row:
        logger.info(
            "wallet.connect replay",
            extra={
                "audit_schema_version": "v1",
                "tg_id": tg_id,
                "event": "wallet_connect",
                "result": "replay",
            },
        )
        return {
            "wallet_id": int(idk_row["wallet_id"]),
            "wallet_address": str(idk_row["wallet_address"]),
            "is_connected": True,
        }

    addr = normalize_wallet_address(address)

    q_owner = text(
        f"""
        SELECT tg_id
          FROM {CORE_SCHEMA}.wallet_bindings
         WHERE wallet_address = :addr
         LIMIT 1
        """
    )
    owner = (await db.execute(q_owner, {"addr": addr})).first()
    if owner and int(owner[0]) != int(tg_id):
        logger.info(
            "wallet.connect conflict",
            extra={
                "audit_schema_version": "v1",
                "tg_id": tg_id,
                "event": "wallet_connect",
                "result": "conflict",
            },
        )
        raise WalletConflict("WALLET_CONFLICT")

    q_find = text(
        f"""
        SELECT id, is_active
          FROM {CORE_SCHEMA}.wallet_bindings
         WHERE wallet_address = :addr AND tg_id = :tg_id
         LIMIT 1
        """
    )
    ex = (await db.execute(q_find, {"addr": addr, "tg_id": tg_id}))
    row = ex.mappings().first()

    now = utcnow()

    if row:
        wallet_id = int(row["id"])
        await db.execute(
            text(
                f"""
                UPDATE {CORE_SCHEMA}.wallet_bindings
                   SET is_active = true,
                       wallet_app = COALESCE(:wallet_app, wallet_app),
                       updated_at = :now
                 WHERE id = :id
                """
            ),
            {
                "id": wallet_id,
                "wallet_app": wallet_app,
                "now": now,
            },
        )
        await _save_connect_idempotency(
            db,
            tg_id=tg_id,
            idempotency_key=idempotency_key,
            wallet_id=wallet_id,
            wallet_address=addr,
        )
        await db.commit()
        return {
            "wallet_id": wallet_id,
            "wallet_address": addr,
            "is_connected": True,
        }

    ins = text(
        f"""
        INSERT INTO {CORE_SCHEMA}.wallet_bindings
            (tg_id, wallet_address, wallet_app,
             is_primary, is_active, created_at, updated_at)
        VALUES
            (:tg_id, :addr, :wallet_app,
             false, true, :now, :now)
        RETURNING id
        """
    )
    wallet_id = int(
        (await db.execute(
            ins,
            {
                "tg_id": tg_id,
                "addr": addr,
                "wallet_app": wallet_app,
                "now": now,
            },
        )).scalar_one()
    )

    # Make primary if none.
    q_has = text(
        f"""
        SELECT 1
          FROM {CORE_SCHEMA}.wallet_bindings
         WHERE tg_id = :tg_id AND is_primary = true AND is_active = true
         LIMIT 1
        """
    )
    if not (await db.execute(q_has, {"tg_id": tg_id})).first():
        await _make_primary_tx(db, tg_id=tg_id, wallet_id=wallet_id)

    await _save_connect_idempotency(
        db,
        tg_id=tg_id,
        idempotency_key=idempotency_key,
        wallet_id=wallet_id,
        wallet_address=addr,
    )

    await db.commit()
    logger.info(
        "wallet.connect ok",
        extra={
            "audit_schema_version": "v1",
            "tg_id": tg_id,
            "event": "wallet_connect",
            "result": "ok",
        },
    )
    return {
        "wallet_id": wallet_id,
        "wallet_address": addr,
        "is_connected": True,
    }


async def _save_connect_idempotency(
    db: AsyncSession,
    *,
    tg_id: int,
    idempotency_key: str,
    wallet_id: int,
    wallet_address: str,
) -> None:
    now = utcnow()
    await db.execute(
        text(
            f"""
            INSERT INTO {CORE_SCHEMA}.wallet_connect_idempotency
                (tg_id, idempotency_key, wallet_id, wallet_address,
                 created_at)
            VALUES
                (:tg_id, :ik, :wallet_id, :addr, :now)
            ON CONFLICT (tg_id, idempotency_key) DO NOTHING
            """
        ),
        {
            "tg_id": tg_id,
            "ik": idempotency_key,
            "wallet_id": wallet_id,
            "addr": wallet_address,
            "now": now,
        },
    )


async def make_primary(
    db: AsyncSession,
    *,
    tg_id: int,
    wallet_id: int,
) -> None:
    await _make_primary_tx(db, tg_id=tg_id, wallet_id=wallet_id)
    await db.commit()
    logger.info(
        "wallet.make_primary",
        extra={
            "audit_schema_version": "v1",
            "tg_id": tg_id,
            "event": "wallet_make_primary",
            "result": "ok",
        },
    )


async def deactivate_wallet(
    db: AsyncSession,
    *,
    tg_id: int,
    wallet_id: int,
) -> None:
    await db.execute(
        text(
            f"""
            UPDATE {CORE_SCHEMA}.wallet_bindings
               SET is_active = false,
                   is_primary = false,
                   updated_at = :now
             WHERE id = :id AND tg_id = :tg_id
            """
        ),
        {"id": wallet_id, "tg_id": tg_id, "now": utcnow()},
    )
    await db.commit()
    logger.info(
        "wallet.deactivate",
        extra={
            "audit_schema_version": "v1",
            "tg_id": tg_id,
            "event": "wallet_deactivate",
            "result": "ok",
        },
    )


async def _make_primary_tx(
    db: AsyncSession,
    *,
    tg_id: int,
    wallet_id: int,
) -> None:
    now = utcnow()
    await db.execute(
        text(
            f"""
            UPDATE {CORE_SCHEMA}.wallet_bindings
               SET is_primary = false,
                   updated_at = :now
             WHERE tg_id = :tg_id
            """
        ),
        {"tg_id": tg_id, "now": now},
    )
    await db.execute(
        text(
            f"""
            UPDATE {CORE_SCHEMA}.wallet_bindings
               SET is_primary = true,
                   is_active = true,
                   updated_at = :now
             WHERE id = :id AND tg_id = :tg_id
            """
        ),
        {"id": wallet_id, "tg_id": tg_id, "now": now},
    )
