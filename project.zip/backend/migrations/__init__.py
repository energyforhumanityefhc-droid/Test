"""Package marker.

Этот файл закрепляет пакетность директории по канону.
См. ARCHITECTURAL_LOCKS.md.
"""


__all__ = []
