# Admin Panel Spec

Модули: Dashboard, Withdrawals, Users, Bank, Shop, Tasks, Prizes, Ads,
Logs.

Требования:
- RBAC (admin key / whitelist)
- Поиск/фильтрация
- Приоритет VIP заявок
