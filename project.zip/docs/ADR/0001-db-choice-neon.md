# ADR-0001: Выбор Postgres (Neon)

## Status
Accepted.

## Context
EFHC Bot требует:
- транзакционности для денежных операций (bank, withdraw, shop),
- строгих инвариантов и аудита,
- масштабирования чтений,
- удобной миграции схемы.

## Decision
Используем **PostgreSQL** (управляемый сервис Neon) как основную БД.

## Rationale
- ACID транзакции для финансовых контуров.
- Удобная модель схем (`efhc_core`) и миграции.
- SQL — прозрачный аудит и расследование инцидентов.
- Совместимость с SQLAlchemy + Alembic.

## Consequences
### Positive
- Чёткие транзакционные границы.
- Простая аналитика/сверка через SQL.
- Возможность enforced-инвариантов (constraints/indices).

### Negative
- Нужно следить за миграциями и версионированием схемы.
- Нужно планировать индексы на hot-path таблицах.

## Operational Notes (SSOT)
### Checks
- `python -m compileall backend ops`
- `pytest`
- `GET /api/system/health/db-schema`

### Rollback
- Откат миграции только через Alembic.
- Прямые SQL правки в проде запрещены (кроме аварийного чтения).
