import type { AppProps } from "next/app";
import NextApp from "next/app";
import "../styles/globals.css";
import React, { useEffect, useState } from "react";
import { QueryClientProvider } from "@tanstack/react-query";
import { TonConnectUIProvider } from "@tonconnect/ui-react";
import { loadDict, type Dict, type Lang } from "../lib/i18n";
import {
  applyTelegramCssVars,
  getTelegramColorScheme,
  getTelegramUser,
  onTelegramThemeChanged,
  onTelegramViewportChanged,
  setTelegramChromeColors,
  tgReady,
} from "../lib/telegram";
import { Layout } from "../components/Layout";
import { ErrorBoundary } from "../components/ErrorBoundary";
import { useSnapshot } from "../hooks/useSnapshot";
import {
  DEFAULT_SETTINGS,
  loadSettings,
  saveSettings,
  type UserSettings,
} from "../lib/settings";
import { isAdminTgId } from "../lib/admin";
import { createEfhcQueryClient } from "../lib/queryClient";
import {
  fetchMySkins,
  getSkinKey,
  getShopSkinBgUrl,
  getUserLevel,
  getUserSkin,
} from "../lib/skins";

export default function EfhcApp({ Component, pageProps }: AppProps) {
  const [queryClient] = useState(() => createEfhcQueryClient());

  const [tcManifestUrl, setTcManifestUrl] = useState<string>(
    "http://localhost/tonconnect-manifest.json",
  );

  const [settings, setSettings] =
    useState<UserSettings>(DEFAULT_SETTINGS);
  const [lang, setLang] = useState<Lang>("en");
  const [uiDict, setUiDict] = useState<Dict>({});
  const [ruDict, setRuDict] = useState<Dict>({});
  const [descDict, setDescDict] = useState<Dict>({});

  const [tg_id, setTgId] = useState<number | null>(null);
  const [telegramName, setTelegramName] = useState<string>("");
  const [telegramAvatarUrl, setTelegramAvatarUrl] =
    useState<string | null>(null);

  const applyTheme = (mode: UserSettings["theme_mode"]) => {
    if (typeof document === "undefined") return;
    const tg = getTelegramColorScheme() || "dark";
    const eff = mode === "auto" ? tg : mode;
    document.documentElement.dataset.theme = eff;
    // Keep Telegram chrome aligned with Telegram tokens (best effort).
    // Telegram API accepts either theme keywords (e.g. "bg_color")
    // or a color string. Prefer computed token values if present.
    if (typeof window !== "undefined") {
      const styles = getComputedStyle(document.documentElement);
      const bg = styles.getPropertyValue("--tg-bg").trim();
      const sec = styles.getPropertyValue("--tg-secondary-bg").trim();
      const bgColor = bg || "bg_color";
      const secColor = sec || bg || "bg_color";
      setTelegramChromeColors(bgColor, secColor);
    }
};

  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      const u = new URL(
        "/tonconnect-manifest.json",
        window.location.origin,
      );
      setTcManifestUrl(u.toString());
    } catch {
      // keep fallback
    }
    tgReady();
    applyTelegramCssVars();
    const u = getTelegramUser();
    setTgId(u?.id ?? null);
    setTelegramName(u?.username || u?.first_name || "");
    setTelegramAvatarUrl((u as any)?.photo_url || null);

    const s = loadSettings();
    setSettings(s);
    setLang(s.lang);

    // Apply theme immediately and then subscribe
    // to Telegram theme changes.
    applyTheme(s.theme_mode);
    const off = onTelegramThemeChanged(() => {
      // Use latest persisted settings to avoid stale closure.
      const latest = loadSettings();
      applyTelegramCssVars();
      applyTheme(latest.theme_mode);
    });

    const offVp = onTelegramViewportChanged(() => {
      applyTelegramCssVars();
    });

    return () => {
      off();
      offVp();
    };
  }, []);

  useEffect(() => {
    // Persist settings.
    saveSettings(settings);
    setLang(settings.lang);
    applyTheme(settings.theme_mode);
  }, [settings]);

  useEffect(() => {
    if (typeof document === "undefined") return;
    if (settings.reduce_motion) {
      document.documentElement.dataset.reduceMotion = "1";
      return;
    }
    delete (document.documentElement.dataset as any).reduceMotion;
  }, [settings.reduce_motion]);

  useEffect(() => {
    // UI dictionary is always English.
    loadDict("en").then(setUiDict).catch(() => setUiDict({}));
    loadDict("ru").then(setRuDict).catch(() => setRuDict({}));
  }, []);

  useEffect(() => {
    // Descriptions dictionary depends on selected language.
    loadDict(lang).then(setDescDict).catch(() => setDescDict({}));
  }, [lang]);

  // Snapshot is cached via React Query.
  const { snap } = useSnapshot(tg_id);

  const isVip = Boolean(snap?.profile?.is_vip);
  // Admin entry is shown by tg_id allowlist (SSOT via
  // NEXT_PUBLIC_ADMIN_TELEGRAM_IDS).
  // Backend must still enforce admin-only access on /admin/*.
  const isAdmin = isAdminTgId(tg_id);

  const [shopSkinBgUrl, setShopSkinBgUrl] =
    useState<string | null>(null);

  useEffect(() => {
    if (typeof document === "undefined") return;
    const total = snap?.profile?.total_generated_kwh || "0";
    const level = getUserLevel(total);
    const skin = getUserSkin(level);
    const key = getSkinKey(level);
    document.documentElement.dataset.skin = key;
    document.documentElement.style.setProperty(
      "--gold",
      skin.accent_1,
    );
    document.documentElement.style.setProperty(
      "--gold-2",
      skin.accent_2,
    );
    document.documentElement.style.setProperty(
      "--energy",
      skin.energy,
    );
  }, [snap?.profile?.total_generated_kwh]);

  useEffect(() => {
    if (!tg_id) {
      setShopSkinBgUrl(null);
      return;
    }

    let cancelled = false;

    const load = async () => {
      try {
        const my = await fetchMySkins();
        const url = getShopSkinBgUrl(Number(my.active_skin_id));
        if (!cancelled) setShopSkinBgUrl(url);
      } catch {
        if (!cancelled) setShopSkinBgUrl(null);
      }
    };

    const onChanged = () => {
      load().catch(() => undefined);
    };

    load().catch(() => undefined);
    if (typeof window !== "undefined") {
      window.addEventListener(
        "efhc_shop_skin_changed",
        onChanged,
      );
    }

    return () => {
      cancelled = true;
      if (typeof window !== "undefined") {
        window.removeEventListener(
          "efhc_shop_skin_changed",
          onChanged,
        );
      }
    };
  }, [tg_id]);

  useEffect(() => {
    if (typeof document === "undefined") return;
    const d = document.documentElement;
    if (!shopSkinBgUrl) {
      d.style.removeProperty("--shop-skin-bg");
      delete (d.dataset as any).shopSkin;
      return;
    }
    d.style.setProperty("--shop-skin-bg", `url(${shopSkinBgUrl})`);
    (d.dataset as any).shopSkin = "1";
  }, [shopSkinBgUrl]);

  return (
    <TonConnectUIProvider manifestUrl={tcManifestUrl}>
      <QueryClientProvider client={queryClient}>
        <Layout
          lang={lang}
          uiDict={uiDict}
          ruDict={ruDict}
          descDict={descDict}
          tg_id={tg_id}
          telegramName={telegramName}
          telegramAvatarUrl={telegramAvatarUrl}
          snapshot={snap}
          isVip={isVip}
          isAdmin={isAdmin}
          settings={settings}
          setLang={(l) => setSettings({ ...settings, lang: l })}
          setSettings={setSettings}
        >
          <ErrorBoundary title="EFHC Mini App">
            <Component
              {...pageProps}
              tg_id={tg_id}
              snap={snap}
              settings={settings}
              setSettings={setSettings}
            />
          </ErrorBoundary>
        </Layout>
      </QueryClientProvider>
    </TonConnectUIProvider>
  );
}

// Disable automatic static optimization (Telegram WebApp is runtime-dynamic)
EfhcApp.getInitialProps = async (appContext: any) => {
  const appProps = await NextApp.getInitialProps(appContext);
  return { ...appProps };
};
