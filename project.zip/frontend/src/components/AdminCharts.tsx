import React from "react";
import { Card } from "./ui/Card";

export function AdminCharts() {
  return <Card title="Admin Charts">Charts</Card>;
}
