import React from "react";
import { Card } from "./ui/Card";

export function EnergyGauge(
  props: { availableKwh: string; totalKwh: string },
) {
  return (
    <Card title="Energy">
      <div className="mt-2 text-sm text-zinc-400">
        Total generated kWh
      </div>
      <div className="text-2xl font-bold">{props.availableKwh}</div>
      <div className="mt-2 text-sm text-zinc-400">
        Total generated kWh
      </div>
      <div className="text-xl">{props.totalKwh}</div>
    </Card>
  );
}
