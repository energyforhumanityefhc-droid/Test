import React from "react";

type Props = React.PropsWithChildren<{ title?: string }>;

type State = { hasError: boolean; error?: unknown };

export class ErrorBoundary extends React.Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(error: unknown): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: unknown) {
    // Keep it minimal: no external reporting here.
    // Telegram clients can be strict about console noise.
    try {
      // eslint-disable-next-line no-console
      console.error("EFHC UI error", error);
    } catch {
      // ignore
    }
  }

  render() {
    if (!this.state.hasError) return this.props.children;

    const title = this.props.title || "Something went wrong";
    const raw = this.state.error as any;
    const detail = String(raw?.message || raw || "Unexpected UI error");

    return (
      <div className="min-h-[60vh] flex items-center"
        style={{ justifyContent: "center" }}
      >
        <div className="max-w-md w-full efhc-card p-5 grid gap-3">
          <div className="text-lg font-bold">{title}</div>
          <div className="text-sm text-zinc-300 whitespace-pre-wrap">
            {detail}
          </div>

          <button
            className="efhc-btn-primary rounded-2xl px-4 py-2 border"
            onClick={() => {
              this.setState({ hasError: false, error: undefined });
              try {
                window.location.reload();
              } catch {
                // ignore
              }
            }}
          >
            Reload
          </button>
        </div>
      </div>
    );
  }
}
