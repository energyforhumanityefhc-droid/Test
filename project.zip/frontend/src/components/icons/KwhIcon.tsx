import React from 'react';

export function KwhIcon(
  { size = 16, className = '' }: { size?: number; className?: string },
) {
  // Universal electricity symbol: lightning in a circle
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <circle
        cx="12"
        cy="12"
        r="10"
        stroke="currentColor"
        strokeWidth="2"
      />
      <path
        d="M13 2L7 13h5l-1 9 6-11h-5l1-9z"
        fill="currentColor"
      />
    </svg>
  );
}
