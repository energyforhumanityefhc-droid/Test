import React from "react";

export function Card(
  props: React.PropsWithChildren<{
    title?: string;
    highlight?: "energy" | "none";
    className?: string;
  }>,
) {
  const hl = props.highlight === "energy" ? "efhc-border-energy" : "";
  return (
    <div className={`efhc-card p-4 ${hl} ${props.className || ""}`}>
      {props.title ? (
        <div className="text-lg font-semibold mb-2">
          {props.title}
        </div>
      ) : null}
      {props.children}
    </div>
  );
}
