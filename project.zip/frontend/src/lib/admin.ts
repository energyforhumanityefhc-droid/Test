/**
 * Admin UI visibility is controlled purely by tg_id allowlist.
 *
 * IMPORTANT:
 * - This is only for showing/hiding the admin entry in UI.
 * - Backend must always enforce admin-only access on /admin/* routes.
 * - SSOT: set NEXT_PUBLIC_ADMIN_TG_IDS="362746228,...." in env.
 */

export function getAdminTgIds(): number[] {
  const raw = (process.env.NEXT_PUBLIC_ADMIN_TG_IDS || "").trim();
  if (!raw) return [];
  return raw
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)
    .map((s) => Number(s))
    .filter((n) => Number.isFinite(n) && n > 0);
}

export function isAdminTgId(tg_id: number | null): boolean {
  if (!tg_id) return false;
  const ids = getAdminTgIds();
  return ids.includes(tg_id);
}
