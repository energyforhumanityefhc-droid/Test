export type HttpMethod = "GET" | "POST" | "PUT" | "PATCH" | "DELETE";

export function getApiBase(): string {
  // Same-origin by default. If you proxy /api to backend,
  // keep it empty.
  return "";
}

export type ApiRequestOptions = {
  body?: unknown;
  idempotencyKey?: string;
  headers?: Record<string, string>;
  // Prefer request tracing for incident debugging.
  requestId?: string;
};

export async function apiRequest<T>(
  path: string,
  method: HttpMethod,
  opts: ApiRequestOptions = {},
): Promise<T> {
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...(opts.headers || {}),
  };

  // Telegram WebApp auth (preferred over passing tg_id in query/body).
  try {
    const initData = (globalThis as any)?.Telegram?.WebApp?.initData;
    if (
      initData &&
      typeof initData === "string" &&
      initData.length > 0
    ) {
      headers["X-Telegram-Init-Data"] = initData;
    } else {
      // Dev fallback: if initData is missing, try to pass tg_id header.
      // Backend must allow it explicitly via
      // ALLOW_INSECURE_USER_HEADERS.
      const unsafe =
        (globalThis as any)?.Telegram?.WebApp?.initDataUnsafe;
      const tg_id = unsafe?.user?.id;
      if (tg_id) headers["X-Telegram-User-Id"] = String(tg_id);
    }
  } catch {
    // ignore
  }

  if (opts.requestId) headers["X-Request-ID"] = String(opts.requestId);
  if (opts.idempotencyKey) {
    headers["Idempotency-Key"] = String(opts.idempotencyKey);
  }

  // Admin headers (если используется админ-доступ через токен).
  // В публичном контуре запрещены user_id
  // и любые public userId headers.
  try {
    const aid =
      (globalThis as any)?.localStorage?.getItem?.(
        "EFHC_ADMIN_ID",
      );
    const atok =
      (globalThis as any)?.localStorage?.getItem?.(
        "EFHC_ADMIN_TOKEN",
      );
    if (aid) headers["X-Admin-Id"] = String(aid);
    if (atok) headers["X-Admin-Token"] = String(atok);
  } catch {
    // ignore
  }

  const res = await fetch(getApiBase() + path, {
    method,
    headers,
    body:
      opts.body !== undefined
        ? JSON.stringify(opts.body)
        : undefined,
    credentials: "include",
  });

  const contentType = res.headers.get("content-type") || "";
  const isJson = contentType.includes("application/json");

  if (!res.ok) {
    const txt = isJson ?
      JSON.stringify(await res.json().catch(() => ({})))
      : await res.text().catch(() => "");
    throw new Error(`HTTP ${res.status}: ${txt}`);
  }

  if (isJson) return (await res.json()) as T;
  return undefined as T;
}
