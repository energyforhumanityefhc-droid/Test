import React, { useEffect, useState } from "react";
import Link from "next/link";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { useT } from "../../hooks/useT";
import { apiRequest } from "../../lib/api";

function newIdk(prefix: string) {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const c: any = globalThis.crypto;
  const uuid = c?.randomUUID ?
    c.randomUUID()
    : `${Date.now()}-${Math.random()}`;
  return `${prefix}:${uuid}`;
}

export default function AdminShopPage() {
  const t = useT();
  const [orders, setOrders] = useState<any[]>([]);
  const [nextCursor, setNextCursor] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function load(cursor?: string | null) {
    setLoading(true);
    setError(null);
    try {
      const qs = new URLSearchParams();
      qs.set("limit", "50");
      if (cursor) qs.set("cursor", cursor);
      const res = await apiRequest<any>(
        `/admin/shop/orders?${qs.toString()}`,
        "GET",
      );
      setOrders(res?.items || []);
      setNextCursor(res?.next_cursor || null);
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  async function setPrice() {
    const code = prompt(
      t("admin.item_code_prompt") || "Item code",
    )?.trim();
    if (!code) return;
    const priceEfhc = prompt(
      t("admin.price_efhc_prompt") || "price_efhc (optional)",
    )?.trim();
    const priceTon = prompt(
      t("admin.price_ton_prompt") || "price_ton (optional)",
    )?.trim();
    const priceUsdt = prompt(
      t("admin.price_usdt_prompt") || "price_usdt (optional)",
    )?.trim();
    const isActive = prompt(
      t("admin.is_active_prompt") ||
        "is_active true/false (optional)",
    )?.trim();

    const body: any = { code };
    if (priceEfhc) body.price_efhc = priceEfhc;
    if (priceTon) body.price_ton = priceTon;
    if (priceUsdt) body.price_usdt = priceUsdt;
    if (isActive === "true" || isActive === "false") {
      body.is_active = isActive === "true";
    }

    setLoading(true);
    setError(null);
    try {
      await apiRequest<any>(
        "/admin/shop/items/set-price",
        "POST",
        {
          idempotencyKey: newIdk(`admin-shop-set-price-${code}`),
          body,
        },
      );
      await load();
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  return (
    <div className="grid gap-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">{t("admin.shop")}</h1>
        <Link href="/admin">
          <Button variant="secondary">
            {t("admin.back")}
          </Button>
        </Link>
      </div>

      <Card title={t("admin.shop_orders")}>
        <div className="flex flex-wrap items-center gap-2 mb-3">
          <Button
            variant="secondary"
            onClick={() => load()}
            disabled={loading}
          >
            {loading ? t("common.loading") : t("common.refresh")}
          </Button>
          <Button
            variant="secondary"
            onClick={setPrice}
            disabled={loading}
          >
            {t("admin.set_price")}
          </Button>
          {nextCursor ? (
            <Button
              variant="secondary"
              onClick={() => load(nextCursor)}
              disabled={loading}
            >
              {t("common.next")}
            </Button>
          ) : null}
        </div>
        {error ? (
          <div className="text-sm text-[color:var(--tg-link)] mb-2">
          {error}
        </div>
        ) : null}

        <div className="overflow-auto">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="text-left border-b">
                <th className="py-2 pr-3">ID</th>
                <th className="py-2 pr-3">{t("admin.user")}</th>
                <th className="py-2 pr-3">{t("admin.item")}</th>
                <th className="py-2 pr-3">{t("admin.status")}</th>
                <th className="py-2 pr-3">{t("admin.payment")}</th>
                <th className="py-2 pr-3">{t("admin.created")}</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((o) => (
                <tr key={o.id} className="border-b">
                  <td className="py-2 pr-3">{o.id}</td>
                  <td className="py-2 pr-3">
                    {o.tg_id || ""}
                  </td>
                  <td className="py-2 pr-3">
                    {o.item_code || o.item_id}
                  </td>
                  <td className="py-2 pr-3">{o.status}</td>
                  <td className="py-2 pr-3">{o.payment_method}</td>
                  <td className="py-2 pr-3">{o.created_at}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}