import React, { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { useT } from "../../hooks/useT";
import { apiRequest } from "../../lib/api";
import { format8 } from "../../lib/format";

type Withdrawal = {
  id: number;
  tg_id: number;
  amount_efhc: string;
  status: string;
  external_address?: string | null;
  tx_hash?: string | null;
  created_at: string;
  processed_at?: string | null;
  error_message?: string | null;
  is_vip: boolean;
};

function newIdk(prefix: string) {
  // In WebApp we can rely on modern browsers; fallback is time-based.
  // Idempotency-Key is required by backend for moderation operations.
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const c: any = globalThis.crypto;
  const uuid = c?.randomUUID ?
    c.randomUUID()
    : `${Date.now()}-${Math.random()}`;
  return `${prefix}:${uuid}`;
}

export default function AdminWithdrawalsPage() {
  const t = useT();
  const [items, setItems] = useState<Withdrawal[]>([]);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<string>("PENDING");
  const [vipOnly, setVipOnly] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const query = useMemo(() => {
    const q = new URLSearchParams();
    if (status) q.set("status", status);
    if (vipOnly) q.set("vip_only", "true");
    q.set("limit", "200");
    q.set("offset", "0");
    return q.toString();
  }, [status, vipOnly]);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const res = await apiRequest<any>(
        `/admin/withdrawals?${query}`,
        "GET",
      );
      setItems(Array.isArray(res) ? res : []);
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query]);

  async function approve(id: number) {
    setLoading(true);
    setError(null);
    try {
      await apiRequest<any>(
        `/admin/withdrawals/${id}/approve`,
        "POST",
        {
          idempotencyKey: newIdk(`admin-withdraw-approve-${id}`),
          body: {},
        },
      );
      await load();
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  async function reject(id: number) {
    const reason =
      prompt(
        t("admin.reject_reason_prompt") || "Reason"
      )?.trim();
    if (!reason) return;
    setLoading(true);
    setError(null);
    try {
      await apiRequest<any>(
        `/admin/withdrawals/${id}/reject`,
        "POST",
        {
          idempotencyKey: newIdk(`admin-withdraw-reject-${id}`),
          body: { reason },
        },
      );
      await load();
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="grid gap-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">{t("admin.withdrawals")}</h1>
        <Link href="/admin">
          <Button variant="secondary">
            {t("admin.back")}
          </Button>
        </Link>
      </div>

      <Card title={t("admin.withdrawals")}> 
        <div className="flex flex-wrap items-center gap-2 mb-3">
          <label className="text-sm">
            {t("admin.filter_status")}
            <select
              className={
                "ml-2 efhc-input text-sm "
              }
              value={status}
              onChange={(e) => setStatus(e.target.value)}
            >
              <option value="PENDING">PENDING</option>
              <option value="PAID">PAID</option>
              <option value="REJECTED">REJECTED</option>
              <option value="ERROR">ERROR</option>
            </select>
          </label>

          <label className="text-sm flex items-center gap-2">
            <input
              type="checkbox"
              checked={vipOnly}
              onChange={(e) => setVipOnly(e.target.checked)}
            />
            {t("admin.vip_only")}
          </label>

          <Button
            onClick={load}
            
            disabled={loading}
          >
            {loading ? t("common.loading") : t("common.refresh")}
          </Button>
        </div>

        {error ? (
          <div className="text-sm text-[color:var(--tg-link)] mb-2">
          {error}
        </div>
        ) : null}

        <div className="overflow-auto">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="text-left border-b">
                <th className="py-2 pr-3">ID</th>
                <th className="py-2 pr-3">TG</th>
                <th className="py-2 pr-3">Amount</th>
                <th className="py-2 pr-3">Status</th>
                <th className="py-2 pr-3">VIP</th>
                <th className="py-2 pr-3">Address</th>
                <th className="py-2 pr-3">Created</th>
                <th className="py-2 pr-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {items.map((w) => (
                <tr key={w.id} className="border-b">
                  <td className="py-2 pr-3">{w.id}</td>
                  <td className="py-2 pr-3">{w.tg_id}</td>
                  
                  <td className="py-2 pr-3 tabular-nums">
                    {format8(w.amount_efhc)}
                  </td>
                  <td className="py-2 pr-3">{w.status}</td>
                  <td className="py-2 pr-3">{w.is_vip ? "VIP" : ""}</td>
                  <td className="py-2 pr-3">
                    {w.external_address || ""}
                  </td>
                  <td className="py-2 pr-3">{w.created_at}</td>
                  <td className="py-2 pr-3">
                    {w.status === "PENDING" || w.status === "ERROR" ? (
                      <div className="flex gap-2">
                        <Button
                          
                          onClick={() => approve(w.id)}
                          disabled={loading}
                        >
                          {t("admin.approve")}
                        </Button>
                        <Button
                          
                          onClick={() => reject(w.id)}
                          disabled={loading}
                        >
                          {t("admin.reject")}
                        </Button>
                      </div>
                    ) : (
                      <span
                        className={
                          "text-xs text-[color:var(--tg-hint)]"
                        }
                      >
                        —
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
