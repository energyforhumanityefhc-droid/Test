import React, { useContext, useEffect, useMemo, useState } from "react";

import {
  useMutation,
  useQueryClient,
} from "@tanstack/react-query";

import { EfhcCard } from "../components/ui/EfhcCard";
import { EfhcButton } from "../components/ui/EfhcButton";
import { apiRequest } from "../lib/api";
import { newIdempotencyKey } from "../lib/idempotency";
import type { SyncSnapshot } from "../hooks/useSnapshot";
import { useWalletsMe } from "../hooks/useWalletsMe";
import { LayoutContext } from "../components/Layout";
import {
  hapticImpact,
  telegramMainButtonOnClick,
  telegramMainButtonSet,
} from "../lib/telegram";
import { cmp8, format8, sumScaledDown } from "../lib/format";
import { EfhcCoinIcon } from "../components/icons/EfhcCoin";
import { KwhIcon } from "../components/icons/KwhIcon";

type ConvertOut = {
  ok: boolean;
  exchanged_kwh: string;
  credited_efhc: string;
  new_available_kwh: string;
  new_main_balance: string;
  detail: string;
};

type WithdrawOut = {
  id: number;
  tg_id: number;
  amount: string;
  status: string;
  detail?: string;
};

function isValidD8(s: string): boolean {
  if (!s) return false;
  const raw = s.trim();
  if (!raw) return false;
  if (raw.includes("e") || raw.includes("E")) return false;
  if (raw.includes("-")) return false;
  // Allow: 0..N with optional fractional part up to 8 decimals.
  return /^\d+(\.\d{0,8})?$/.test(raw);
}

export default function ExchangePage(props: {
  tg_id: number | null;
  snap: SyncSnapshot | null;
}) {
  const { confirm, toast, settings, openWalletConnect } = useContext(
    LayoutContext,
  );
  const tg_id = props.tg_id;
  const qc = useQueryClient();

  const walletsQ = useWalletsMe(tg_id);
  const walletConnected = Boolean(walletsQ.data?.is_connected);

  const totalGenerated =
    props.snap?.profile?.total_generated_kwh || "0";
  const availableSnap = props.snap?.profile?.available_kwh || "0";
  const mainBalance = props.snap?.profile?.main_balance || "0";

  const availableKwh = useMemo(() => {
    const g = format8(totalGenerated);
    const a = format8(availableSnap);
    const exchanged = sumScaledDown(g, `-${a}`, 8);
    const calc = sumScaledDown(g, `-${exchanged}`, 8);
    return calc;
  }, [totalGenerated, availableSnap]);

  const canExchange = useMemo(() => {
    return cmp8(availableKwh, "0.00000000") > 0;
  }, [availableKwh]);

  const [wAmount, setWAmount] = useState("10.00000000");

  const withdrawMinOk = useMemo(() => {
    return cmp8(mainBalance, "10.00000000") >= 0;
  }, [mainBalance]);

  const withdrawAmountOk = useMemo(() => {
    if (!isValidD8(wAmount)) return false;
    const amt = format8(wAmount);
    if (cmp8(amt, "10.00000000") < 0) return false;
    if (cmp8(amt, mainBalance) > 0) return false;
    return true;
  }, [wAmount, mainBalance]);

  const exchangeAll = useMutation({
    mutationFn: async () => {
      if (!tg_id) throw new Error("tg_id required");
      const idk = newIdempotencyKey();
      return apiRequest<ConvertOut>(
        `/exchange/convert/${tg_id}`,
        "POST",
        {
          idempotencyKey: idk,
          body: {},
        },
      );
    },
    onSuccess: async (res) => {
      toast(res.detail || "OK", "success");
      await qc.invalidateQueries({
        queryKey: ["syncSnapshot", tg_id],
      });
      await qc.invalidateQueries({
        queryKey: ["exchangePreview", tg_id],
      });
    },
    onError: (e: any) => {
      toast(String(e?.message || e), "error");
    },
  });

  const doExchange = async () => {
    if (!tg_id) return;
    if (!canExchange) return;
    const ok = await confirm(
      "convert",
      "Обменять всё доступное?",
      "Доступные kWh будут зачислены в EFHC MAIN по курсу 1:1.",
    );
    if (!ok) return;
    await exchangeAll.mutateAsync();
  };

  const withdraw = useMutation({
    mutationFn: async () => {
      if (!tg_id) throw new Error("tg_id required");
      if (!walletConnected) {
        throw new Error("WALLET_REQUIRED");
      }
      if (!withdrawAmountOk) {
        throw new Error("Invalid amount");
      }
      const idk = newIdempotencyKey();
      return apiRequest<WithdrawOut>(
        "/withdraw/request",
        "POST",
        {
          idempotencyKey: idk,
          body: { amount: format8(wAmount) },
        },
      );
    },
    onSuccess: async () => {
      toast("Заявка создана", "success");
      await qc.invalidateQueries({
        queryKey: ["syncSnapshot", tg_id],
      });
    },
    onError: (e: any) => {
      toast(String(e?.message || e), "error");
    },
  });

  const doWithdraw = async () => {
    if (!tg_id) return;
    if (!walletConnected) {
      openWalletConnect();
      return;
    }
    if (!withdrawMinOk) return;
    if (!withdrawAmountOk) return;
    const ok = await confirm(
      "withdraw",
      "Создать заявку на вывод?",
      "Списание выполняется только из EFHC MAIN.",
    );
    if (!ok) return;
    await withdraw.mutateAsync();
  };

  const setMax = () => {
    setWAmount(format8(mainBalance));
  };


  useEffect(() => {
    // Telegram MainButton priority (MUST):
    // 1) if available_kwh > 0 -> Exchange
    // 2) else if 10.00000000 <= amount <= main_balance -> Withdraw
    // 3) else hide
    if (!tg_id) {
      telegramMainButtonSet({ text: "", show: false });
      return () => undefined;
    }

    const hasAvailable = cmp8(availableKwh, "0.00000000") > 0;
    const canWithdraw = Boolean(withdrawAmountOk && walletConnected);

    if (!hasAvailable && !canWithdraw) {
      telegramMainButtonSet({ text: "", show: false });
      return () => undefined;
    }

    const mode = hasAvailable ? "exchange" : "withdraw";

    telegramMainButtonSet({
      text: mode === "exchange" ? "Обмен" : "Вывод",
      enabled: mode === "exchange" || walletConnected,
      show: true,
    });

    const onClick = async () => {
      hapticImpact(settings.haptics_enabled);
      if (mode === "exchange") {
        await doExchange();
        return;
      }
      await doWithdraw();
    };

    const off = telegramMainButtonOnClick(onClick);

    return () => {
      off();
      telegramMainButtonSet({ text: "", show: false });
    };
  }, [
    tg_id,
    availableKwh,
    withdrawAmountOk,
    walletConnected,
    settings.haptics_enabled,
    doExchange,
    doWithdraw,
  ]);
  return (
    <div className="space-y-3">
      <EfhcCard>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <KwhIcon size={20} />
            <div className="text-base font-semibold">Обмен</div>
          </div>
          <div className="text-sm text-[var(--tg-hint)]">
            Курс: 1 kWh = 1 EFHC
          </div>
        </div>

        <div className="mt-3">
          <div className="text-sm text-[var(--tg-hint)]">
            Доступно к обмену (kWh)
          </div>
          <div className="mt-1 flex items-center gap-2">
            <div
              className="text-xl font-bold tabular-nums"
            >
              {format8(availableKwh)}
            </div>
          </div>
        </div>

        <div className="mt-4">
          <EfhcButton
            onClick={doExchange}
            disabled={!canExchange || exchangeAll.isPending}
            className="w-full"
          >
            Обмен
          </EfhcButton>
        </div>
      </EfhcCard>

      <EfhcCard>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <EfhcCoinIcon size={20} />
            <div className="text-base font-semibold">Вывод</div>
          </div>
        </div>

        <div className="mt-3">
          <div className="text-sm text-[var(--tg-hint)]">
            Доступно к выводу (MAIN)
          </div>
          <div
            className="mt-1 text-xl font-bold tabular-nums"
          >
            {format8(mainBalance)}
          </div>
        </div>

        <div className="mt-4">
          <div className="text-sm text-[var(--tg-hint)]">Amount</div>
          <div className="mt-2 flex items-center gap-2">
            <input
              value={wAmount}
              onChange={(e) => setWAmount(e.target.value)}
              className={
                "w-full rounded-xl bg-[var(--tg-secondary-bg)] " +
                "px-3 py-2 tabular-nums outline-none " +
                "border border-[color:var(--tg-hint)]"
              }
              inputMode="decimal"
            />
            <EfhcButton
              onClick={setMax}
              variant="secondary"
              disabled={!withdrawMinOk}
            >
              MAX
            </EfhcButton>
          </div>
        </div>

        <div className="mt-3">
          <EfhcButton
            onClick={doWithdraw}
            disabled={
              !withdrawMinOk ||
              !withdrawAmountOk ||
              !walletConnected ||
              withdraw.isPending
            }
            className="w-full"
          >
            Вывод
          </EfhcButton>
        </div>

        {!walletConnected && (
          <div className="mt-2 text-sm text-[var(--tg-hint)]">
            Подключите кошелёк в Profile, чтобы вывести EFHC.
          </div>
        )}

        {!withdrawMinOk && (
          <div className="mt-2 text-sm text-[var(--tg-hint)]">
            Минимум вывода: 10.00000000 EFHC
          </div>
        )}
      </EfhcCard>
    </div>
  );
}