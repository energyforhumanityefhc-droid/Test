/* eslint-disable @next/next/no-img-element */
import React, { useContext, useMemo, useRef } from "react";
import { useRouter } from "next/router";
import {
  useMutation,
  useQuery,
  useQueryClient,
} from "@tanstack/react-query";
import { Card } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { Badge } from "../components/ui/Badge";
import { apiRequest } from "../lib/api";
import { newIdempotencyKey } from "../lib/idempotency";
import { useWalletsMe } from "../hooks/useWalletsMe";
import { useT } from "../hooks/useT";
import { useTD } from "../hooks/useTD";
import { useTonConnectUI } from "@tonconnect/ui-react";
import type { SyncSnapshot } from "../hooks/useSnapshot";
import { LayoutContext } from "../components/Layout";
import { EfhcCoinIcon } from "../components/icons/EfhcCoin";
import {
  activateSkin,
  buySkin,
  fetchMySkins,
  fetchSkinsCatalog,
  type SkinItem,
  type SkinsMy,
} from "../lib/skins";
import { Skeleton } from "../components/ui/Skeleton";
import { EmptyState } from "../components/ui/EmptyState";

type CatalogItem = {
  sku: string;
  title: string;
  description: any;
  price_efhc?: string | null;
  price_ton?: string | null;
  price_usdt?: string | null;
  is_vip_only?: boolean;
  kind: string;
};

type DepositPackage = {
  id: number;
  title: string;
  asset: string;
  price_asset_d8: string;
  efhc_amount_d8: string;
};

export default function ShopPage(props: {
  tg_id: number | null;
  snap: SyncSnapshot | null;
}) {
  const t = useT();
  const td = useTD();
  const router = useRouter();
  const { lang, toast, openWalletConnect } = useContext(
    LayoutContext,
  );
  const tg_id = props.tg_id;

  const qc = useQueryClient();
  const skinsRef = useRef<HTMLDivElement | null>(null);
  const walletsMe = useWalletsMe(tg_id);
  const [tonConnectUI] = useTonConnectUI();

  const isWalletConnected = Boolean(walletsMe.data?.is_connected);

  const openWalletIfNeeded = (): boolean => {
    if (isWalletConnected) return false;
    openWalletConnect();
    return true;
  };

  const pickDesc = useMemo(() => {
    return (d: any): string => {
      if (!d) return "";
      if (typeof d === "string") return d;
      if (typeof d === "object") {
        return String(
          d[lang] || d.en || d.ru || "",
        );
      }
      return String(d);
    };
  }, [lang]);

  const shopQ = useQuery({
    queryKey: ["shopCatalog"],
    staleTime: 60_000,
    queryFn: async () => {
      const r = await apiRequest<{ items: CatalogItem[] }>(
        `/shop/catalog`,
        "GET",
      );
      return r.items || [];
    },
  });

  const depositPkgsQ = useQuery({
    queryKey: ["depositPackages"],
    staleTime: 60_000,
    queryFn: async () => {
      const r = await apiRequest<{ items: DepositPackage[] }>(
        `/deposit/packages`,
        "GET",
      );
      return r.items || [];
    },
  });

  const depositM = useMutation({
    mutationFn: async (package_id: number) => {
      const idk = newIdempotencyKey();
      const r = await apiRequest<any>(
        `/deposit/efhc`,
        "POST",
        {
          idempotencyKey: idk,
          body: { package_id },
        },
      );
      return r;
    },
    onSuccess: async (r: any) => {
      try {
        await tonConnectUI.sendTransaction(r.tonconnect_tx);
        toast("Waiting for confirmation", "success");
      } catch (e: any) {
        toast("Payment cancelled", "error");
        throw e;
      }
    },
    onError: (e: any) => {
      toast("Deposit failed", "error");
      throw e;
    },
  });

  const skinsCatalogQ = useQuery({
    queryKey: ["skinsCatalog"],
    staleTime: 60_000,
    queryFn: async () => await fetchSkinsCatalog(),
  });

  const mySkinsQ = useQuery({
    queryKey: ["skinsMy"],
    staleTime: 10_000,
    queryFn: async () => await fetchMySkins(),
  });

  React.useEffect(() => {
    const section = String(router.query.section || "");
    if (section === "skins") {
      window.setTimeout(() => {
        skinsRef.current?.scrollIntoView({
          behavior: "smooth",
          block: "start",
        });
      }, 50);
    }
  }, [router.query.section]);

  const buySkinM = useMutation({
    mutationFn: async (skin_id: number) => {
      const idk = newIdempotencyKey();
      await buySkin(skin_id, idk);
    },
    onSuccess: async () => {
      toast("Skin purchased", "success");
      await qc.invalidateQueries({ queryKey: ["skinsMy"] });
      await qc.invalidateQueries({ queryKey: ["syncSnapshot", tg_id] });
    },
    onError: (e: any) => {
      toast("Purchase failed", "error");
      throw e;
    },
  });

  const activateSkinM = useMutation({
    mutationFn: async (skin_id: number) => {
      await activateSkin(skin_id);
    },
    onSuccess: async () => {
      toast("Skin activated", "success");
      await qc.invalidateQueries({ queryKey: ["skinsMy"] });
      await qc.invalidateQueries({ queryKey: ["syncSnapshot", tg_id] });
    },
    onError: (e: any) => {
      toast("Activation failed", "error");
      throw e;
    },
  });

  const buyWithEfM = useMutation({
    mutationFn: async (sku: string) => {
      const idk = newIdempotencyKey();
      return await apiRequest<any>(`/shop/purchase-efhc`, "POST", {
        idempotencyKey: idk,
        body: { sku, qty: 1 },
      });
    },
    onSuccess: async () => {
      toast(t("shop.purchase_ok"), "success");
      await qc.invalidateQueries({ queryKey: ["syncSnapshot", tg_id] });
    },
    onError: () => toast("Purchase failed", "error"),
  });

  const extOrderM = useMutation({
    mutationFn: async (
      args: { sku: string; payCurrency: "TON" | "USDT" },
    ) => {
      const clientNonce = newIdempotencyKey();
      return await apiRequest<any>(`/shop/order-external`, "POST", {
        body: {
          sku: args.sku,
          qty: 1,
          pay_currency: args.payCurrency,
          client_nonce: clientNonce,
        },
      });
    },
    onSuccess: () => toast(t("shop.external_created"), "success"),
    onError: () => toast("Order failed", "error"),
  });

  const mySkins = (mySkinsQ.data || null) as SkinsMy | null;
  const isOwned = (skin_id: number) => {
    return (mySkins?.owned || []).some(
      (x) => Number(x.skin_id) === Number(skin_id),
    );
  };

  return (
    <div className="grid gap-4">
      <h1 className="text-2xl font-bold">{t("shop.title")}</h1>

      <Card title={t("shop.rules")}>
        <div className="text-sm text-[color:var(--tg-text)]">
          {td("desc.shop.vip_nft_manual")}
        </div>
        <div className="text-xs text-[color:var(--tg-hint)] mt-2">
          {td("desc.shop.idempotency_note")}
        </div>
      </Card>

      <Card title={t("shop.deposit_title") || "Deposit"}>
        <div className="text-xs text-[color:var(--tg-hint)]">
          {t("shop.deposit_note")
            || "On-chain payment via TonConnect"}
        </div>

        {!walletsMe.data?.is_connected ? (
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <Button
              variant="secondary"
              onClick={() => openWalletConnect()}
            >
              {t("profile.wallet_connect") || "Connect Wallet"}
            </Button>
            <span className="text-xs text-[color:var(--tg-hint)]">
              {t("shop.wallet_required") || "Wallet required"}
            </span>
          </div>
        ) : null}

        <div className="mt-3 grid gap-2">
          {(depositPkgsQ.data || []).map((p) => (
            <div
              key={p.id}
              className={
                "efhc-card p-3 flex items-center "
                + "justify-between"
              }
            >
              <div className="min-w-0">
                <div className="font-semibold truncate">{p.title}</div>
                <div className="text-xs text-[color:var(--tg-hint)]">
                  {p.price_asset_d8} {p.asset}
                  {" "}→{" "}
                  {p.efhc_amount_d8} EFHC
                </div>
              </div>
              <Button
                disabled={depositM.isPending}
                onClick={() => {
                  if (openWalletIfNeeded()) return;
                  depositM.mutate(p.id);
                }}
              >
                {depositM.isPending
                  ? t("common.loading")
                  : t("shop.pay") || "Pay"}
              </Button>
            </div>
          ))}

          {depositPkgsQ.isLoading ? (
            <Skeleton className="h-16" />
          ) : null}
          {!depositPkgsQ.isLoading
            && (depositPkgsQ.data || []).length === 0 ? (
              <EmptyState
                title={t("shop.no_packages") || "No packages"}
                hint={t("shop.no_packages_hint") || "Ask admin"}
              />
            ) : null}
        </div>
      </Card>

      <div className="grid gap-3">
        {shopQ.isFetching && (shopQ.data || []).length === 0 ? (
          <div className="grid gap-2">
            <Skeleton className="h-24" />
            <Skeleton className="h-24" />
          </div>
        ) : null}

        {(shopQ.data || []).map((it) => (
          <div key={it.sku} className="efhc-card p-3">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="font-semibold">{it.title}</div>
                <div className="text-xs text-[color:var(--tg-hint)]">
                  {pickDesc(it.description)}
                </div>
                <div className="mt-2 flex flex-wrap gap-2">
                  {it.is_vip_only ? <Badge>VIP</Badge> : null}
                </div>
              </div>

              <div className="text-right min-w-0">
                {it.price_efhc ? (
                  <div
                    className={
                      "text-sm font-semibold inline-flex "
                      + "items-center gap-1"
                    }
                  >
                    <EfhcCoinIcon size={24} /> {it.price_efhc} EFHC
                  </div>
                ) : null}
                {it.price_ton ? (
                  <div className="text-xs text-[color:var(--tg-hint)]">
                    {it.price_ton} TON
                  </div>
                ) : null}
                {it.price_usdt ? (
                  <div className="text-xs text-[color:var(--tg-hint)]">
                    {it.price_usdt} USDT
                  </div>
                ) : null}
              </div>
            </div>

            <div className="mt-3 flex flex-wrap gap-2">
              {it.price_efhc ? (
                <Button
                  disabled={buyWithEfM.isPending}
                  onClick={() => buyWithEfM.mutate(it.sku)}
                >
                  {buyWithEfM.isPending
                    ? t("common.loading")
                    : t("shop.buy_efhc")}
                </Button>
              ) : null}
              {it.price_ton ? (
                <Button
                  variant="secondary"
                  disabled={extOrderM.isPending}
                  onClick={() => {
                    if (openWalletIfNeeded()) return;
                    extOrderM.mutate({
                      sku: it.sku,
                      payCurrency: "TON",
                    });
                  }}
                >
                  {t("shop.pay_ton")}
                </Button>
              ) : null}
              {it.price_usdt ? (
                <Button
                  variant="secondary"
                  disabled={extOrderM.isPending}
                  onClick={() => {
                    if (openWalletIfNeeded()) return;
                    extOrderM.mutate({
                      sku: it.sku,
                      payCurrency: "USDT",
                    });
                  }}
                >
                  {t("shop.pay_usdt")}
                </Button>
              ) : null}
            </div>
          </div>
        ))}

        {(shopQ.data || []).length === 0 && !shopQ.isFetching ? (
          <EmptyState
            title={t("common.empty")}
            detail={shopQ.error ? String(shopQ.error) : ""}
            actionLabel="Refresh"
            onAction={() => void shopQ.refetch()}
          />
        ) : null}
      </div>

      <div ref={skinsRef} />
      <Card title="Skins">
        <div className="text-xs efhc-text-muted2">
          Картинки для главной страницы (под прогресс-баром).
          <br />
          Покупай и активируй.
        </div>

        {skinsCatalogQ.isFetching &&
        (skinsCatalogQ.data || []).length === 0 ? (
          <div className="mt-3 grid gap-2">
            <Skeleton className="h-40" />
            <Skeleton className="h-40" />
          </div>
        ) : null}

        <div className="mt-3 grid grid-cols-1 gap-3">
          {(skinsCatalogQ.data || []).map((sk: SkinItem) => {
            const owned = isOwned(sk.skin_id);
            const active =
              Number(mySkins?.active_skin_id || 1) ===
              Number(sk.skin_id);
            return (
              <div
                key={sk.skin_id}
                className="efhc-card overflow-hidden"
              >
                <img
                  src={sk.asset_path}
                  alt={sk.title}
                  className="w-full h-auto block"
                  loading="lazy"
                />
                <div
                  className={
                    "p-3 flex items-start justify-between " +
                    "gap-3"
                  }
                >
                  <div>
                    <div className="font-semibold">
                      ID {sk.skin_id} — {sk.title}
                    </div>
                    <div
                      className={
                        "mt-1 text-sm inline-flex items-center " +
                        "gap-1 efhc-text-gold"
                      }
                    >
                      <EfhcCoinIcon size={24} /> {sk.price_efhc} EFHC
                    </div>
                  </div>
                  <div className="flex flex-col gap-2 items-end">
                    {active ? <Badge>ACTIVE</Badge> : null}
                    {owned && !active ? (
                      <Button
                        variant="secondary"
                        disabled={activateSkinM.isPending}
                        onClick={() => activateSkinM.mutate(sk.skin_id)}
                      >
                        Use
                      </Button>
                    ) : null}
                    {!owned ? (
                      <Button
                        disabled={buySkinM.isPending}
                        onClick={() => buySkinM.mutate(sk.skin_id)}
                      >
                        Buy
                      </Button>
                    ) : null}
                  </div>
                </div>
              </div>
            );
          })}

          {(skinsCatalogQ.data || []).length === 0 &&
          !skinsCatalogQ.isFetching ? (
            <EmptyState
              title="No skins"
              detail={
                skinsCatalogQ.error
                  ? String(skinsCatalogQ.error)
                  : ""
              }
              actionLabel="Refresh"
              onAction={() => {
                void skinsCatalogQ.refetch();
                void mySkinsQ.refetch();
              }}
            />
          ) : null}
        </div>
      </Card>
    </div>
  );
}