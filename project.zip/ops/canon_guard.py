#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""EFHC Canon Guard

Проверяет архитектурные запреты проекта:
- TG-ID как единственная истина в публичном слое
  (запрет tg_id вне admin-контуров)
- Абсолютный запрет бан-токена
  (буквы l o t t e r y без пробелов) во всех файлах/путях
- Запрет запрещённых паттернов (через шаблоны с {BAN})
- Идемпотентность:
  MUST-IDK по SSOT списку путей
  SHOULD-IDK — предупреждение
  EXTERNAL-ID — без Idempotency-Key

Запуск:
  python ops/canon_guard.py

Код специально НЕ содержит запрещённый токен в явном виде.
"""

from __future__ import annotations

import glob
import os
import re
import sys
from pathlib import Path
import subprocess
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Tuple

try:
    import yaml
except ImportError:
    print(
        "ERROR: PyYAML not installed. "
        "Install with: pip install pyyaml",
        file=sys.stderr,
    )
    sys.exit(2)

REPO_ROOT = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..")
)
RULES_PATH = os.path.join(REPO_ROOT, "ops", "canon_rules.yaml")


@dataclass


class Violation:
    rule: str
    file: str
    line: int | None
    snippet: str
    fix: str

def iter_repo_files(
    root: str,
    ignore_dirs: List[str],
    exts: List[str],
) -> Iterable[str]:
    ignore_set = set(ignore_dirs)
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in ignore_set]
        for fn in filenames:
            full = os.path.join(dirpath, fn)
            rel = os.path.relpath(full, root)
            if any(part in ignore_set for part in rel.split(os.sep)):
                continue
            if exts and not any(fn.endswith(e) for e in exts):
                continue
            yield full


def iter_all_paths(root: str, ignore_dirs: List[str]) -> Iterable[str]:
    ignore_set = set(ignore_dirs)
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in ignore_set]
        for fn in filenames:
            full = os.path.join(dirpath, fn)
            rel = os.path.relpath(full, root)
            if any(part in ignore_set for part in rel.split(os.sep)):
                continue
            yield full


def read_lines(path: str) -> List[str]:
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        return f.read().splitlines()


def add_violation(
    vs: List[Violation],
    rule: str,
    file: str,
    line: int | None,
    snippet: str,
    fix: str,
) -> None:
    vs.append(
        Violation(
            rule=rule,
            file=file,
            line=line,
            snippet=snippet,
            fix=fix,
        )
    )



class CanonRulesError(RuntimeError):
    pass


def load_canon_rules(path: Path) -> dict[str, Any]:
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise CanonRulesError(
            f"CANON_GUARD: cannot read rules file: {path}"
        ) from exc

    try:
        data = yaml.safe_load(raw)
    except yaml.YAMLError as exc:
        raise CanonRulesError(
            f"CANON_GUARD: invalid YAML in {path}"
        ) from exc

    if not isinstance(data, dict):
        raise CanonRulesError(
            "CANON_GUARD: ops/canon_rules.yaml must be a mapping (dict)"
        )

    validate_rules(data)
    return data


def load_rules(path: str) -> Dict[str, Any]:
    # Backward-compatible wrapper for existing call sites.
    return load_canon_rules(Path(path))


def _expect_type(obj: Any, expected: type, path: str) -> None:
    if not isinstance(obj, expected):
        got = type(obj).__name__
        exp = expected.__name__
        raise CanonRulesError(
            f"CANON_GUARD: {path} must be {exp}, got {got}"
        )


def _expect_list_of_str(value: Any, path: str) -> None:
    _expect_type(value, list, path)
    for i, item in enumerate(value):
        if not isinstance(item, str):
            got = type(item).__name__
            raise CanonRulesError(
                f"CANON_GUARD: {path}[{i}] must be str, got {got}"
            )


def _expect_bool(value: Any, path: str) -> None:
    if not isinstance(value, bool):
        got = type(value).__name__
        raise CanonRulesError(
            f"CANON_GUARD: {path} must be bool, got {got}"
        )


def _expect_str(value: Any, path: str) -> None:
    if not isinstance(value, str):
        got = type(value).__name__
        raise CanonRulesError(
            f"CANON_GUARD: {path} must be str, got {got}"
        )


def _validate_alias_bans(cfg: Dict[str, Any]) -> None:
    if "mode" in cfg:
        _expect_str(cfg["mode"], "alias_bans.mode")
        mode = str(cfg["mode"]).lower()
        if mode not in {"report", "enforce"}:
            raise CanonRulesError(
                "CANON_GUARD: alias_bans.mode must be report|enforce"
            )

    for key in ["banned_tokens", "banned_regex", "scan"]:
        if key not in cfg:
            raise CanonRulesError(
                "CANON_GUARD: alias_bans missing key: " + key
            )

    _expect_list_of_str(
        cfg["banned_tokens"],
        "alias_bans.banned_tokens",
    )
    _expect_list_of_str(
        cfg["banned_regex"],
        "alias_bans.banned_regex",
    )
    _expect_type(cfg["scan"], dict, "alias_bans.scan")

    scan = cfg["scan"]
    if "include_file_ext" in scan:
        _expect_list_of_str(
            scan["include_file_ext"],
            "alias_bans.scan.include_file_ext",
        )
    if "ignore_path_globs" in scan:
        _expect_list_of_str(
            scan["ignore_path_globs"],
            "alias_bans.scan.ignore_path_globs",
        )


def validate_rules(rules: Dict[str, Any]) -> None:
    # Требование A1: верхний уровень — mapping/dict,
    # и обязательные ключи.
    required = [
        "version",
        "format",
        "paths",
        "identifier_canon",
        "terminology_bans",
        "guard",
    ]
    missing = [k for k in required if k not in rules]
    if missing:
        raise CanonRulesError(
            "CANON_GUARD: missing required keys: "
            + ", ".join(missing)
        )

    allowed_top = set(required) | {
        "exclusions",
        "idempotency",
        "alias_bans",
        "logs_policy",
    }
    unknown = sorted(set(rules.keys()) - allowed_top)
    if unknown:
        raise CanonRulesError(
            "CANON_GUARD: unknown top-level keys: "
            + ", ".join(unknown)
        )

    _expect_type(rules["format"], dict, "format")
    _expect_type(rules["paths"], dict, "paths")
    _expect_type(rules["identifier_canon"], dict, "identifier_canon")
    _expect_type(rules["terminology_bans"], dict, "terminology_bans")
    _expect_type(rules["guard"], dict, "guard")

    if "alias_bans" in rules:
        _expect_type(rules["alias_bans"], dict, "alias_bans")
        _validate_alias_bans(rules["alias_bans"])

    fmt = rules["format"]
    if "required_top_level_type" in fmt:
        if fmt["required_top_level_type"] != "mapping":
            raise CanonRulesError(
                "CANON_GUARD: format.required_top_level_type must be "
                "'mapping'"
            )

    paths = rules["paths"]
    for key in ["repo_roots", "include", "ignore_dirs", "ignore_globs"]:
        if key not in paths:
            raise CanonRulesError(
                f"CANON_GUARD: missing required key: paths.{key}"
            )
    _expect_list_of_str(paths["repo_roots"], "paths.repo_roots")
    _expect_list_of_str(paths["include"], "paths.include")
    _expect_list_of_str(paths["ignore_dirs"], "paths.ignore_dirs")
    _expect_list_of_str(paths["ignore_globs"], "paths.ignore_globs")

    excl = rules.get("exclusions") or {}
    _expect_type(excl, dict, "exclusions")
    if "content_scan_globs" in excl:
        _expect_list_of_str(
            excl["content_scan_globs"],
            "exclusions.content_scan_globs",
        )

    idem = rules.get("idempotency")
    if idem is not None:
        _expect_type(idem, dict, "idempotency")
        if "must_path_patterns" not in idem:
            raise CanonRulesError(
                "CANON_GUARD: missing required key: "
                "idempotency.must_path_patterns"
            )
        _expect_list_of_str(
            idem["must_path_patterns"],
            "idempotency.must_path_patterns",
        )

    ident = rules["identifier_canon"]
    for key in ["allowed_user_id_name", "banned_identifiers"]:
        if key not in ident:
            raise CanonRulesError(
                "CANON_GUARD: missing required key: "
                f"identifier_canon.{key}"
            )
    if not isinstance(ident["allowed_user_id_name"], str):
        raise CanonRulesError(
            "CANON_GUARD: identifier_canon.allowed_user_id_name "
            "must be str"
        )
    _expect_list_of_str(
        ident["banned_identifiers"],
        "identifier_canon.banned_identifiers",
    )

    tb = rules["terminology_bans"]
    if "banned_tokens" not in tb:
        raise CanonRulesError(
            "CANON_GUARD: missing required key: "
            "terminology_bans.banned_tokens"
        )
    _expect_list_of_str(
        tb["banned_tokens"],
        "terminology_bans.banned_tokens",
    )

    scan = tb.get("scan")
    _expect_type(scan, dict, "terminology_bans.scan")
    for key in ["enabled", "include_file_ext", "ignore_path_globs"]:
        if key not in scan:
            raise CanonRulesError(
                "CANON_GUARD: missing required key: "
                f"terminology_bans.scan.{key}"
            )
    _expect_bool(scan["enabled"], "terminology_bans.scan.enabled")
    _expect_list_of_str(
        scan["include_file_ext"],
        "terminology_bans.scan.include_file_ext",
    )
    _expect_list_of_str(
        scan["ignore_path_globs"],
        "terminology_bans.scan.ignore_path_globs",
    )


def _compile_banned_token_regexes(
    tokens: list[str],
) -> list[re.Pattern[str]]:
    regs: list[re.Pattern[str]] = []
    for tok in tokens:
        raw = str(tok)
        if not raw:
            continue
        # Важный нюанс: \b считает '_' частью слова (\w), поэтому
        # не ловит случаи вроде "prize_models" или "admin/prizes.tsx".
        # Канон A4: запрещённые термины должны ловиться и в путях, и в
        # идентификаторах, но не должны задевать слова типа "withdraw".
        # Поэтому используем границы по [A-Za-z0-9], а не по \w.
        pat = (
            rf"(?i)(?<![A-Za-z0-9]){re.escape(raw)}(?![A-Za-z0-9])"
        )
        regs.append(re.compile(pat))
    return regs


def _path_excluded(rel_path: str, globs_list: list[str]) -> bool:
    import fnmatch

    rel_norm = rel_path.replace("\\", "/")
    for g in globs_list:
        g_norm = str(g).replace("\\", "/")
        if fnmatch.fnmatch(rel_norm, g_norm):
            return True
    return False


def _get_term_scan_cfg(
    rules: Dict[str, Any],
) -> tuple[list[str], list[str], list[str]]:
    paths = rules["paths"]
    ignore_dirs = list(paths.get("ignore_dirs") or [])

    tb = rules["terminology_bans"]
    scan = tb["scan"]
    exts = list(scan.get("include_file_ext") or [])

    exclusions = []
    excl = rules.get("exclusions") or {}
    exclusions.extend(list(excl.get("content_scan_globs") or []))
    exclusions.extend(list(scan.get("ignore_path_globs") or []))

    return ignore_dirs, exts, exclusions


def _iter_term_scan_roots(rules: Dict[str, Any]) -> list[str]:
    paths = rules["paths"]
    include = list(paths.get("include") or [])
    roots: list[str] = []
    for rel in include:
        if not rel:
            continue
        roots.append(os.path.join(REPO_ROOT, str(rel)))
    return roots


def check_banned_tokens_and_patterns(
    rules: Dict[str, Any],
) -> List[Violation]:
    vs: List[Violation] = []

    tb = rules["terminology_bans"]
    scan = tb["scan"]
    enabled = bool(scan.get("enabled", True))

    tokens = list(tb.get("banned_tokens") or [])
    if not enabled:
        # Stage-gate: пока терминология не выровнена по проекту,
        # держим в режиме строгого запрета только для абсолютного
        # бан-токена (без затрагивания существующих подсистем).
        ban = "".join(["l","o","t","t","e","r","y"])
        tokens = [t for t in tokens if str(t).lower() == ban]
    regs = _compile_banned_token_regexes(tokens)
    if not regs:
        return vs

    ignore_dirs, exts, exclude_globs = _get_term_scan_cfg(rules)
    scan_roots = _iter_term_scan_roots(rules)

    # 1) Проверка путей (имена файлов/папок)
    for root in scan_roots:
        if not os.path.isdir(root):
            continue
        for p in iter_all_paths(root, ignore_dirs):
            rel = os.path.relpath(p, REPO_ROOT)
            if _path_excluded(rel, exclude_globs):
                continue
            for rg in regs:
                if rg.search(rel):
                    add_violation(
                        vs,
                        rule="TERMINOLOGY_BAN_PATH",
                        file=rel,
                        line=None,
                        snippet=rel,
                        fix=(
                            "Переименовать путь: запрещённый термин "
                            "не допускается по TERMS_GLOSSARY."
                        ),
                    )
                    break

    # 2) Проверка содержимого
    for root in scan_roots:
        if not os.path.isdir(root):
            continue
        for p in iter_repo_files(root, ignore_dirs, exts):
            rel = os.path.relpath(p, REPO_ROOT)
            if _path_excluded(rel, exclude_globs):
                continue

            lines = read_lines(p)
            for i, line in enumerate(lines, start=1):
                for rg in regs:
                    if rg.search(line):
                        add_violation(
                            vs,
                            rule="TERMINOLOGY_BAN_CONTENT",
                            file=rel,
                            line=i,
                            snippet=line.strip()[:200],
                            fix=(
                                "Заменить запрещённый термин "
                                "на каноничный по TERMS_GLOSSARY."
                            ),
                        )
                        break

    return vs


def check_cursor_codec(rules: Dict[str, Any]) -> List[Violation]:
    """SSOT курсора: требуем наличие единого cursor_codec.py."""
    vs: List[Violation] = []
    cfg = rules.get("cursor_codec") or {}
    rel = (
        cfg.get("required_file")
        or "backend/app/utils/cursor_codec.py"
    )
    abs_path = os.path.join(REPO_ROOT, rel)
    if not os.path.exists(abs_path):
        add_violation(
            vs,
            rule="CURSOR_CODEC_MISSING",
            file=rel,
            line=None,
            snippet=rel,
            fix=(
                "Создайте единый SSOT cursor codec "
                "и используйте его во всех модулях."
            ),
        )
    return vs


def _glob_files(globs_list: List[str]) -> List[str]:
    out: List[str] = []
    for g in globs_list:
        out.extend(
            glob.glob(
                os.path.join(REPO_ROOT, g),
                recursive=True,
            )
        )
    return sorted(set(out))


def _matches_any_glob(rel_path: str, globs_list: List[str]) -> bool:
    import fnmatch

    rel_norm = rel_path.replace("\\", "/")
    for g in globs_list:
        g_norm = g.replace("\\", "/")
        if fnmatch.fnmatch(rel_norm, g_norm):
            return True
    return False


def check_public_api_forbidden_fields(
    rules: Dict[str, Any]
) -> List[Violation]:
    """Запрещает legacy id в HTTP-слое (routes и schemas).

    Без исключений.

    Канон: внешние контуры (включая admin) оперируют только tg_id.
    Внутренний PK может существовать в БД/сервисах,
    но не должен протекать
    в публичные схемы/роуты.
    И не должен называться legacy id в этих слоях.
    """

    vs: List[Violation] = []
    forbidden = set(rules.get("public_api_forbidden_fields", []) or [])

    targets: List[str] = []
    targets.extend(_glob_files(rules.get("routes_globs", []) or []))
    targets.extend(_glob_files(rules.get("schemas_globs", []) or []))

    exclude_dirs = set(rules.get("exclude_dirs", []) or [])

    for pth in sorted(set(targets)):
        rel = os.path.relpath(pth, REPO_ROOT)
        if any(part in exclude_dirs for part in rel.split(os.sep)):
            continue

        lines = read_lines(pth)
        for i, line in enumerate(lines, start=1):
            for f in forbidden:
                if re.search(rf"\b{re.escape(f)}\b", line):
                    add_violation(
                        vs,
                        rule="PUBLIC_API_FORBIDDEN_FIELD",
                        file=rel,
                        line=i,
                        snippet=line.strip()[:200],
                        fix=(
                            "HTTP-слой не использует legacy id. "
                            "Везде использовать tg_id."
                        ),
                    )

    return vs


def _compile_path_regexes(patterns: List[str]) -> List[re.Pattern[str]]:
    out: List[re.Pattern[str]] = []
    for p in patterns:
        try:
            out.append(re.compile(str(p)))
        except re.error as e:
            raise ValueError(
                f"Invalid regex in rules: {p} ({e})"
            ) from e
    return out


def _path_matches(path: str, regs: List[re.Pattern[str]]) -> bool:
    return any(r.search(path) for r in regs)


def check_idempotency_policy(rules: Dict[str, Any]) -> List[Violation]:
    """Проверка политики идемпотентности по 3 классам:

    A) MUST-IDK: по списку путей (regex)
       требует Depends(require_idempotency_key)
    B) SHOULD-IDK: по списку путей (regex)
       предупреждение, если нет accept/require
    C) EXTERNAL-ID: по списку путей (regex)
       запрещаем require_idempotency_key
       и требуем event-id dedupe

    Важно: это не "философия" про все POST.
    Это точный SSOT список критичных команд.
    """

    vs: List[Violation] = []
    routes = _glob_files(rules.get("money_routes_globs", []) or [])
    exclude_dirs = set(rules.get("exclude_dirs", []) or [])

    idem = rules.get("idempotency") or {}
    require_dep = str(idem.get("dependency", "require_idempotency_key"))
    accept_dep = str(
        idem.get(
            "accept_dependency",
            "accept_idempotency_key",
        )
    )

    must_regs = _compile_path_regexes(
        list(idem.get("must_path_patterns", []) or [])
    )
    should_regs = _compile_path_regexes(
        list(idem.get("should_path_patterns", []) or [])
    )
    external_regs = _compile_path_regexes(
        list(idem.get("external_event_id_paths", []) or [])
    )

    # Декораторы, где операция меняет состояние (обычно требуется
    # идемпотентность по SSOT).
    deco_re = re.compile(
        r"^\s*@router\.(post|patch|delete|put)\("
        r"\s*(['\"])([^'\"]+)\2"
    )

    for p in routes:
        rel = os.path.relpath(p, REPO_ROOT)
        if any(part in exclude_dirs for part in rel.split(os.sep)):
            continue

        lines = read_lines(p)
        for idx, line in enumerate(lines):
            m = deco_re.search(line)
            if not m:
                continue

            method = m.group(1).lower()
            path = m.group(3)

            window = "\n".join(lines[idx : min(idx + 100, len(lines))])
            has_require = (
                f"Depends({require_dep})" in window
                or f"Depends({require_dep}," in window
            )
            has_accept = (
                f"Depends({accept_dep})" in window
                or f"Depends({accept_dep}," in window
            )

            # C) EXTERNAL-ID:
            # запрещаем Idempotency-Key dependency и требуем
            # dedupe по event-id.
            if _path_matches(path, external_regs):
                if has_require:
                    add_violation(
                        vs,
                        rule="EXTERNAL_ID_FORBIDS_IDK",
                        file=rel,
                        line=idx + 1,
                        snippet=line.strip()[:200],
                        fix=(
                            "External callbacks/webhooks не требуют "
                            "Idempotency-Key. Использовать dedupe "
                            "по provider event-id."
                        ),
                    )

                # Требование dedupe по event-id:
                # ищем маркеры обработчика.
                # Минимально:
                # наличие слов event_id/update_id/delivery_id или
                # вызова external_event_dedupe.
                dedupe_markers = [
                    "external_event_dedupe",
                    "processed_events",
                    "provider_event_id",
                    "delivery_id",
                    "update_id",
                    "event_id",
                    "X-Event-Id",
                    "X-Delivery-Id",
                ]
                if not any(tok in window for tok in dedupe_markers):
                    add_violation(
                        vs,
                        rule="EXTERNAL_ID_MISSING_DEDUPE",
                        file=rel,
                        line=idx + 1,
                        snippet=line.strip()[:200],
                        fix=(
                            "External callbacks должны иметь dedupe "
                            "по event-id/delivery-id "
                            "(processed_events table) — добавить "
                            "явный маркер/проверку."
                        ),
                    )
                continue

            # A) MUST-IDK по SSOT списку путей
            if _path_matches(path, must_regs):
                if not has_require:
                    add_violation(
                        vs,
                        rule="MUST_IDK_MISSING",
                        file=rel,
                        line=idx + 1,
                        snippet=f"@router.{method}('{path}')"[:200],
                        fix=(
                            f"Путь '{path}' в списке MUST-IDK. "
                            f"Добавь Depends({require_dep}) "
                            "в сигнатуру handler."
                        ),
                    )
                continue

            # B) SHOULD-IDK:
            # предупреждение (не fail) если нет accept/require
            if _path_matches(path, should_regs):
                if not (has_require or has_accept):
                    # Предупреждение печатаем,
                    # но не добавляем как violation
                    print(
                        (
                            "CANON GUARD: WARN — SHOULD-IDK "
                            "path without idempotency: "
                            f"{rel}:{idx+1} {path}"
                        ),
                        file=sys.stderr,
                    )
                continue

            # Остальные пути: идемпотентность желательна, но guard не
            # принуждает.

    return vs


def check_db_required_terms(rules: Dict[str, Any]) -> List[Violation]:
    """Требуемые термины должны существовать в репо.

    Контроль DB SSOT.
    """
    vs: List[Violation] = []
    required = rules.get("db_required_terms", []) or []
    if not required:
        return vs

    exclude_dirs = rules.get("exclude_dirs", []) or []
    exts = rules.get("scan_extensions", []) or []

    found = {t: False for t in required}

    for p in iter_repo_files(REPO_ROOT, exclude_dirs, exts):
        text = "\n".join(read_lines(p))
        for t in required:
            if t in text:
                found[t] = True

    for t, ok in found.items():
        if not ok:
            add_violation(
                vs,
                rule="DB_REQUIRED_TERM_MISSING",
                file="(repo)",
                line=None,
                snippet=t,
                fix=(
                    "DB SSOT нарушен: обязательный термин отсутствует "
                    "(схема/константы)."
                ),
            )

    return vs


def check_anti_symptom_patching(
    rules: Dict[str, Any]
) -> List[Violation]:
    """Архитектурный запрет «лечения симптомов».

    Проверяет:
      • required_files существуют
      • forbidden_patterns не встречаются в backend/app/routes/**
        (исторический anti‑symptom lock)
      • global_forbidden_patterns не встречаются в кодовой базе
        (backend/app/**, backend/migrations/**)

    Важно:
      • global_forbidden_patterns применяются только к исполняемому
        коду (.py, .sql), а не к документации.
        Иначе примеры в *.md могут ломать сборку.
    """
    vs: List[Violation] = []
    block = rules.get("anti_symptom_patching") or {}
    forbidden = block.get("forbidden_patterns") or []
    global_forbidden = block.get("global_forbidden_patterns") or []
    required_files = block.get("required_files") or []

    for rel in required_files:
        abs_path = os.path.join(REPO_ROOT, rel)
        if not os.path.exists(abs_path):
            add_violation(
                vs,
                rule="ANTI_PATCH_REQUIRED_FILE_MISSING",
                file=rel,
                line=None,
                snippet=rel,
                fix="Добавьте обязательный SSOT файл (anti‑latki).",
            )

    routes_root = os.path.join(REPO_ROOT, "backend", "app", "routes")
    scan_roots = [
        os.path.join(REPO_ROOT, "backend", "app"),
        os.path.join(REPO_ROOT, "backend", "migrations"),
    ]
    scan_roots = [p for p in scan_roots if os.path.isdir(p)]

    def _compile(
        patterns: List[Any],
        key: str,
    ) -> List[Tuple[str, re.Pattern]]:
        out: List[Tuple[str, re.Pattern]] = []
        for item in patterns:
            ps = str(item)
            try:
                rx = re.compile(ps)
            except re.error as exc:
                raise CanonRulesError(
                    "CANON_GUARD: invalid regex in rules: "
                    f"anti_patch.{key}: {ps}"
                ) from exc
            out.append((ps, rx))
        return out

    compiled_routes = _compile(forbidden, "forbidden_patterns")
    compiled_global = _compile(
        global_forbidden,
        "global_forbidden_patterns",
    )

    def _is_allowed_match(pattern_str: str, relpath: str) -> bool:
        """Точечные исключения для SSOT-файлов.

        Запреты должны ловить дублирование SSOT,
        но не должны запрещать сам SSOT.
        """
        if pattern_str in {"def encode_cursor", "def decode_cursor"}:
            rel_norm = relpath.replace("\\", "/")
            return rel_norm == "backend/app/utils/cursor_codec.py"
        return False

    # 1) Исторический lock: forbidden_patterns только в routes.
    if os.path.isdir(routes_root) and compiled_routes:
        for p in glob.glob(
            os.path.join(routes_root, "**", "*.py"),
            recursive=True,
        ):
            relpath = os.path.relpath(p, REPO_ROOT)
            content = "\n".join(read_lines(p))
            for pattern_str, rx in compiled_routes:
                m = rx.search(content)
                if not m:
                    continue
                if _is_allowed_match(pattern_str, relpath):
                    continue
                line_no = content[: m.start()].count("\n") + 1
                lines = read_lines(p)
                snippet = rx.pattern
                idx0 = line_no - 1
                if 0 <= idx0 < len(lines):
                    snippet = lines[idx0].strip()
                add_violation(
                    vs,
                    rule="ANTI_PATCH_FORBIDDEN_PATTERN",
                    file=relpath,
                    line=line_no,
                    snippet=snippet[:200],
                    fix=(
                        "Запрещено лечить симптомы в routes. "
                        "Исправляйте первопричину через SSOT "
                        "(contracts/standards/utils) "
                        "и добавляйте guard/test."
                    ),
                )

    # 2) Глобальные запреты:
    # только исполняемый код (.py, .sql) в backend/app +
    # migrations.
    if scan_roots and compiled_global:
        exts = {".py", ".sql"}
        for root in scan_roots:
            for p in glob.glob(
                os.path.join(root, "**", "*"),
                recursive=True,
            ):
                if not os.path.isfile(p):
                    continue
                if os.path.splitext(p)[1].lower() not in exts:
                    continue

                relpath = os.path.relpath(p, REPO_ROOT)
                content = "\n".join(read_lines(p))
                for pattern_str, rx in compiled_global:
                    m = rx.search(content)
                    if not m:
                        continue
                    if _is_allowed_match(pattern_str, relpath):
                        continue
                    line_no = content[: m.start()].count("\n") + 1
                    lines = read_lines(p)
                    snippet = rx.pattern
                    idx0 = line_no - 1
                    if 0 <= idx0 < len(lines):
                        snippet = lines[idx0].strip()
                    add_violation(
                        vs,
                        rule="ANTI_PATCH_FORBIDDEN_PATTERN",
                        file=relpath,
                        line=line_no,
                        snippet=snippet[:200],
                        fix=(
                            "Запрещено использовать глобально "
                            "запрещённый паттерн. "
                            "Исправляйте через SSOT + guard/test."
                        ),
                    )
    return vs


def check_repo_importability(rules: Dict[str, Any]) -> List[Violation]:
    """Lock: Repo Must Be Importable."""
    vs: List[Violation] = []
    block = rules.get("repo_importability") or {}
    required = block.get("required_packages") or []
    for pkg in required:
        pkg_path = os.path.join(REPO_ROOT, pkg)
        has_pkg = os.path.isdir(pkg_path)
        has_init = os.path.exists(
            os.path.join(pkg_path, "__init__.py")
        )
        if has_pkg and not has_init:
            add_violation(
                vs,
                rule="REPO_IMPORTABILITY_MISSING_INIT",
                file=os.path.relpath(pkg_path, REPO_ROOT),
                line=None,
                snippet="__init__.py missing",
                fix=(
                    "Добавьте __init__.py "
                    "для гарантированной импортируемости пакета."
                ),
            )

    mod = (block.get("import_check") or {}).get("module")
    if mod:
        try:
            subprocess.check_output(
                [sys.executable, "-c", f"import {mod}"],
                cwd=REPO_ROOT,
                stderr=subprocess.STDOUT,
                timeout=20,
            )
        except Exception as e:
            add_violation(
                vs,
                rule="REPO_IMPORTABILITY_IMPORT_FAILED",
                file="(import)",
                line=None,
                snippet=str(e)[:200],
                fix=(
                    f"Исправьте ошибки импорта, "
                    f"чтобы `import {mod}` проходил успешно."
                ),
            )
    return vs


def check_cursor_codec_ssot(rules: Dict[str, Any]) -> List[Violation]:
    """Lock: Cursor codec SSOT.

    Что проверяет:
    - Курсор кодируется только через backend/app/utils/cursor_codec.py.
    - Запрещены tuple‑курсоры: encode_cursor((...)).
    - Запрещена распаковка decode_cursor в несколько переменных.
      Пример: a, b = decode_cursor(...).

    Это лечит «болезнь класса» pagination drift.
    Формат курсора обязан быть dict.
    """
    vs: List[Violation] = []

    app_root = os.path.join(REPO_ROOT, "backend", "app")
    if not os.path.isdir(app_root):
        return vs

    exclude_dirs = set(
        (rules.get("exclude_dirs") or [])
        + ["__pycache__"]
    )

    banned = [
        (
            re.compile(r"\bdef\s+encode_cursor\b"),
            "CURSOR_CODEC_NO_LOCAL_DEF",
            "Определение encode_cursor разрешено только "
            "в utils/cursor_codec.py",
        ),
        (
            re.compile(r"\bdef\s+decode_cursor\b"),
            "CURSOR_CODEC_NO_LOCAL_DEF",
            "Определение decode_cursor разрешено только "
            "в utils/cursor_codec.py",
        ),
        (
            re.compile(r"encode_cursor\(\s*\("),
            "CURSOR_CODEC_TUPLE_ENCODE_FORBIDDEN",
            "Запрещён tuple‑курсор. "
            "Используй encode_cursor({..}).",
        ),
        (
            re.compile(
                r"\w+\s*,\s*\w+\s*=\s*decode_cursor\("
            ),
            "CURSOR_CODEC_UNPACK_FORBIDDEN",
            "decode_cursor() возвращает dict. "
            "Нельзя распаковывать в несколько переменных.",
        ),
    ]

    codec_rel = os.path.join(
        "backend",
        "app",
        "utils",
        "cursor_codec.py",
    )
    codec_abs = os.path.join(REPO_ROOT, codec_rel)

    for dirpath, dirnames, filenames in os.walk(app_root):
        rel_dir = os.path.relpath(dirpath, REPO_ROOT)
        dirnames[:] = [d for d in dirnames if d not in exclude_dirs]
        for fn in filenames:
            if not fn.endswith(".py"):
                continue
            abs_path = os.path.join(dirpath, fn)
            if os.path.abspath(abs_path) == os.path.abspath(codec_abs):
                continue
            rel = os.path.relpath(abs_path, REPO_ROOT)
            # исключаем миграции
            # (они не в backend/app, но на всякий случай)
            if any(part in exclude_dirs for part in rel.split(os.sep)):
                continue
            lines = read_lines(abs_path)
            for i, line in enumerate(lines, start=1):
                for rx, rule_name, fix in banned:
                    if rx.search(line):
                        add_violation(
                            vs,
                            rule=rule_name,
                            file=rel,
                            line=i,
                            snippet=line.strip()[:200],
                            fix=fix,
                        )

    return vs


def check_settings_ssot(rules: Dict[str, Any]) -> List[Violation]:
    """Lock: Settings SSOT.

    Минимальная SSOT‑проверка:
    - Если в проекте используется
      settings.env_normalized / s.env_normalized,
      то свойство env_normalized обязано существовать в Settings.
    """
    vs: List[Violation] = []

    app_root = os.path.join(REPO_ROOT, "backend", "app")
    cfg_path = os.path.join(
        REPO_ROOT,
        "backend",
        "app",
        "core",
        "config_core.py",
    )
    if not os.path.isfile(cfg_path) or not os.path.isdir(app_root):
        return vs

    # ищем использование env_normalized
    used = False
    for dirpath, dirnames, filenames in os.walk(app_root):
        dirnames[:] = [d for d in dirnames if d not in {"__pycache__"}]
        for fn in filenames:
            if not fn.endswith(".py"):
                continue
            abs_path = os.path.join(dirpath, fn)
            rel = os.path.relpath(abs_path, REPO_ROOT)
            if rel.endswith(os.path.join("core", "config_core.py")):
                continue
            for line in read_lines(abs_path):
                if ".env_normalized" in line:
                    used = True
                    break
            if used:
                break
        if used:
            break

    if not used:
        return vs

    cfg_text = "\n".join(read_lines(cfg_path))
    if "def env_normalized" not in cfg_text:
        add_violation(
            vs,
            rule="SETTINGS_SSOT_ENV_NORMALIZED_MISSING",
            file=os.path.relpath(cfg_path, REPO_ROOT),
            line=1,
            snippet="env_normalized",
            fix=(
                "Добавь @property def env_normalized(self)->str "
                "в Settings (config_core.py)."
            ),
        )

    return vs


def check_lotteries_auto_cycle_ssot(
    rules: Dict[str, Any]
) -> List[Violation]:
    """SSOT: lotteries авто-цикл.

    Запрет scheduler-контура.
    Кошелёк для NFT.


    Guard валит сборку, если:
      - в репозитории существуют scheduler-модули для lotteries
        (по regex из SSOT)
      - в lotteries_service отсутствуют каноничные функции
        и их вызовы из svc_buy_tickets
    """

    vs: List[Violation] = []
    cfg = rules.get("lotteries") or {}
    guard = (cfg.get("guard") or {}) if isinstance(cfg, dict) else {}

    if not cfg or not isinstance(cfg, dict):
        return vs

    # A) Запрет scheduler-модулей для lotteries
    if bool(cfg.get("forbid_lotteries_scheduler")):
        rx_list = guard.get("forbidden_scheduler_regexes") or []
        regs = _compile_path_regexes([str(x) for x in rx_list])
        exclude_dirs = rules.get("exclude_dirs", []) or []
        for p in iter_all_paths(REPO_ROOT, exclude_dirs):
            rel = os.path.relpath(p, REPO_ROOT).replace("\\", "/")
            if _path_matches(rel, regs):
                add_violation(
                    vs,
                    rule="LOTTERIES_SCHEDULER_FORBIDDEN",
                    file=rel,
                    line=None,
                    snippet=rel,
                    fix=(
                        "Удалить/не регистрировать scheduler-задачи "
                        "для lotteries: sold-out обрабатывается "
                        "в svc_buy_tickets."
                    ),
                )

    # B) Требование кошелька и sold-out авто-цикла в сервисе
    service_rel = str(
        guard.get("required_service_file")
        or "backend/app/services/lotteries_service.py"
    )
    service_abs = os.path.join(REPO_ROOT, service_rel)
    if not os.path.exists(service_abs):
        add_violation(
            vs,
            rule="LOTTERIES_SERVICE_MISSING",
            file=service_rel,
            line=None,
            snippet=service_rel,
            fix=(
                "Файл сервиса lotteries отсутствует — "
                "восстановите "
                "backend/app/services/lotteries_service.py."
            ),
        )
        return vs

    content = "\n".join(read_lines(service_abs))
    wallet_fn = str(
        guard.get("required_wallet_guard_fn")
        or "_require_wallet_for_nft_ticket_purchase"
    )
    soldout_fn = str(
        guard.get("required_sold_out_fn")
        or "_auto_draw_if_sold_out"
    )

    if bool(cfg.get("nft_wallet_required_on_ticket_purchase")):
        if f"def {wallet_fn}" not in content:
            add_violation(
                vs,
                rule="DRAWS_WALLET_GUARD_FN_MISSING",
                file=service_rel,
                line=None,
                snippet=f"def {wallet_fn} ...",
                fix=(
                    "Добавьте каноничную функцию проверки кошелька "
                    "и используйте её в svc_buy_tickets."
                ),
            )
        # вызов внутри svc_buy_tickets
        sig = (
            r"async\s+def\s+svc_buy_tickets"
            r"\([^\)]*\)\s*"
            r"(?:->[^:]+)?\s*:"
        )
        wallet_re = (
            sig
            + r"[\s\S]*"
            + re.escape(wallet_fn)
            + r"\("
        )
        if re.search(wallet_re, content) is None:
            add_violation(
                vs,
                rule="DRAWS_WALLET_GUARD_CALL_MISSING",
                file=service_rel,
                line=None,
                snippet=f"{wallet_fn}(...)",
                fix=(
                    "В svc_buy_tickets должен быть вызов "
                    "функции проверки кошелька для NFT-приза."
                ),
            )

    if bool(cfg.get("sold_out_triggers_draw")):
        if f"def {soldout_fn}" not in content:
            add_violation(
                vs,
                rule="DRAWS_SOLDOUT_FN_MISSING",
                file=service_rel,
                line=None,
                snippet=f"def {soldout_fn} ...",
                fix=(
                    "Добавьте каноничную функцию sold-out авто-цикла "
                    "и вызывайте её из svc_buy_tickets."
                ),
            )
        sig = (
            r"async\s+def\s+svc_buy_tickets"
            r"\([^\)]*\)\s*"
            r"(?:->[^:]+)?\s*:"
        )
        soldout_re = (
            sig
            + r"[\s\S]*"
            + re.escape(soldout_fn)
            + r"\("
        )
        if re.search(soldout_re, content) is None:
            add_violation(
                vs,
                rule="DRAWS_SOLDOUT_CALL_MISSING",
                file=service_rel,
                line=None,
                snippet=f"{soldout_fn}(...)",
                fix=(
                    "В svc_buy_tickets должен быть вызов sold-out "
                    "авто-цикла (lotteries сразу при sold-out)."
                ),
            )

    return vs


def check_python_packages_must_be_importable(
    rules: Dict[str, Any]
) -> List[Violation]:
    """Lock: Python packages must be importable.

    Две проверки:
      1) Явный SSOT-список required_init_files:
         если директория существует,
         а __init__.py отсутствует → FAIL.
      2) Авто-правило:
         если директория содержит .py файлы
         (кроме __init__.py)
         и не попадает в исключения →
         __init__.py обязателен.

    Важно: это защита от «болезни класса».
    Пакетность ломают случайно — снова и снова.
    """

    vs: List[Violation] = []
    cfg = rules.get("python_packages") or {}
    required_init_files: List[str] = list(
        cfg.get("required_init_files", []) or []
    )
    auto_rule: bool = bool(cfg.get("auto_init_for_py_dirs", False))
    exclude_dir_patterns: List[str] = list(
        cfg.get("exclude_dir_patterns", []) or []
    )

    # 1) Явный SSOT
    for rel_init in required_init_files:
        rel_init = str(rel_init)
        dir_rel = os.path.dirname(rel_init)
        dir_abs = os.path.join(REPO_ROOT, dir_rel)
        init_abs = os.path.join(REPO_ROOT, rel_init)
        if os.path.isdir(dir_abs) and not os.path.exists(init_abs):
            add_violation(
                vs,
                rule="PY_PKG_REQUIRED_INIT_MISSING",
                file=dir_rel,
                line=None,
                snippet="__init__.py missing",
                fix=(
                    f"Добавьте {rel_init} "
                    "(пакетность обязана быть закреплена каноном)."
                ),
            )

    # 2) Авто-правило по дереву backend/ (и опционально ops/)
    if not auto_rule:
        return vs

    compiled_excl: List[re.Pattern[str]] = []
    for pat in exclude_dir_patterns:
        ps = str(pat)
        try:
            compiled_excl.append(re.compile(ps))
        except re.error as exc:
            raise CanonRulesError(
                "CANON_GUARD: invalid regex in rules: "
                f"python_packages.exclude_dir_patterns: {ps}"
            ) from exc

    def is_excluded(rel_dir: str) -> bool:
        norm = rel_dir.replace("\\", "/")
        parts = [p for p in norm.split("/") if p]
        # совпадение по целому пути и по отдельным сегментам
        for rx in compiled_excl:
            if rx.search(norm):
                return True
            if any(rx.search(seg) for seg in parts):
                return True
        return False

    roots = [
        os.path.join(REPO_ROOT, "backend"),
        os.path.join(REPO_ROOT, "ops"),
    ]
    for root in roots:
        if not os.path.isdir(root):
            continue
        for dirpath, dirnames, filenames in os.walk(root):
            rel_dir = os.path.relpath(dirpath, REPO_ROOT)
            if is_excluded(rel_dir):
                # не углубляемся
                dirnames[:] = []
                continue

            py_files = [f for f in filenames if f.endswith(".py")]
            if not py_files:
                continue

            has_non_init_py = any(f != "__init__.py" for f in py_files)
            if not has_non_init_py:
                continue

            if "__init__.py" not in py_files:
                add_violation(
                    vs,
                    rule="PY_PKG_AUTO_INIT_MISSING",
                    file=rel_dir,
                    line=None,
                    snippet="директория с .py без __init__.py",
                    fix=(
                        "Добавьте __init__.py "
                        "(или внесите директорию "
                        "в исключения канона, "
                        "если это не пакет)."
                    ),
                )

    return vs


def check_ssot_priority_note(rules: Dict[str, Any]) -> List[Violation]:
    """Ensure SSOT priority is explicitly documented.

    Canon: ARCHITECTURAL_LOCKS.md has priority
    over any technical specification documents.
    This prevents regressions where developers
    follow outdated PDFs over locks/guard.
    """
    violations: List[Violation] = []

    # Canon: project.zip is a FLAT artifact containing code zones only.
    # Repo-root policy docs may not be shipped inside the artifact.
    # In that mode, we do not enforce presence of repo-root locks docs.
    def _is_flat_artifact_root(root: str) -> bool:
        p = Path(root)
        return (
            p.joinpath("backend").is_dir()
            and p.joinpath("frontend").is_dir()
            and p.joinpath("tests").is_dir()
            and p.joinpath("ops").is_dir()
            and not p.joinpath(".git").exists()
        )

    path = os.path.join(REPO_ROOT, "ARCHITECTURAL_LOCKS.md")
    if not os.path.exists(path):
        if _is_flat_artifact_root(REPO_ROOT):
            return []
        violations.append(
            Violation(
                rule="SSOT PRIORITY NOTE",
                file="ARCHITECTURAL_LOCKS.md",
                line=None,
                snippet="missing file",
                fix=(
                    "Create ARCHITECTURAL_LOCKS.md "
                    "in repo root and add SSOT "
                    "priority section."
                ),
            )
        )
        return violations

    with open(path, "r", encoding="utf-8") as f:
        content = f.read()

    required_phrase = "приоритет над любыми техническими заданиями"
    if required_phrase not in content.lower():
        violations.append(
            Violation(
                rule="SSOT PRIORITY NOTE",
                file="ARCHITECTURAL_LOCKS.md",
                line=1,
                snippet="SSOT priority statement not found",
                fix=(
                    "Add section 'SSOT / Приоритет документов' "
                    "stating locks/guard/code override "
                    "any TЗ."
                ),
            )
        )
    return violations


def main() -> int:
    if not os.path.exists(RULES_PATH):
        print(
            f"ERROR: rules file not found: {RULES_PATH}",
            file=sys.stderr,
        )
        return 2

    try:
        rules = load_rules(RULES_PATH)
    except CanonRulesError as e:
        print(
            f"ERROR: invalid rules file: {e}",
            file=sys.stderr,
        )
        return 2
    violations: List[Violation] = []

    violations.extend(check_ssot_priority_note(rules))
    violations.extend(check_banned_tokens_and_patterns(rules))
    violations.extend(check_public_api_forbidden_fields(rules))
    violations.extend(check_idempotency_policy(rules))
    violations.extend(check_cursor_codec(rules))
    violations.extend(check_db_required_terms(rules))
    violations.extend(check_anti_symptom_patching(rules))
    violations.extend(check_lotteries_auto_cycle_ssot(rules))
    violations.extend(check_python_packages_must_be_importable(rules))
    violations.extend(check_repo_importability(rules))
    violations.extend(check_cursor_codec_ssot(rules))
    violations.extend(check_settings_ssot(rules))

    if not violations:
        print("CANON GUARD: OK — нарушений не найдено.")
        return 0

    print(
        "\nCANON GUARD: FAIL — обнаружены нарушения:\n",
        file=sys.stderr,
    )
    for v in violations[:200]:
        loc = v.file if v.line is None else f"{v.file}:{v.line}"
        print(f"- RULE: {v.rule}", file=sys.stderr)
        print(f"  FILE: {loc}", file=sys.stderr)
        print(f"  SNIP: {v.snippet}", file=sys.stderr)
        print(f"  FIX : {v.fix}", file=sys.stderr)
        print("", file=sys.stderr)

    print(f"TOTAL VIOLATIONS: {len(violations)}", file=sys.stderr)
    return 2

if __name__ == "__main__":
    raise SystemExit(main())

