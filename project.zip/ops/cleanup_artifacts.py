"""Cleanup utility: remove Python/pytest artifacts from the repository.

Removes:
- __pycache__ directories
- *.pyc/*.pyo files
- .pytest_cache directory

Usage:
    python ops/cleanup_artifacts.py
    python ops/cleanup_artifacts.py --dry-run
    python ops/cleanup_artifacts.py --root /path/to/repo

Exit code:
    0 - success (nothing to delete or deleted successfully)
    1 - error
"""

from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path


ARTIFACT_DIR_NAMES = {"__pycache__", ".pytest_cache"}
ARTIFACT_FILE_SUFFIXES = {".pyc", ".pyo"}

EXCLUDE_TOP_DIRS = {
    "vendor",
    "alembic",
    "migrations",
    ".git",
    "dist",
    "build",
    ".venv",
    "venv",
}


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Remove Python/pytest artifacts from the repo."
    )
    p.add_argument(
        "--root",
        type=Path,
        default=Path(__file__).resolve().parents[1],
        help="Repository root (default: parent of ops/)",
    )
    p.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be removed, but do not delete.",
    )
    return p.parse_args()


def is_excluded(path: Path, root: Path) -> bool:
    try:
        rel = path.relative_to(root)
    except ValueError:
        return True
    parts = rel.parts
    return bool(parts) and parts[0] in EXCLUDE_TOP_DIRS


def find_artifacts(root: Path) -> list[Path]:
    found: list[Path] = []
    for p in root.rglob("*"):
        if is_excluded(p, root):
            continue
        if p.is_dir() and p.name in ARTIFACT_DIR_NAMES:
            found.append(p)
            continue
        if p.is_file() and p.suffix in ARTIFACT_FILE_SUFFIXES:
            found.append(p)
    return sorted(found)


def remove_path(p: Path, dry_run: bool) -> None:
    if dry_run:
        print(f"DRY-RUN: would remove {p}")
        return
    if p.is_dir():
        shutil.rmtree(p, ignore_errors=False)
    else:
        p.unlink(missing_ok=True)


def main() -> int:
    ns = parse_args()
    root = ns.root.resolve()

    if not root.exists():
        print(f"ERROR: root does not exist: {root}", file=sys.stderr)
        return 1

    artifacts = find_artifacts(root)
    if not artifacts:
        print("OK: no artifacts found")
        return 0

    # Remove files first, then dirs (to avoid leftover empty dirs)
    files = [p for p in artifacts if p.is_file()]
    dirs = [p for p in artifacts if p.is_dir()]

    for p in files:
        remove_path(p, ns.dry_run)
    for p in dirs:
        remove_path(p, ns.dry_run)

    if ns.dry_run:
        print(f"DRY-RUN: {len(artifacts)} paths would be removed")
    else:
        print(f"OK: removed {len(artifacts)} paths")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
