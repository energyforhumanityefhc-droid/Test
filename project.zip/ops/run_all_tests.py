from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
TESTS = ROOT / "tests"


def _rel(path: Path) -> str:
    return path.relative_to(ROOT).as_posix()


def _discover() -> list[Path]:
    if not TESTS.exists():
        return []
    return sorted(TESTS.rglob("test_*.py"))


def _select(files: list[Path], group: str) -> list[str]:
    rels = [_rel(p) for p in files]
    if group == "all":
        return rels
    if group == "quick":
        keep = (
            "tests/architecture/",
            "tests/core/",
            "tests/test_build_sanity.py",
            "tests/test_no_banned_identifiers.py",
            "tests/test_no_placeholders.py",
        )
        return [r for r in rels if any(r.startswith(k) for k in keep)]
    if group == "architecture":
        return [r for r in rels if r.startswith("tests/architecture/")]
    if group == "core":
        return [r for r in rels if r.startswith("tests/core/")]
    if group == "unit":
        return [r for r in rels if r.startswith("tests/efhc_backend/")]
    raise ValueError(f"Unknown group: {group}")


def _run_pytest(selected: list[str], extra: list[str]) -> int:
    cmd = [sys.executable, "-m", "pytest", "-q", *selected, *extra]
    proc = subprocess.run(cmd, cwd=str(ROOT))
    return int(proc.returncode)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="run_all_tests",
        description="List and run EFHC Bot pytest groups.",
    )
    parser.add_argument(
        "--list",
        action="store_true",
        help="Print discovered tests and exit.",
    )
    parser.add_argument(
        "--group",
        choices=["all", "quick", "architecture", "core", "unit"],
        default="all",
        help="Select a test group.",
    )
    parser.add_argument(
        "pytest_args",
        nargs=argparse.REMAINDER,
        help="Extra args passed to pytest after '--'.",
    )
    args = parser.parse_args(argv)

    files = _discover()
    selected = _select(files, args.group)

    if args.list:
        print("Discovered tests:")
        for r in [_rel(p) for p in files]:
            print(f"- {r}")
        print("\nSelected:")
        for r in selected:
            print(f"- {r}")
        return 0

    extra = []
    if args.pytest_args and args.pytest_args[0] == "--":
        extra = args.pytest_args[1:]
    elif args.pytest_args:
        extra = args.pytest_args
    return _run_pytest(selected, extra)


if __name__ == "__main__":
    raise SystemExit(main())
