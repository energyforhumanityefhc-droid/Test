-- Create schemas
CREATE SCHEMA IF NOT EXISTS efhc_core;
