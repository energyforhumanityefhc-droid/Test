# Line 72 Defrag — Cycle 001
Fixed to <=72 (0 violations each):
- `frontend/src/pages/panels.tsx`
- `frontend/src/pages/referrals.tsx`
- `frontend/src/components/EnergyGauge.tsx`
- `frontend/src/components/icons/KwhIcon.tsx`
- `frontend/src/components/AdminTable.tsx`

Current frontend total violations (all scanned text): **598**

Top remaining offenders:
- `frontend/src/components/ProfileModal.tsx` — 53 lines over 72 (max 161)
- `frontend/src/pages/admin/users.tsx` — 47 lines over 72 (max 140)
- `frontend/public/locale/ru.json` — 34 lines over 72 (max 153)
- `frontend/src/pages/exchange.tsx` — 29 lines over 72 (max 139)
- `frontend/src/pages/index.tsx` — 28 lines over 72 (max 96)
- `frontend/src/components/Layout.tsx` — 23 lines over 72 (max 152)
- `frontend/src/pages/admin/index.tsx` — 21 lines over 72 (max 117)
- `frontend/src/pages/admin/panels.tsx` — 18 lines over 72 (max 123)
- `frontend/src/pages/shop.tsx` — 18 lines over 72 (max 95)
- `frontend/src/pages/ranks.tsx` — 17 lines over 72 (max 142)
- `frontend/src/pages/lotteries.tsx` — 15 lines over 72 (max 185)
- `frontend/src/pages/admin/shop.tsx` — 15 lines over 72 (max 104)
- `frontend/src/lib/telegram.ts` — 13 lines over 72 (max 108)
- `frontend/src/pages/admin/logs.tsx` — 13 lines over 72 (max 106)
- `frontend/src/pages/admin/referrals.tsx` — 13 lines over 72 (max 94)
