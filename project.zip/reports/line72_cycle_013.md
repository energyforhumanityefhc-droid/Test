# line72 cycle 013

Цель: критичные правки security/MVP без изменения экономики SSOT.

Изменения:
- CORS: в prod не разрешаем localhost; allowlist через
  CORS_ALLOW_ORIGINS (CSV) и базовые URL из settings.
- JWT TTL: дефолтный ACCESS_TOKEN_EXPIRE_MINUTES уменьшен до 30.
- Alembic env: исправлен sslmode=require (без пробелов).
- .env.example: добавлены переменные для CORS/JWT/initData/admin key.

Исключения line72: нет.

Проверки:
- python -m compileall backend -q : PASS
- pytest -q : PASS
