# line72 cycle 017

Дата: 2026-02-24
Архив-база: EFHC_Bot_v145_29_alias_cleanup_tg_id.zip
Цель цикла: доки/тексты без алиасов идентификатора, канон tg_id.

## Изменения

1) README.md
- Убраны упоминания идентификатора через query/headers.
- Каноничный путь: request.state.tg_id или X-Telegram-Init-Data.

2) backend/app/models/bank_models.py
- В __repr__ исправлено bank_tg_id -> bank_tg_id.

3) docs/EFHC_CANON.md
- Исправлен список запрещённых алиасов без перечисления
  псевдо-ключей в точных токенах.

## 72
Исключений нет.
