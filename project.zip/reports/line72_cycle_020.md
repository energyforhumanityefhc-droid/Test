# line72 cycle 020

Goal: T2 Energy UI (12-level progress + live energy) using snapshot only.

Files changed:

1) frontend/src/pages/index.tsx
- Replaced Energy screen content with T2 blocks A-E.
- Live E(t) interpolation from server_now_iso + gen_per_sec_effective,
  2–4 UI updates/sec (333ms).
- 12-level thresholds + level names, progress bar, remaining kWh.
- Fixed 8 decimals, DOWN via bigint scaled math, tabular numerals.

2) reports/line72_cycle_020.md
- This report.

Line72 exceptions: none.
