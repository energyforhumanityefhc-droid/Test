# line72 cycle 023

Scope: Exchange page SSOT alignment.

Files changed:
- backend/app/services/exchange_service.py
- backend/app/services/withdraw_service.py
- frontend/src/pages/exchange.tsx

Notes:
- No new routes/endpoints/entities.
- Idempotency-Key required for EXCHANGE_ALL and WITHDRAW.
- Audit attached to efhc_transfers_log.extra_info.
