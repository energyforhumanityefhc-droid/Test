# line72 cycle 024

Goal:
- Add SSOT nuclear lock: total_generated_kwh is append-only (never
  decreases).
- Guard exchange path against lifetime mutation and add tests:
  runtime/static.

Changed files (<=5):
1) ARCHITECTURAL_LOCKS.md
   - Added LOCK: TOTAL_GENERATED_KWH_APPEND_ONLY with invariants.

2) backend/app/services/exchange_service.py
   - Added assert-style guards ensuring total_generated_kwh never changes
     during EXCHANGE_ALL apply/audit.
   - Included total_generated_kwh in audit "after" snapshot.

3) tests/test_total_generated_kwh_append_only.py
   - Static tests ensuring exchange/withdraw never decrement lifetime.

4) tests/architecture/test_no_total_generated_kwh_decrement.py
   - Repo-wide static grep-like test for forbidden decrement patterns.

Notes:
- No new routes/entities.
- No banned substrings introduced.
