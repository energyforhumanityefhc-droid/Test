# line72_cycle_025

Цикл: v145_38

Цель: SSOT-зеркальная ветка через exchanged_kwh_total + защита от гонок
Exchange-all.

Сделано:
- Добавлен exchanged_kwh_total (миграция) и SSOT-замок зеркальной ветки:
  available_kwh = total_generated_kwh - exchanged_kwh_total.
- Вынесен EXCHANGE_ALL в атомарную транзакцию с FOR UPDATE и аудитом.
- Добавлен статический тест: формула и наличие блокировки.

Исключения line72: нет.
