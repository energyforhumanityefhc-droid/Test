# line72 cycle 027

Changes:
- Added runtime concurrency tests to prove single-application under
  race conditions for:
  - double EXCHANGE_ALL
  - EXCHANGE_ALL + WITHDRAW
  - double WITHDRAW
- Brought WITHDRAW audit fields to parity with the EXCHANGE_ALL audit
  standard (before/after + invariant_ok for success and rejected paths).
- Added explicit SSOT pointer for exchange/withdraw mechanics into
  Architectural Locks.

Files changed:
- backend/app/database.py
- backend/app/services/transactions_service.py
- backend/app/services/withdraw_service.py
- docs/ARCHITECTURAL_LOCKS.md
- tests/test_concurrency_exchange_all.py
- tests/test_concurrency_exchange_withdraw.py
- tests/test_concurrency_withdraw_double.py
- reports/line72_cycle_027.md

Line72 exceptions: none
Checks:
- compileall: PASS
- pytest: PASS
