# line72_cycle_028

Scope: Panels tab SSOT threads, canon formatting, minimal guard tests.

Done:
- Panels UI uses snapshot fields as the only source of truth for counts and rates.
- All dynamic energy/rate values are rendered via the canon 8-decimal DOWN formatter.
- Added tabular-nums to dynamic numeric values for stable alignment.
- Added static tests that fail on local numeric casts/formatting on Panels.

Files changed:
1) frontend/src/pages/panels.tsx
   - Summary shows active panels count (snapshot) and effective generation rate (snapshot).
   - Base/VIP rate cards are rendered from snapshot fields only.
   - All kWh/rate values use the canon formatter and tabular-nums.
2) tests/architecture/test_panels_no_local_numeric_casts.py
   - Guard: no local numeric casts/formatters on Panels.
3) tests/test_panels_uses_canon_formatter.py
   - Guard: Panels imports and uses the canon formatter.
4) reports/line72_cycle_028.md
   - This report.

Line72 exceptions: none.

Checks:
- python -m compileall backend -q : PASS
- pytest -q : PASS
