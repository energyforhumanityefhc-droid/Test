# line72_cycle_031

Cycle goal: Panels SSOT implementation (step 2/10)

## What changed

Aligned the ORM model for `panels` with Panels SSOT fields and invariants,
without introducing new routes/services/UI changes.

Key points:

* Added SSOT fields to `Panel`: `public_id` (nullable), `activated_at`.
* Kept `public_id` nullable to support the SSOT flow where it is filled
  after `id` is allocated inside the same transaction.
* Added SSOT time invariant constraint `expires_at > activated_at` and the
  UNIQUE constraint on `public_id` in the ORM declaration.
* Kept legacy fields for compatibility; SSOT services will be switched to
  the SSOT fields in later steps.

## Canon / locks respected

* No new endpoints, no aliases.
* No economic logic changes.
* No client-side time source introduced.

## Verification

* python -m compileall backend -q : PASS
* pytest -q : PASS
