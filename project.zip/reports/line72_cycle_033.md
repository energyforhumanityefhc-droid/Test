# line72 cycle 033

## Scope
SSOT Panels — cycle 4/10 (Routes).

## Changes
- Aligned panels purchase route to SSOT canon:
  - Single canonical buy endpoint: POST /panels/buy/{tg_id}
  - Requires Idempotency-Key.
  - Body is empty (no qty, no tg_id in body).
  - Response includes created panel (id, public_id, activated_at,
    expires_at) and server_now_utc.
- Enforced tg_id match with authenticated tg_id.
- Removed legacy purchase route to avoid duplicates.

## Verification
- python -m compileall backend -q: PASS
- pytest -q: PASS
