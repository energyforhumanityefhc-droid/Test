# Cycle 034 — Panels SSOT (frontend)

Scope: SSOT Panels пункт 5/10 (Frontend).

## Changes
- Panels page updated to match SSOT structure:
  - Top description block.
  - Actions grid 2x2: Buy, Lotteries, Active, Archive.
  - One list controlled by Active/Archive.
- Canon time anchor:
  - Uses meta.server_now_iso as UTC anchor.
  - Local clock used only as a stopwatch.
  - Remaining timer derived from expires_at - now_utc.
- Canon buy route:
  - POST /panels/buy/{tg_id} with Idempotency-Key header.
- Card rendering is resilient to missing fields:
  - public_id and ISO dates are optional; UI shows "—".

## Notes
- No new routes, entities, or economic logic changes.
- SSOT numeric strings stay formatted via format8.
