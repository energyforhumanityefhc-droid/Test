# line72 cycle 038

Цикл: Panels SSOT — backend tests (MUST) по идемпотентности и срокам.

## Сделано

- Добавлены runtime pytest-тесты для Panels:
  - идемпотентность создания панели по одному ключу,
  - глобальный рост идентификаторов панелей между пользователями,
  - срок 180 дней (UTC tz-aware),
  - классификация Active/Archive по server_now_utc.

## Инварианты

- Один (tg_id, Idempotency-Key) возвращает одну и ту же панель.
- expires_at - activated_at == 180 days (UTC).
- Active: expires_at > server_now_utc; Archive: expires_at <= server_now_utc.

## Проверки

- python -m compileall backend -q
- pytest -q
