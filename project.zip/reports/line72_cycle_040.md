# Cycle 9/10 (SSOT Panels) — Canon docs linkage

## What changed

- Canon docs were aligned so that Panels SSOT is explicitly part of the
  architectural locks set.

## Files changed

- docs/ARCHITECTURAL_LOCKS.md
  - Added an explicit SSOT pointer to docs/PANELS_SSOT.md alongside the
    existing Exchange/Withdraw SSOT reference.

## Line-72 exceptions

- None.

## Verification

- python -m compileall backend -q: PASS
- pytest -q: PASS
