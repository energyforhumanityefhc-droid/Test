# Cycle 042 — SSOT per-sec constants (BASE/VIP) + locks + tests

## What changed

- Added SSOT string fields for per-sec generation rates and 1:1 rate to
  Settings.
- Enforced a single source of truth via system locks helper accessors.
- Removed local defaults / literal fallbacks from services and routes.
- Added unit/regression tests for Settings defaults, lock validation,
  VIP switch, and a repo-wide literal guard.

## Files

- backend/app/core/config_core.py
- backend/app/core/system_locks.py
- backend/app/services/energy_service.py
- backend/app/services/panels_service.py
- backend/app/crud/panels_crud.py
- backend/app/routes/sync_routes.py
- backend/app/routes/user_routes.py
- backend/app/utils.py
- tests/test_per_sec_constants_settings.py
- tests/test_gen_rate_vip_switch.py
- tests/test_per_sec_literals_guard.py

## Notes

- No new routes or aliases were introduced.
- All calculations stay Decimal d8 (ROUND_DOWN).