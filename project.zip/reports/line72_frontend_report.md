# Frontend line72 report

This file is required by the baseline integrity manifest.
Do not delete.
