from __future__ import annotations

from pathlib import Path


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def _slice_between(text: str, start: str, end: str) -> str:
    s = text.find(start)
    if s < 0:
        return ""
    e = text.find(end, s + len(start))
    if e < 0:
        return text[s:]
    return text[s:e]


def test_exchange_api_returns_main_only_balance() -> None:
    root = _repo_root()
    p = root / "backend" / "app" / "routes" / "exchange_routes.py"
    src = _read(p)

    # ExchangeConvertOut должен содержать только new_main_balance.
    cls = _slice_between(
        src,
        "class ExchangeConvertOut",
        "class ExchangeHistoryItem",
    )
    assert "new_main_balance" in cls, (
        "ExchangeConvertOut must expose new_main_balance"
    )
    assert "bonus" not in cls.lower(), (
        "ExchangeConvertOut must not expose any bonus fields"
    )


def test_withdraw_service_never_touches_bonus_balance() -> None:
    root = _repo_root()
    p = root / "backend" / "app" / "services" / "withdraw_service.py"
    if not p.exists():
        # если модуль переименован, пусть тест явно упадёт
        raise AssertionError("withdraw_service.py not found")
    src = _read(p).lower()
    assert "bonus_balance" not in src, (
        "Withdraw must never touch bonus_balance"
    )


def test_shop_purchase_with_efhc_spends_bonus_then_main_in_source_order(
) -> None:
    root = _repo_root()
    p = root / "backend" / "app" / "services" / "shop_service.py"
    src = _read(p)

    body = _slice_between(
        src,
        "async def purchase_with_efhc",
        "async def",
    )
    if not body:
        raise AssertionError("purchase_with_efhc() not found")

    a = body.find("debit_user_bonus_to_bank")
    b = body.find("debit_user_to_bank")

    assert a >= 0, "purchase_with_efhc must debit bonus via bank"
    assert b >= 0, "purchase_with_efhc must debit main via bank"
    assert a < b, "purchase_with_efhc must spend BONUS before MAIN"


def test_frontend_exchange_page_does_not_read_bonus_balance_property(
) -> None:
    root = _repo_root()
    p = root / "frontend" / "src" / "pages" / "exchange.tsx"
    src = _read(p)

    # Разрешены тексты про bonus, но запрещён доступ к свойству
    # snap.profile.bonus_balance.
    low = src.lower()
    assert "bonus_balance" not in low, (
        "Frontend exchange page must not access bonus_balance"
    )
