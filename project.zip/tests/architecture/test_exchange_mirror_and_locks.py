# -*- coding: utf-8 -*-
"""Canon guard: mirror-branch formula and race locks for Exchange.

We keep tests repo-local and deterministic (no DB required).

Must-have:
- Mirror formula uses total_generated_kwh and exchanged_kwh_total.
- Exchange-all uses row lock (FOR UPDATE) to prevent double-spend races.
"""

from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_exchange_uses_mirror_formula() -> None:
    src = _read("backend/app/services/exchange_service.py")

    assert "exchanged_kwh_total" in src
    assert "total_generated_kwh" in src
    assert "total - exchanged_total" in src


def test_exchange_all_has_row_lock() -> None:
    src = _read("backend/app/services/transactions_service.py")

    assert "exchange_all_available_kwh_to_main" in src
    assert "FOR UPDATE" in src
    assert "exchanged_kwh_total" in src