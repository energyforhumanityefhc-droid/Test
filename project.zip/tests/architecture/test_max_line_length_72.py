"""Architecture test: enforce max 72 characters per line.

Scope: продуктовые исходники (backend/app, ops, api, frontend).
Правило 72 применяется ко всем текстовым исходникам фронтенда.
"""

from __future__ import annotations

from pathlib import Path


MAX_LEN = 72
SCAN_DIRS = (
    Path("api"),
    Path("backend/app"),
    Path("ops"),
    Path("frontend"),
)
EXCLUDE_PARTS = {
    "__pycache__",
    "alembic",
    "migrations",
    "vendor",
    "node_modules",
    ".next",
    "public",
    "dist",
    "build",
    "coverage",
}

# Files that are machine-managed or otherwise impractical
# to keep under 72 without harming their purpose.
# without harming their purpose (lockfiles, generated bundles, etc.).
EXCLUDE_FILE_NAMES = {
    "package-lock.json",
    "pnpm-lock.yaml",
    "yarn.lock",
}


def _is_excluded(path: Path) -> bool:
    parts = set(path.parts)
    return any(p in parts for p in EXCLUDE_PARTS)


def _iter_text_files(root: Path):
    for base in SCAN_DIRS:
        base_path = root / base
        if not base_path.exists():
            continue
        for p in base_path.rglob("*"):
            if p.is_dir():
                continue
            rel = p.relative_to(root)
            if _is_excluded(rel):
                continue
            if p.name in EXCLUDE_FILE_NAMES:
                continue
            # Python + frontend sources.
            if p.suffix.lower() not in {
                ".py",
                ".pyi",
                ".ts",
                ".tsx",
                ".js",
                ".jsx",
                ".css",
                ".md",
                ".json",
                ".yml",
                ".yaml",
            }:
                continue
            yield p, rel


def test_max_line_length_72():
    root = Path(__file__).resolve().parents[2]  # repo root
    violations: list[str] = []

    for p, rel in _iter_text_files(root):
        try:
            data = p.read_text(encoding="utf-8", errors="strict")
        except UnicodeDecodeError:
            # If it's not valid UTF-8, treat as binary and ignore.
            # (We keep the scope to text sources.)
            continue

        for idx, line in enumerate(data.splitlines(), start=1):
            # Measure visible characters excluding newline.
            ln = len(line)
            if ln > MAX_LEN:
                snippet = repr(line[:120])
                violations.append(
                    f"{rel}:{idx}: L={ln} > {MAX_LEN}: {snippet}"
                )

    if violations:
        head = "\n".join(violations[:200])
        if len(violations) <= 200:
            more = ""
        else:
            extra = len(violations) - 200
            more = f"\n... and {extra} more"
        raise AssertionError(
            (
                f"Max line length {MAX_LEN} violated in "
                f"{len(violations)} lines.\n"
            )
            + head
            + more
            + "\n\nSee also: reports/line72_frontend_report.md"
        )
