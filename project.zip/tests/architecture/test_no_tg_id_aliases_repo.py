from __future__ import annotations

from pathlib import Path


def _s(parts: list[str]) -> str:
    return "".join(parts)


SKIP_DIRS = {
    ".git",
    ".venv",
    "venv",
    "__pycache__",
    "node_modules",
    "dist",
    "build",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
}


def _is_text_file(path: Path) -> bool:
    # Keep this conservative.
    # We only scan typical source/docs/config files.
    return path.suffix.lower() in {
        ".py",
        ".ts",
        ".tsx",
        ".js",
        ".jsx",
        ".css",
        ".md",
        ".yml",
        ".yaml",
        ".json",
        ".txt",
        ".env",
        ".example",
        ".ini",
        ".toml",
        ".sql",
        ".sh",
    }


def test_repo_has_no_tg_id_alias_names() -> None:
    repo_root = Path(__file__).resolve().parents[2]

    banned = [
        _s(["t", "g", "I", "d"]),
        _s(["t", "g", "I", "D"]),
        _s(["t", "g", "i", "d"]),
        _s(["t", "elegram", "_", "id"]),
        _s(["t", "elegram", "I", "d"]),
        _s(["t", "elegram", "Id"]),
    ]

    offenders: list[str] = []
    for path in repo_root.rglob("*"):
        if not path.is_file():
            continue
        if any(part in SKIP_DIRS for part in path.parts):
            continue
        if not _is_text_file(path):
            continue

        text = path.read_text(encoding="utf-8", errors="replace")
        for needle in banned:
            if needle in text:
                offenders.append(f"{path}:{needle}")

    assert not offenders, (
        "Banned tg_id alias terms found in repo:\n"
        + "\n".join(offenders)
    )
