from __future__ import annotations

from pathlib import Path

# --- Log artifacts policy (SSOT) ---
# Логи и журналы ошибок фиксируются 1:1 (как есть) и могут содержать
# строки из CI/traceback. Поэтому они исключаются из большинства guard-тестов,
# чтобы не ломать канон проекта. Исключение: отдельный тест длины строки 72.
LOG_EXCLUDED_FILE_NAMES = {
    "EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md",
}
LOG_EXCLUDED_DIR_PARTS = {
    ".local_artifacts",
    "logs",
}
LOG_EXCLUDED_SUFFIXES = {
    ".log",
}

def _is_log_artifact(path: Path) -> bool:
    if path.name in LOG_EXCLUDED_FILE_NAMES:
        return True
    if set(path.parts) & LOG_EXCLUDED_DIR_PARTS:
        return True
    if path.suffix.lower() in LOG_EXCLUDED_SUFFIXES:
        return True
    if path.name.startswith("logs_"):
        return True
    return False


def _s(parts: list[str]) -> str:
    return "".join(parts)


SKIP_DIRS = {
    ".git",
    ".venv",
    "venv",
    "__pycache__",
    "node_modules",
    "dist",
    "build",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
}


def _is_text_file(path: Path) -> bool:
    # Keep this conservative.
    # We only scan typical source/docs/config files.
    return path.suffix.lower() in {
        ".py",
        ".ts",
        ".tsx",
        ".js",
        ".jsx",
        ".css",
        ".md",
        ".yml",
        ".yaml",
        ".json",
        ".txt",
        ".env",
        ".example",
        ".ini",
        ".toml",
        ".sql",
        ".sh",
    }


def test_repo_has_no_tg_id_alias_names() -> None:
    repo_root = Path(__file__).resolve().parents[2]

    banned = [
        _s(["t", "g", "I", "d"]),
        _s(["t", "g", "I", "D"]),
        _s(["t", "g", "i", "d"]),
        _s(["t", "elegram", "_", "id"]),
        _s(["t", "elegram", "I", "d"]),
        _s(["t", "elegram", "Id"]),
    ]

    offenders: list[str] = []
    for path in repo_root.rglob("*"):
        if not path.is_file():
            continue
        if _is_log_artifact(path):
            continue
        if any(part in SKIP_DIRS for part in path.parts):
            continue
        if not _is_text_file(path):
            continue

        text = path.read_text(encoding="utf-8", errors="replace")
        for needle in banned:
            if needle in text:
                offenders.append(f"{path}:{needle}")

    assert not offenders, (
        "Banned tg_id alias terms found in repo:\n"
        + "\n".join(offenders)
    )
