from __future__ import annotations

import re
from pathlib import Path

# --- Log artifacts policy (SSOT) ---
# Логи и журналы ошибок фиксируются 1:1 (как есть) и могут содержать
# строки из CI/traceback. Поэтому они исключаются из большинства guard-тестов,
# чтобы не ломать канон проекта. Исключение: отдельный тест длины строки 72.
LOG_EXCLUDED_FILE_NAMES = {
    "EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md",
}
LOG_EXCLUDED_DIR_PARTS = {
    ".local_artifacts",
    "logs",
}
LOG_EXCLUDED_SUFFIXES = {
    ".log",
}

def _is_log_artifact(path: Path) -> bool:
    if path.name in LOG_EXCLUDED_FILE_NAMES:
        return True
    if set(path.parts) & LOG_EXCLUDED_DIR_PARTS:
        return True
    if path.suffix.lower() in LOG_EXCLUDED_SUFFIXES:
        return True
    if path.name.startswith("logs_"):
        return True
    return False


ROOT = Path(__file__).resolve().parents[2]


_FORBIDDEN_PATTERNS = [
    re.compile(r"total_generated_kwh\s*-=", re.IGNORECASE),
    re.compile(
        r"total_generated_kwh\s*=\s*total_generated_kwh\s*-",
        re.IGNORECASE,
    ),
    re.compile(
        r"SET\s+total_generated_kwh\s*=\s*[^\n]*-",
        re.IGNORECASE,
    ),
]


def _is_text(path: Path) -> bool:
    return path.suffix in {".py", ".md", ".txt", ".yaml", ".yml"}


def test_no_total_generated_kwh_decrement_patterns() -> None:
    offenders: list[str] = []

    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        if _is_log_artifact(path):
            continue
        if not _is_text(path):
            continue
        rel = path.relative_to(ROOT)
        if str(rel).startswith(".git/"):
            continue
        if str(rel).startswith("frontend/node_modules/"):
            continue
        if str(rel).startswith(".venv/"):
            continue
        try:
            data = path.read_text(encoding="utf-8")
        except Exception:
            continue
        for pat in _FORBIDDEN_PATTERNS:
            if pat.search(data):
                offenders.append(f"{rel}: {pat.pattern}")
                break

    assert not offenders, "\n".join(offenders)
