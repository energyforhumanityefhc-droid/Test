from __future__ import annotations

from pathlib import Path


def test_panels_page_has_no_local_numeric_casts() -> None:
    """Panels must not locally cast/format SSOT numeric strings.

    Guardrail: prohibit patterns that typically lead to precision loss.
    """

    p = Path("frontend/src/pages/panels.tsx")
    src = p.read_text(encoding="utf-8")

    assert "toFixed(" not in src, "Panels page must not use toFixed()."
    assert "Number(" not in src, "Panels page must not use Number() casts."
