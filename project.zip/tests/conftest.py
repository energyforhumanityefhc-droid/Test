"""Test configuration.

We enforce no .pyc / __pycache__ generation during tests so that the
repository-artifact guard stays stable and honest.
"""

from __future__ import annotations

import os
import sys


os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
sys.dont_write_bytecode = True
