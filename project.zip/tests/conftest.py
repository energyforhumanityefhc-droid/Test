"""Pytest bootstrap for EFHC Bot (CANON).

Goal: make project root importable when CI runs `pytest` from `extracted/`.
This avoids fragile dependence on external PYTHONPATH.
"""

from __future__ import annotations

import sys
from pathlib import Path


def _ensure_project_root_on_syspath() -> None:
    # tests/ is inside project root (flat zip layout).
    project_root = Path(__file__).resolve().parents[1]
    if str(project_root) not in sys.path:
        sys.path.insert(0, str(project_root))


_ensure_project_root_on_syspath()
