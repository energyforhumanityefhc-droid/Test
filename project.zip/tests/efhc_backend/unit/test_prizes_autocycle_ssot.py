import pathlib


def test_lotteries_service_has_wallet_guard_and_soldout_autocycle():
    """Regression: SSOT for lotteries auto-cycle and wallet requirement.

    This test intentionally inspects source code to prevent
    "DTO drift" and contract regressions.
    accidental removal of critical invariants.
    """

    p = (
        pathlib.Path(__file__).resolve().parents[3]
        / "backend"
        / "app"
        / "services"
        / "lotteries_service.py"
    )
    text = p.read_text(encoding="utf-8")

    assert "def _require_wallet_for_nft_ticket_purchase" in text
    assert "def _auto_lotteries_if_sold_out" in text

    # Both must be called from svc_buy_tickets
    assert "_require_wallet_for_nft_ticket_purchase(" in text
    assert "_auto_lotteries_if_sold_out(" in text

