"""
Unit tests package marker for frontend-related tests.
"""
__all__: list[str] = []
