import os
import subprocess


def test_canon_guard_fails_on_ban_token(tmp_path):
    # Создаём временный файл в пределах репо и пишем туда бан-токен,
    # собранный из частей (в исходниках теста токен не присутствует).
    ban = "".join(["l", "o", "t", "t", "e", "r", "y"])

    docs_dir = os.path.join(os.getcwd(), "docs")
    os.makedirs(docs_dir, exist_ok = True)

    bad_path = os.path.join(docs_dir, "_tmp_bad_canon.md")
    try:
        with open(bad_path, "w", encoding = 'utf-8') as f:
            f.write(ban + "\n")

        p = subprocess.run(
            ["python", "ops/canon_guard.py"],
            capture_output=True,
            text=True,
        )
        assert p.returncode != 0
    finally:
        if os.path.exists(bad_path):
            os.remove(bad_path)

