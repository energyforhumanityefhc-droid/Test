from __future__ import annotations

import asyncio
import importlib
import json
import os
import tempfile
from decimal import Decimal
from datetime import datetime, timezone

import pytest


if os.getenv("EFHC_CI_FULL") == "1":
    try:
        import sqlalchemy  # noqa: F401
    except Exception as e:
        pytest.fail(f"full-ci missing dependency: {e}")
else:
    pytest.importorskip("sqlalchemy")

from sqlalchemy import event, text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker


async def _init_sqlite_schema(db_url: str) -> None:
    engine = create_async_engine(
        db_url,
        future=True,
        connect_args={"check_same_thread": False},
    )

    @event.listens_for(engine.sync_engine, "connect")
    def _sqlite_now(dbapi_conn, _rec) -> None:  # pragma: no cover
        try:
            dbapi_conn.create_function(
                "now",
                0,
                lambda: datetime.now(timezone.utc).isoformat(),
            )
        except Exception:
            pass

    async with engine.begin() as conn:
        await conn.execute(text("PRAGMA journal_mode=WAL"))
        await conn.execute(text("PRAGMA synchronous=NORMAL"))
        await conn.execute(text("PRAGMA busy_timeout=5000"))

        await conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS main.users (
                    tg_id INTEGER PRIMARY KEY,
                    username TEXT,
                    is_vip INTEGER NOT NULL DEFAULT 0,
                    is_active INTEGER NOT NULL DEFAULT 1,
                    main_balance NUMERIC NOT NULL DEFAULT 0,
                    bonus_balance NUMERIC NOT NULL DEFAULT 0,
                    total_generated_kwh NUMERIC NOT NULL DEFAULT 0,
                    exchanged_kwh_total NUMERIC NOT NULL DEFAULT 0,
                    available_kwh NUMERIC NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP),
                    updated_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
                )
                """
            )
        )
        await conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS main.efhc_transfers_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tg_id INTEGER NOT NULL,
                    amount NUMERIC NOT NULL,
                    direction TEXT NOT NULL,
                    balance_type TEXT NOT NULL,
                    reason TEXT NOT NULL,
                    idempotency_key TEXT NOT NULL UNIQUE,
                    created_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP),
                    extra_info TEXT
                )
                """
            )
        )
        await conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS main.withdraw_requests (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tg_id INTEGER NOT NULL,
                    amount NUMERIC NOT NULL,
                    status TEXT NOT NULL,
                    idempotency_key TEXT NOT NULL UNIQUE,
                    hold_done INTEGER NOT NULL DEFAULT 0,
                    refund_done INTEGER NOT NULL DEFAULT 0,
                    payout_ref TEXT,
                    created_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP),
                    updated_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
                )
                """
            )
        )
    await engine.dispose()


def _reload_services_for_sqlite() -> tuple[object, object]:
    # Локальный режим тестов: SQLite + схема main.
    os.environ["DB_SCHEMA_CORE"] = "main"
    os.environ["ADMIN_BANK_TELEGRAM_ID"] = "900100"  # тестовый банк
    from backend.app.core import config_core

    config_core.get_settings.cache_clear()

    import backend.app.services.transactions_service as ts
    import backend.app.services.withdraw_service as ws

    ts = importlib.reload(ts)
    ws = importlib.reload(ws)
    return ts, ws


@pytest.mark.asyncio
async def test_concurrency_double_exchange_all_no_double_credit() -> None:
    ts, _ws = _reload_services_for_sqlite()

    with tempfile.TemporaryDirectory() as td:
        db_url = f"sqlite+aiosqlite:///{td}/concurrency_1.db"
        await _init_sqlite_schema(db_url)

        engine = create_async_engine(
            db_url,
            future=True,
            connect_args={"check_same_thread": False},
        )

        @event.listens_for(engine.sync_engine, "connect")
        def _sqlite_now2(dbapi_conn, _rec) -> None:  # pragma: no cover
            try:
                dbapi_conn.create_function(
                    "now",
                    0,
                    lambda: datetime.now(timezone.utc).isoformat(),
                )
            except Exception:
                pass
        Session = sessionmaker(
            engine,
            class_=AsyncSession,
            expire_on_commit=False,
            autoflush=False,
        )

        bank_tg_id = int(ts.BANK_TG_ID)
        user_tg_id = 100001

        async with Session() as s:
            await s.execute(
                text(
                    """
                    INSERT INTO main.users (
                        tg_id, username, is_vip, is_active,
                        main_balance, bonus_balance,
                        total_generated_kwh, exchanged_kwh_total,
                        available_kwh, created_at, updated_at
                    ) VALUES (
                        :tg_id, :u, 0, 1,
                        :mb, :bb,
                        :tk, :ex,
                        :av, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
                    )
                    """
                ),
                {
                    "tg_id": user_tg_id,
                    "u": "user",
                    "mb": "0.00000000",
                    "bb": "0.00000000",
                    "tk": "100.00000000",
                    "ex": "0.00000000",
                    "av": "100.00000000",
                },
            )
            await s.execute(
                text(
                    """
                    INSERT INTO main.users (
                        tg_id, username, is_vip, is_active,
                        main_balance, bonus_balance,
                        total_generated_kwh, exchanged_kwh_total,
                        available_kwh, created_at, updated_at
                    ) VALUES (
                        :tg_id, :u, 0, 1,
                        :mb, :bb,
                        :tk, :ex,
                        :av, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
                    )
                    """
                ),
                {
                    "tg_id": bank_tg_id,
                    "u": "bank",
                    "mb": "1000.00000000",
                    "bb": "0.00000000",
                    "tk": "0.00000000",
                    "ex": "0.00000000",
                    "av": "0.00000000",
                },
            )
            await s.commit()

        async def _do_exchange(idk: str) -> object:
            async with Session() as s:
                return await ts.exchange_all_available_kwh_to_main(
                    s,
                    tg_id=user_tg_id,
                    idempotency_key=idk,
                    reason="test_exchange_all",
                )

        r1, r2 = await asyncio.gather(
            _do_exchange("k_ex_all_1"),
            _do_exchange("k_ex_all_2"),
        )

        # Одна из попыток должна быть success, вторая — rejected/no-op.
        assert bool(getattr(r1, "created_log_id", 0))
        assert bool(getattr(r2, "created_log_id", 0))

        async with Session() as s:
            row = (
                await s.execute(
                    text(
                        """
                        SELECT
                          COALESCE(exchanged_kwh_total, 0),
                          COALESCE(main_balance, 0),
                          COALESCE(available_kwh, 0)
                        FROM main.users
                        WHERE tg_id = :tg
                        """
                    ),
                    {"tg": user_tg_id},
                )
            ).fetchone()

            assert Decimal(str(row[0])) == Decimal("100.00000000")
            assert Decimal(str(row[1])) == Decimal("100.00000000")
            assert Decimal(str(row[2])) == Decimal("0.00000000")

            logs = (
                await s.execute(
                    text(
                        """
                        SELECT extra_info
                        FROM main.efhc_transfers_log
                        WHERE tg_id = :tg
                        ORDER BY id
                        """
                    ),
                    {"tg": user_tg_id},
                )
            ).fetchall()

        statuses = []
        for (raw,) in logs:
            if not raw:
                continue
            try:
                payload = json.loads(str(raw))
            except Exception:
                continue
            if payload.get("op_type") == "EXCHANGE_ALL":
                statuses.append(payload.get("status"))

        assert "success" in statuses
        assert "rejected" in statuses

        await engine.dispose()
