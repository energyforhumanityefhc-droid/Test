from __future__ import annotations

import asyncio
import importlib
import json
import os
from datetime import timezone
from decimal import Decimal

import pytest


if os.getenv("EFHC_CI_FULL") == "1":
    try:
        import sqlalchemy  # noqa: F401
    except Exception as e:
        pytest.fail(f"full-ci missing dependency: {e}")
else:
    pytest.importorskip("sqlalchemy")

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker


def _reload_services_for_postgres() -> tuple[object, object]:
    # Канон: Postgres-only. SQLite запрещён.
    db_url = os.getenv("DATABASE_URL", "")
    if not db_url:
        pytest.skip("DATABASE_URL is not set")
    if db_url.startswith("sqlite://"):
        pytest.fail("SQLite is forbidden by CANON")

    # В тестах используем схему из настроек по умолчанию.
    os.environ["ADMIN_BANK_TG_ID"] = "900100"  # тестовый банк
    from backend.app.core import config_core

    config_core.get_settings.cache_clear()

    import backend.app.services.transactions_service as ts
    import backend.app.services.withdraw_service as ws

    ts = importlib.reload(ts)
    ws = importlib.reload(ws)
    return ts, ws


async def _reset_tables(engine, schema: str) -> None:
    async with engine.begin() as conn:
        # Чистим только то, что использует этот тест.
        await conn.execute(
            text(
                f"TRUNCATE TABLE {schema}.withdraw_requests, "
                f"{schema}.efhc_transfers_log, {schema}.users "
                "RESTART IDENTITY CASCADE"
            )
        )


@pytest.mark.asyncio
async def test_concurrency_exchange_all_and_withdraw_consistent() -> None:
    ts, ws = _reload_services_for_postgres()
    db_url = os.environ["DATABASE_URL"]
    engine = create_async_engine(db_url, future=True)
    schema = getattr(ts, "SCHEMA", "efhc_core")
    await _reset_tables(engine, schema)

    Session = sessionmaker(
        engine,
        class_=AsyncSession,
        expire_on_commit=False,
        autoflush=False,
    )

    bank_tg_id = int(ts.BANK_TG_ID)
    user_tg_id = 100002

    async with Session() as s:
        await s.execute(
            text(
                f"""
                INSERT INTO {schema}.users (
                    tg_id, username, is_vip, is_active,
                    main_balance, bonus_balance,
                    total_generated_kwh, exchanged_kwh_total,
                    available_kwh, created_at, updated_at
                ) VALUES (
                    :tg_id, :u, 0, 1,
                    :mb, :bb,
                    :tk, :ex,
                    :av, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
                )
                """
            ),
            {
                "tg_id": user_tg_id,
                "u": "user",
                "mb": "10.00000000",
                "bb": "0.00000000",
                "tk": "50.00000000",
                "ex": "0.00000000",
                "av": "50.00000000",
            },
        )
        await s.execute(
            text(
                f"""
                INSERT INTO {schema}.users (
                    tg_id, username, is_vip, is_active,
                    main_balance, bonus_balance,
                    total_generated_kwh, exchanged_kwh_total,
                    available_kwh, created_at, updated_at
                ) VALUES (
                    :tg_id, :u, 0, 1,
                    :mb, :bb,
                    :tk, :ex,
                    :av, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
                )
                """
            ),
            {
                "tg_id": bank_tg_id,
                "u": "bank",
                "mb": "1000.00000000",
                "bb": "0.00000000",
                "tk": "0.00000000",
                "ex": "0.00000000",
                "av": "0.00000000",
            },
        )
        await s.commit()

    async def _do_exchange() -> object:
        async with Session() as s:
            return await ts.exchange_all_available_kwh_to_main(
                s,
                tg_id=user_tg_id,
                idempotency_key="k_ex_with_wd",
                reason="test_exchange_all",
            )

    async def _do_withdraw() -> object:
        async with Session() as s:
            return await ws.request_withdraw(
                s,
                tg_id=user_tg_id,
                amount=Decimal("10.00000000"),
                client_idk="k_wd_1",
            )

    out = await asyncio.gather(
        _do_exchange(),
        _do_withdraw(),
        return_exceptions=True,
    )
    assert len(out) == 2

    async with Session() as s:
        row = (
            await s.execute(
                text(
                    f"""
                    SELECT
                      COALESCE(exchanged_kwh_total, 0),
                      COALESCE(main_balance, 0),
                      COALESCE(available_kwh, 0)
                    FROM {schema}.users
                    WHERE tg_id = :tg
                    """
                ),
                {"tg": user_tg_id},
            )
        ).fetchone()

        ex_total = Decimal(str(row[0]))
        main_bal = Decimal(str(row[1]))
        avail = Decimal(str(row[2]))

        assert ex_total == Decimal("50.00000000")
        assert avail == Decimal("0.00000000")
        assert main_bal in {
            Decimal("50.00000000"),
            Decimal("60.00000000"),
        }
        assert main_bal >= Decimal("0")

        logs = (
            await s.execute(
                text(
                    f"""
                    SELECT extra_info
                    FROM {schema}.efhc_transfers_log
                    WHERE tg_id = :tg
                    ORDER BY id
                    """
                ),
                {"tg": user_tg_id},
            )
        ).fetchall()

    seen_exchange = False
    seen_withdraw = False
    for (raw,) in logs:
        if not raw:
            continue
        try:
            payload = json.loads(str(raw))
        except Exception:
            continue

        if payload.get("op_type") == "EXCHANGE_ALL":
            after = (payload.get("after") or {})
            assert "invariant_ok" in after
            seen_exchange = True

        if payload.get("op_type") == "WITHDRAW":
            before = (payload.get("before") or {})
            after = (payload.get("after") or {})
            assert "main_balance_before" in before
            assert "withdrawable_main_before" in before
            assert "amount" in before
            assert "min_amount" in before
            assert "main_balance_after" in after
            assert "withdrawable_main_after" in after
            assert "invariant_ok" in after
            seen_withdraw = True

    assert seen_exchange
    assert seen_withdraw

    await engine.dispose()
