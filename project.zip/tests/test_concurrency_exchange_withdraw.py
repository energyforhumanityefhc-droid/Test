from __future__ import annotations

import asyncio
import importlib
import json
import os
import tempfile
from datetime import datetime, timezone
from decimal import Decimal

import pytest


if os.getenv("EFHC_CI_FULL") == "1":
    try:
        import sqlalchemy  # noqa: F401
    except Exception as e:
        pytest.fail(f"full-ci missing dependency: {e}")
else:
    pytest.importorskip("sqlalchemy")

from sqlalchemy import event, text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker


def _reload_services_for_sqlite() -> tuple[object, object]:
    os.environ["DB_SCHEMA_CORE"] = "main"
    os.environ["ADMIN_BANK_TELEGRAM_ID"] = "900100"  # тестовый банк
    from backend.app.core import config_core

    config_core.get_settings.cache_clear()

    import backend.app.services.transactions_service as ts
    import backend.app.services.withdraw_service as ws

    ts = importlib.reload(ts)
    ws = importlib.reload(ws)
    return ts, ws


async def _init_schema(engine) -> None:
    async with engine.begin() as conn:
        await conn.execute(text("PRAGMA journal_mode=WAL"))
        await conn.execute(text("PRAGMA synchronous=NORMAL"))
        await conn.execute(text("PRAGMA busy_timeout=5000"))
        await conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS main.users (
                    tg_id INTEGER PRIMARY KEY,
                    username TEXT,
                    is_vip INTEGER NOT NULL DEFAULT 0,
                    is_active INTEGER NOT NULL DEFAULT 1,
                    main_balance NUMERIC NOT NULL DEFAULT 0,
                    bonus_balance NUMERIC NOT NULL DEFAULT 0,
                    total_generated_kwh NUMERIC NOT NULL DEFAULT 0,
                    exchanged_kwh_total NUMERIC NOT NULL DEFAULT 0,
                    available_kwh NUMERIC NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP),
                    updated_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
                )
                """
            )
        )
        await conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS main.efhc_transfers_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tg_id INTEGER NOT NULL,
                    amount NUMERIC NOT NULL,
                    direction TEXT NOT NULL,
                    balance_type TEXT NOT NULL,
                    reason TEXT NOT NULL,
                    idempotency_key TEXT NOT NULL UNIQUE,
                    created_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP),
                    extra_info TEXT
                )
                """
            )
        )
        await conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS main.withdraw_requests (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tg_id INTEGER NOT NULL,
                    amount NUMERIC NOT NULL,
                    status TEXT NOT NULL,
                    idempotency_key TEXT NOT NULL UNIQUE,
                    hold_done INTEGER NOT NULL DEFAULT 0,
                    refund_done INTEGER NOT NULL DEFAULT 0,
                    payout_ref TEXT,
                    created_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP),
                    updated_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
                )
                """
            )
        )


@pytest.mark.asyncio
async def test_concurrency_exchange_all_and_withdraw_consistent() -> None:
    ts, ws = _reload_services_for_sqlite()

    with tempfile.TemporaryDirectory() as td:
        db_url = f"sqlite+aiosqlite:///{td}/concurrency_2.db"
        engine = create_async_engine(
            db_url,
            future=True,
            connect_args={"check_same_thread": False},
        )

        @event.listens_for(engine.sync_engine, "connect")
        def _sqlite_now(dbapi_conn, _rec) -> None:  # pragma: no cover
            try:
                dbapi_conn.create_function(
                    "now",
                    0,
                    lambda: datetime.now(timezone.utc).isoformat(),
                )
            except Exception:
                pass

        await _init_schema(engine)

        Session = sessionmaker(
            engine,
            class_=AsyncSession,
            expire_on_commit=False,
            autoflush=False,
        )

        bank_tg_id = int(ts.BANK_TG_ID)
        user_tg_id = 100002

        async with Session() as s:
            await s.execute(
                text(
                    """
                    INSERT INTO main.users (
                        tg_id, username, is_vip, is_active,
                        main_balance, bonus_balance,
                        total_generated_kwh, exchanged_kwh_total,
                        available_kwh, created_at, updated_at
                    ) VALUES (
                        :tg_id, :u, 0, 1,
                        :mb, :bb,
                        :tk, :ex,
                        :av, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
                    )
                    """
                ),
                {
                    "tg_id": user_tg_id,
                    "u": "user",
                    "mb": "10.00000000",
                    "bb": "0.00000000",
                    "tk": "50.00000000",
                    "ex": "0.00000000",
                    "av": "50.00000000",
                },
            )
            await s.execute(
                text(
                    """
                    INSERT INTO main.users (
                        tg_id, username, is_vip, is_active,
                        main_balance, bonus_balance,
                        total_generated_kwh, exchanged_kwh_total,
                        available_kwh, created_at, updated_at
                    ) VALUES (
                        :tg_id, :u, 0, 1,
                        :mb, :bb,
                        :tk, :ex,
                        :av, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
                    )
                    """
                ),
                {
                    "tg_id": bank_tg_id,
                    "u": "bank",
                    "mb": "1000.00000000",
                    "bb": "0.00000000",
                    "tk": "0.00000000",
                    "ex": "0.00000000",
                    "av": "0.00000000",
                },
            )
            await s.commit()

        async def _do_exchange() -> object:
            async with Session() as s:
                return await ts.exchange_all_available_kwh_to_main(
                    s,
                    tg_id=user_tg_id,
                    idempotency_key="k_ex_with_wd",
                    reason="test_exchange_all",
                )

        async def _do_withdraw() -> object:
            async with Session() as s:
                return await ws.request_withdraw(
                    s,
                    tg_id=user_tg_id,
                    amount=Decimal("10.00000000"),
                    client_idk="k_wd_1",
                )

        out = await asyncio.gather(
            _do_exchange(),
            _do_withdraw(),
            return_exceptions=True,
        )
        assert len(out) == 2

        async with Session() as s:
            row = (
                await s.execute(
                    text(
                        """
                        SELECT
                          COALESCE(exchanged_kwh_total, 0),
                          COALESCE(main_balance, 0),
                          COALESCE(available_kwh, 0)
                        FROM main.users
                        WHERE tg_id = :tg
                        """
                    ),
                    {"tg": user_tg_id},
                )
            ).fetchone()

            ex_total = Decimal(str(row[0]))
            main_bal = Decimal(str(row[1]))
            avail = Decimal(str(row[2]))

            assert ex_total == Decimal("50.00000000")
            assert avail == Decimal("0.00000000")
            assert main_bal in {
                Decimal("50.00000000"),
                Decimal("60.00000000"),
            }

            assert main_bal >= Decimal("0")

            logs = (
                await s.execute(
                    text(
                        """
                        SELECT extra_info
                        FROM main.efhc_transfers_log
                        WHERE tg_id = :tg
                        ORDER BY id
                        """
                    ),
                    {"tg": user_tg_id},
                )
            ).fetchall()

        # Ожидаем, что обе операции записали корректный аудит.
        seen_exchange = False
        seen_withdraw = False
        for (raw,) in logs:
            if not raw:
                continue
            try:
                payload = json.loads(str(raw))
            except Exception:
                continue

            if payload.get("op_type") == "EXCHANGE_ALL":
                after = (payload.get("after") or {})
                assert "invariant_ok" in after
                seen_exchange = True

            if payload.get("op_type") == "WITHDRAW":
                before = (payload.get("before") or {})
                after = (payload.get("after") or {})
                assert "main_balance_before" in before
                assert "withdrawable_main_before" in before
                assert "amount" in before
                assert "min_amount" in before
                assert "main_balance_after" in after
                assert "withdrawable_main_after" in after
                assert "invariant_ok" in after
                seen_withdraw = True

        assert seen_exchange
        assert seen_withdraw

        await engine.dispose()
