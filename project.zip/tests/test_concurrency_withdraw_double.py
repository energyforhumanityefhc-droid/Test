from __future__ import annotations

import asyncio
import importlib
import json
import os
from decimal import Decimal

import pytest

if os.getenv("EFHC_CI_FULL") == "1":
    try:
        import sqlalchemy  # noqa: F401
    except Exception as e:
        pytest.fail(f"full-ci missing dependency: {e}")
else:
    pytest.importorskip("sqlalchemy")

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

from tests.conftest import get_async_db_url, get_postgres_schema_default, truncate_schema_all_tables


def _reload_services_for_postgres() -> object:
    # Канон: Postgres-only.
    db_url = os.getenv("DATABASE_URL", "")
    if not db_url:
        pytest.skip("DATABASE_URL is not set")
    if db_url.startswith("sqlite://"):
        pytest.fail("SQLite is forbidden by CANON")

    os.environ["ADMIN_BANK_TG_ID"] = "900100"  # тестовый банк
    from backend.app.core import config_core
    config_core.get_settings.cache_clear()

    import backend.app.services.transactions_service as ts  # noqa: F401
    import backend.app.services.withdraw_service as ws

    importlib.reload(ts)
    ws = importlib.reload(ws)
    return ws


@pytest.mark.asyncio
async def test_concurrency_double_withdraw_only_one_success() -> None:
    ws = _reload_services_for_postgres()

    db_url = get_async_db_url()
    engine = create_async_engine(db_url, future=True)

    schema = getattr(ws, "SCHEMA", None) or get_postgres_schema_default()
    await truncate_schema_all_tables(engine, schema)

    Session = sessionmaker(
        engine,
        class_=AsyncSession,
        expire_on_commit=False,
        autoflush=False,
    )

    user_tg_id = 100003
    bank_tg_id = 900100

    async with Session() as s:
        await s.execute(
            text(
                f"""
                INSERT INTO {schema}.users (
                    tg_id, username, is_vip, is_active,
                    main_balance, bonus_balance,
                    total_generated_kwh, exchanged_kwh_total,
                    available_kwh, created_at, updated_at
                ) VALUES (
                    :tg_id, :u, 0, 1,
                    :mb, :bb,
                    0, 0,
                    0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
                )
                """
            ),
            {
                "tg_id": user_tg_id,
                "u": "user",
                "mb": "15.00000000",
                "bb": "0.00000000",
            },
        )
        await s.execute(
            text(
                f"""
                INSERT INTO {schema}.users (
                    tg_id, username, is_vip, is_active,
                    main_balance, bonus_balance,
                    total_generated_kwh, exchanged_kwh_total,
                    available_kwh, created_at, updated_at
                ) VALUES (
                    :tg_id, :u, 0, 1,
                    :mb, :bb,
                    0, 0,
                    0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
                )
                """
            ),
            {
                "tg_id": bank_tg_id,
                "u": "bank",
                "mb": "0.00000000",
                "bb": "0.00000000",
            },
        )
        await s.commit()

    async def _do_withdraw(client_idk: str) -> object:
        async with Session() as s:
            return await ws.request_withdraw(
                s,
                tg_id=user_tg_id,
                amount=Decimal("10.00000000"),
                client_idk=client_idk,
            )

    out = await asyncio.gather(
        _do_withdraw("k_wd_a"),
        _do_withdraw("k_wd_b"),
        return_exceptions=True,
    )

    ok_count = sum(1 for x in out if not isinstance(x, Exception))
    err_count = sum(1 for x in out if isinstance(x, Exception))
    assert ok_count == 1
    assert err_count == 1

    async with Session() as s:
        row = (
            await s.execute(
                text(
                    f"""
                    SELECT COALESCE(main_balance, 0)
                    FROM {schema}.users
                    WHERE tg_id = :tg
                    """
                ),
                {"tg": user_tg_id},
            )
        ).fetchone()
        assert Decimal(str(row[0])) == Decimal("5.00000000")

        logs = (
            await s.execute(
                text(
                    f"""
                    SELECT extra_info
                    FROM {schema}.efhc_transfers_log
                    WHERE tg_id = :tg
                    ORDER BY id
                    """
                ),
                {"tg": user_tg_id},
            )
        ).fetchall()

    # Должны быть как минимум 2 записи: success и rejected.
    statuses = []
    for (raw,) in logs:
        if not raw:
            continue
        try:
            payload = json.loads(str(raw))
        except Exception:
            continue
        if payload.get("op_type") == "WITHDRAW":
            statuses.append(payload.get("status"))

    assert "success" in statuses
    assert "rejected" in statuses

    await engine.dispose()
