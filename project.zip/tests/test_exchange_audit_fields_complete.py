from __future__ import annotations

import ast
from pathlib import Path


REQ_BEFORE = {
    "total_generated_kwh",
    "exchanged_kwh_total",
    "available_kwh",
    "main_balance",
    "total_equivalent",
}

REQ_AFTER = {
    "total_generated_kwh",
    "exchanged_kwh_total",
    "available_kwh",
    "main_balance",
    "total_equivalent",
    "invariant_ok",
}


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def test_exchange_all_audit_fields_complete() -> None:
    path = _repo_root() / "backend" / "app" / "services" / (
        "transactions_service.py"
    )
    src = path.read_text(encoding="utf-8")
    tree = ast.parse(src)

    found = False

    class V(ast.NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> None:
            nonlocal found
            keys = []
            for k in node.keys:
                if isinstance(k, ast.Constant) and isinstance(k.value, str):
                    keys.append(k.value)

            if "exchange_all_audit" in keys and "op_type" in keys:
                # Find nested before/after dicts by walking values.
                before = None
                after = None
                for k, v in zip(node.keys, node.values):
                    if isinstance(k, ast.Constant) and k.value == "before":
                        before = v
                    if isinstance(k, ast.Constant) and k.value == "after":
                        after = v

                def keys_of(d: ast.AST) -> set[str]:
                    if not isinstance(d, ast.Dict):
                        return set()
                    out: set[str] = set()
                    for kk in d.keys:
                        if (
                            isinstance(kk, ast.Constant)
                            and isinstance(kk.value, str)
                        ):
                            out.add(kk.value)
                    return out

                bkeys = keys_of(before) if before else set()
                akeys = keys_of(after) if after else set()

                # Rejected path may omit after historically. We require
                # both, so the lock is enforceable.
                assert REQ_BEFORE <= bkeys
                assert REQ_AFTER <= akeys
                found = True

            self.generic_visit(node)

    V().visit(tree)
    assert found, "exchange_all_audit dict not found"
