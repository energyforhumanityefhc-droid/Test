# SPDX-License-Identifier: MIT
"""Alembic smoke: clean DB -> upgrade head.

Goal: prove that a fresh install (empty DB) can run
`alembic upgrade head` and that key tables exist.

We run on SQLite (offline/dev) to keep CI light.
"""

from __future__ import annotations

from pathlib import Path

import os

import pytest


def _import_or_skip(name: str):
    """Import helper for minimal vs full CI.

    In minimal environments the migration smoke may be skipped.
    In full CI (`EFHC_CI_FULL=1`) missing deps is an env error.
    """
    try:
        return __import__(name, fromlist=["*"])
    except Exception as exc:
        if os.getenv("EFHC_CI_FULL") == "1":
            pytest.fail(f"Missing dependency: {name}: {exc}")
        pytest.skip(
            f"Missing dependency: {name}",
            allow_module_level=True,
        )


sa = _import_or_skip("sqlalchemy")
command = _import_or_skip("alembic.command")
Config = _import_or_skip("alembic.config").Config


def _alembic_config(repo_root: Path, db_url: str) -> Config:
    cfg = Config()
    cfg.set_main_option(
        "script_location",
        str(repo_root / "backend" / "migrations"),
    )
    cfg.set_main_option("sqlalchemy.url", db_url)
    return cfg


def test_alembic_upgrade_head_sqlite(tmp_path: Path) -> None:
    repo_root = Path(__file__).resolve().parents[1]
    db_path = tmp_path / "alembic_smoke.db"
    db_url = f"sqlite:///{db_path.as_posix()}"

    cfg = _alembic_config(repo_root, db_url)
    command.upgrade(cfg, "head")

    engine = sa.create_engine(db_url)
    with engine.begin() as conn:
        for name in (
            "users",
            "panels",
            "efhc_transfers_log",
        ):
            conn.execute(sa.text(f"SELECT 1 FROM {name} LIMIT 1"))
