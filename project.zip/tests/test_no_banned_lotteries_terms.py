"""Canon test: lotteries SSOT.

This test ensures legacy labels for the lotteries module are absent
everywhere in the repo.
in backend code (including comments).

Implementation note:
- The forbidden words are assembled from fragments to avoid embedding
  them directly in the test file.
  literally in the repository text.
"""

from __future__ import annotations

import re
import tokenize
from io import StringIO
from pathlib import Path
from typing import Iterable


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _w(parts: list[str]) -> str:
    return "".join(parts)


_B0 = _w(["lo", "tte", "ry"])
_B1 = _w(["ra", "ff", "le"])
_B2 = _w(["dr", "aw"])
_B3 = _w(["dr", "aw", "s"])

_BANNED = (_B0, _B1, _B2, _B3)

_BANNED_RE = re.compile(
    r"\b(" + "|".join(_BANNED) + r")\b",
    re.IGNORECASE,
)


def iter_backend_py_files() -> Iterable[Path]:
    for path in PROJECT_ROOT.glob("backend/**/*.py"):
        if not path.is_file():
            continue
        if "migrations" in path.parts:
            continue
        if "__pycache__" in path.parts:
            continue
        yield path


def iter_name_tokens(text: str) -> Iterable[str]:
    reader = StringIO(text).readline
    for tok in tokenize.generate_tokens(reader):
        if tok.type == tokenize.NAME:
            yield tok.string


def test_no_legacy_lotteries_terms_in_backend() -> None:
    offenders: list[str] = []

    for path in iter_backend_py_files():
        text = path.read_text(encoding="utf-8")

        if _BANNED_RE.search(text):
            offenders.append(str(path.relative_to(PROJECT_ROOT)))
            continue

        for name in iter_name_tokens(text):
            if _BANNED_RE.fullmatch(name):
                offenders.append(str(path.relative_to(PROJECT_ROOT)))
                break

    assert not offenders, (
        "Legacy lotteries terms found: " + ", ".join(offenders[:20])
    )
