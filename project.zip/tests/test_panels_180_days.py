from __future__ import annotations

import importlib
import os
from datetime import datetime, timedelta

import pytest

if os.getenv("EFHC_CI_FULL") == "1":
    try:
        import sqlalchemy  # noqa: F401
    except Exception as e:
        pytest.fail(f"full-ci missing dependency: {e}")
else:
    pytest.importorskip("sqlalchemy")

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

from tests.conftest import get_async_db_url, get_postgres_schema_default, truncate_schema_all_tables


def _reload_panels_service_for_postgres():
    # Канон: Postgres-only.
    db_url = os.getenv("DATABASE_URL", "")
    if not db_url:
        pytest.skip("DATABASE_URL is not set")
    if db_url.startswith("sqlite://"):
        pytest.fail("SQLite is forbidden by CANON")

    os.environ["ADMIN_BANK_TG_ID"] = "900100"
    from backend.app.core import config_core
    config_core.get_settings.cache_clear()

    from backend.app.services import panels_service
    importlib.reload(panels_service)
    return panels_service


@pytest.mark.asyncio
async def test_panels_expires_exactly_180_days_utc() -> None:
    panels_service = _reload_panels_service_for_postgres()

    db_url = get_async_db_url()
    engine = create_async_engine(db_url, future=True)
    schema = getattr(panels_service, "SCHEMA", None) or get_postgres_schema_default()
    await truncate_schema_all_tables(engine, schema)

    Session = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

    tg_id = 3001

    async with Session() as db:
        await db.execute(
            text(
                f"""
                INSERT INTO {schema}.users (tg_id, main_balance, bonus_balance)
                VALUES (:tg, '200.00000000', '0.00000000')
                """
            ),
            {"tg": tg_id},
        )
        await db.commit()

    async with Session() as db:
        out = await panels_service.create_panel_for_user(
            db,
            tg_id=tg_id,
            idempotency_key="life-180",
        )
        await db.commit()

        r = await db.execute(
            text(
                f"""
                SELECT activated_at, expires_at
                FROM {schema}.panels
                WHERE id=:pid
                """
            ),
            {"pid": int(out["id"])},
        )
        row = r.fetchone()
        assert row is not None
        act = row[0]
        exp = row[1]
        assert act is not None and exp is not None

        # Both must be tz-aware UTC.
        assert act.tzinfo is not None
        assert exp.tzinfo is not None
        assert act.utcoffset() == timedelta(0)
        assert exp.utcoffset() == timedelta(0)
        assert exp - act == timedelta(days=180)

    await engine.dispose()
