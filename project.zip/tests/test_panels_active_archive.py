from __future__ import annotations

import importlib
import os
import tempfile
from datetime import datetime, timedelta, timezone

import pytest


if os.getenv("EFHC_CI_FULL") == "1":
    try:
        import sqlalchemy  # noqa: F401
    except Exception as e:
        pytest.fail(f"full-ci missing dependency: {e}")
else:
    pytest.importorskip("sqlalchemy")

from sqlalchemy import event, text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker


async def _init_sqlite_schema(db_url: str) -> None:
    engine = create_async_engine(
        db_url,
        future=True,
        connect_args={"check_same_thread": False},
    )

    @event.listens_for(engine.sync_engine, "connect")
    def _sqlite_now(dbapi_conn, _rec) -> None:  # pragma: no cover
        try:
            dbapi_conn.create_function(
                "now",
                0,
                lambda: datetime.now(timezone.utc).isoformat(),
            )
        except Exception:
            pass

    async with engine.begin() as conn:
        await conn.execute(text("PRAGMA foreign_keys = ON"))
        await conn.execute(text("PRAGMA journal_mode=WAL"))

        await conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS main.users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tg_id INTEGER NOT NULL UNIQUE,
                    is_vip INTEGER NOT NULL DEFAULT 0,
                    main_balance NUMERIC NOT NULL DEFAULT 0,
                    bonus_balance NUMERIC NOT NULL DEFAULT 0,
                    total_generated_kwh NUMERIC NOT NULL DEFAULT 0,
                    exchanged_kwh_total NUMERIC NOT NULL DEFAULT 0,
                    available_kwh NUMERIC NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP),
                    updated_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
                )
                """
            )
        )
        await conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS main.efhc_transfers_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tg_id INTEGER NOT NULL,
                    amount NUMERIC NOT NULL,
                    direction TEXT NOT NULL,
                    balance_type TEXT NOT NULL,
                    reason TEXT NOT NULL,
                    idempotency_key TEXT NOT NULL UNIQUE,
                    created_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP),
                    extra_info TEXT
                )
                """
            )
        )
        await conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS main.panels (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tg_id INTEGER NOT NULL,
                    public_id TEXT UNIQUE,
                    activated_at TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    last_generated_at TEXT NOT NULL,
                    base_gen_per_sec NUMERIC NOT NULL,
                    generated_kwh NUMERIC NOT NULL DEFAULT 0,
                    is_active INTEGER NOT NULL DEFAULT 1,
                    archived_at TEXT
                )
                """
            )
        )

    await engine.dispose()


def _reload_panels_service_for_sqlite():
    os.environ["DB_SCHEMA_CORE"] = "main"
    os.environ["ADMIN_BANK_TELEGRAM_ID"] = "900100"
    from backend.app.core import config_core

    importlib.reload(config_core)
    from backend.app.services import panels_service

    importlib.reload(panels_service)
    return panels_service


@pytest.mark.asyncio
async def test_panels_active_archive_classification_by_server_now() -> None:
    panels_service = _reload_panels_service_for_sqlite()

    fd, path = tempfile.mkstemp(prefix="efhc_panels_kind_", suffix=".db")
    os.close(fd)
    db_url = f"sqlite+aiosqlite:///{path}"

    fixed_now = datetime(2026, 3, 1, 0, 0, 0, tzinfo=timezone.utc)
    panels_service.utcnow = lambda: fixed_now  # type: ignore

    try:
        await _init_sqlite_schema(db_url)
        engine = create_async_engine(
            db_url,
            future=True,
            connect_args={"check_same_thread": False},
        )
        Session = sessionmaker(
            engine,
            class_=AsyncSession,
            expire_on_commit=False,
        )

        tg_id = 4001

        async with Session() as db:
            await db.execute(
                text(
                    """
                    INSERT INTO main.users (tg_id, main_balance, bonus_balance)
                    VALUES (:tg, 0.0, 0.0)
                    """
                ),
                {"tg": tg_id},
            )

            # panel 1: active (expires after server_now)
            act = fixed_now - timedelta(days=1)
            exp_active = fixed_now + timedelta(days=1)
            # panel 2: archive (expires at/before server_now)
            exp_arch = fixed_now

            await db.execute(
                text(
                    """
                    INSERT INTO main.panels (
                        tg_id,
                        public_id,
                        activated_at,
                        created_at,
                        expires_at,
                        last_generated_at,
                        base_gen_per_sec,
                        generated_kwh,
                        is_active,
                        archived_at
                    )
                    VALUES
                      (:tg, 'ID00000001', :act, :act, :exp1, :act, 0.00000692,
                       0, 1, NULL),
                      (:tg, 'ID00000002', :act, :act, :exp2, :act, 0.00000692,
                       0, 1, :arch)
                    """
                ),
                {
                    "tg": tg_id,
                    "act": act.isoformat(),
                    "exp1": exp_active.isoformat(),
                    "exp2": exp_arch.isoformat(),
                    "arch": fixed_now.isoformat(),
                },
            )
            await db.commit()

        async with Session() as db:
            active = await panels_service.list_user_panels(
                db,
                tg_id=tg_id,
                kind="active",
                limit=10,
                cursor=None,
            )
            archive = await panels_service.list_user_panels(
                db,
                tg_id=tg_id,
                kind="archive",
                limit=10,
                cursor=None,
            )

            assert len(active.items) == 1
            assert active.items[0]["public_id"] == "ID00000001"
            assert bool(active.items[0]["is_active"]) is True

            assert len(archive.items) == 1
            assert archive.items[0]["public_id"] == "ID00000002"
            assert bool(archive.items[0]["is_active"]) is False

        await engine.dispose()
    finally:
        try:
            os.unlink(path)
        except Exception:
            pass
