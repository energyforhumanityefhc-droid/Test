from __future__ import annotations

import importlib
import os
import tempfile
from datetime import datetime, timezone

import pytest

def _get_async_db_url() -> str:
    db_url = os.getenv("DATABASE_URL") or os.getenv("ASYNC_DATABASE_URL")
    if not db_url:
        pytest.skip("DATABASE_URL is required for Postgres-only CI", allow_module_level=True)
    # forbid sqlite in canon
    if db_url.startswith("sqlite"):
        pytest.fail("SQLite is forbidden in CI canon (Postgres-only)")
    # normalize to async psycopg driver for SQLAlchemy
    if db_url.startswith("postgresql://"):
        return "postgresql+psycopg://" + db_url[len("postgresql://"):]
    if db_url.startswith("postgres://"):
        return "postgresql+psycopg://" + db_url[len("postgres://"):]
    if db_url.startswith("postgresql+psycopg://"):
        return db_url
    return db_url


if os.getenv("EFHC_CI_FULL") == "1":
    try:
        import sqlalchemy  # noqa: F401
    except Exception as e:
        pytest.fail(f"full-ci missing dependency: {e}")
else:
    pytest.importorskip("sqlalchemy")

from sqlalchemy import event, text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker


async def _init_sqlite_schema(db_url: str) -> None:
    # SQLite is forbidden in Postgres-only CI canon
    pytest.fail("SQLite is forbidden in CI canon (Postgres-only)")
    return


def _reload_panels_service_for_sqlite():
    os.environ["DB_SCHEMA_CORE"] = "main"
    os.environ["ADMIN_BANK_TELEGRAM_ID"] = "900100"
    from backend.app.core import config_core

    importlib.reload(config_core)
    from backend.app.services import panels_service

    importlib.reload(panels_service)
    return panels_service


@pytest.mark.asyncio
async def test_panels_global_id_grows_across_users() -> None:
    panels_service = _reload_panels_service_for_sqlite()

    fd, path = tempfile.mkstemp(prefix="efhc_panels_gid_", suffix=".db")
    os.close(fd)
    db_url = _get_async_db_url()

    try:
        await _init_sqlite_schema(db_url)
        engine = create_async_engine(
            db_url,
            future=True,
            connect_args={"check_same_thread": False},
        )
        Session = sessionmaker(
            engine,
            class_=AsyncSession,
            expire_on_commit=False,
        )

        tg_a = 2001
        tg_b = 2002

        async with Session() as db:
            await db.execute(
                text(
                    """
                    INSERT INTO main.users (tg_id, main_balance, bonus_balance)
                    VALUES (:a, 200.0, 0.0), (:b, 200.0, 0.0)
                    """
                ),
                {"a": tg_a, "b": tg_b},
            )
            await db.commit()

        async with Session() as db:
            out_a = await panels_service.create_panel_for_user(
                db,
                tg_id=tg_a,
                idempotency_key="gid-a",
            )
            out_b = await panels_service.create_panel_for_user(
                db,
                tg_id=tg_b,
                idempotency_key="gid-b",
            )
            await db.commit()

            assert out_a["id"] != out_b["id"]
            assert out_a["public_id"].startswith("ID")
            assert out_b["public_id"].startswith("ID")
            assert out_b["id"] > out_a["id"]

        await engine.dispose()
    finally:
        try:
            os.unlink(path)
        except Exception:
            pass
