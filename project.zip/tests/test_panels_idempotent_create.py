from __future__ import annotations

import importlib
import os

import pytest

if os.getenv("EFHC_CI_FULL") == "1":
    try:
        import sqlalchemy  # noqa: F401
    except Exception as e:
        pytest.fail(f"full-ci missing dependency: {e}")
else:
    pytest.importorskip("sqlalchemy")

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

from tests.conftest import get_async_db_url, get_postgres_schema_default, truncate_schema_all_tables


def _reload_panels_service_for_postgres():
    os.environ["ADMIN_BANK_TG_ID"] = "900100"
    from backend.app.core import config_core
    config_core.get_settings.cache_clear()

    from backend.app.services import panels_service
    importlib.reload(panels_service)
    return panels_service


@pytest.mark.asyncio
async def test_panels_idempotency_create_same_key_same_panel() -> None:
    panels_service = _reload_panels_service_for_postgres()

    db_url = get_async_db_url()
    engine = create_async_engine(db_url, future=True)
    schema = getattr(panels_service, "SCHEMA", None) or get_postgres_schema_default()
    await truncate_schema_all_tables(engine, schema)

    Session = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

    tg_id = 6001

    async with Session() as db:
        await db.execute(
            text(
                f"""
                INSERT INTO {schema}.users (tg_id, main_balance, bonus_balance)
                VALUES (:tg, '200.00000000', '0.00000000')
                """
            ),
            {"tg": tg_id},
        )
        await db.commit()

    async with Session() as db:
        out1 = await panels_service.create_panel_for_user(
            db,
            tg_id=tg_id,
            idempotency_key="idem-panel",
        )
        out2 = await panels_service.create_panel_for_user(
            db,
            tg_id=tg_id,
            idempotency_key="idem-panel",
        )
        await db.commit()

        assert int(out1["id"]) == int(out2["id"])
        assert out1["public_id"] == out2["public_id"]

        r = await db.execute(
            text(f"SELECT COUNT(*) FROM {schema}.panels WHERE tg_id = :tg"),
            {"tg": tg_id},
        )
        cnt = int(r.scalar() or 0)
        assert cnt == 1

    await engine.dispose()
