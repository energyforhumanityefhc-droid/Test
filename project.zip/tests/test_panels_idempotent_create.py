from __future__ import annotations

import asyncio
import importlib
import os
import tempfile
from datetime import datetime, timezone

import pytest

def _get_async_db_url() -> str:
    db_url = os.getenv("DATABASE_URL") or os.getenv("ASYNC_DATABASE_URL")
    if not db_url:
        pytest.skip("DATABASE_URL is required for Postgres-only CI", allow_module_level=True)
    # forbid sqlite in canon
    if db_url.startswith("sqlite"):
        pytest.fail("SQLite is forbidden in CI canon (Postgres-only)")
    # normalize to async psycopg driver for SQLAlchemy
    if db_url.startswith("postgresql://"):
        return "postgresql+psycopg://" + db_url[len("postgresql://"):]
    if db_url.startswith("postgres://"):
        return "postgresql+psycopg://" + db_url[len("postgres://"):]
    if db_url.startswith("postgresql+psycopg://"):
        return db_url
    return db_url


if os.getenv("EFHC_CI_FULL") == "1":
    try:
        import sqlalchemy  # noqa: F401
    except Exception as e:
        pytest.fail(f"full-ci missing dependency: {e}")
else:
    pytest.importorskip("sqlalchemy")

from sqlalchemy import event, text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker


async def _init_sqlite_schema(db_url: str) -> None:
    # SQLite is forbidden in Postgres-only CI
    pytest.fail("SQLite is forbidden in CI canon (Postgres-only)")

engine = create_async_engine(
        db_url,
        future=True,
        connect_args={"check_same_thread": False},
    )

    @event.listens_for(engine.sync_engine, "connect")
    def _sqlite_now(dbapi_conn, _rec) -> None:  # pragma: no cover
        try:
            dbapi_conn.create_function(
                "now",
                0,
                lambda: datetime.now(timezone.utc).isoformat(),
            )
        except Exception:
            pass

    async with engine.begin() as conn:
        await conn.execute(text("PRAGMA foreign_keys = ON"))
        await conn.execute(text("PRAGMA journal_mode=WAL"))
        await conn.execute(text("PRAGMA synchronous=NORMAL"))
        await conn.execute(text("PRAGMA busy_timeout=5000"))

        await conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS main.users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tg_id INTEGER NOT NULL UNIQUE,
                    username TEXT,
                    is_vip INTEGER NOT NULL DEFAULT 0,
                    is_active INTEGER NOT NULL DEFAULT 1,
                    main_balance NUMERIC NOT NULL DEFAULT 0,
                    bonus_balance NUMERIC NOT NULL DEFAULT 0,
                    total_generated_kwh NUMERIC NOT NULL DEFAULT 0,
                    exchanged_kwh_total NUMERIC NOT NULL DEFAULT 0,
                    available_kwh NUMERIC NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP),
                    updated_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
                )
                """
            )
        )

        await conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS main.efhc_transfers_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tg_id INTEGER NOT NULL,
                    amount NUMERIC NOT NULL,
                    direction TEXT NOT NULL,
                    balance_type TEXT NOT NULL,
                    reason TEXT NOT NULL,
                    idempotency_key TEXT NOT NULL UNIQUE,
                    created_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP),
                    extra_info TEXT
                )
                """
            )
        )

        await conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS main.panels (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tg_id INTEGER NOT NULL,
                    public_id TEXT UNIQUE,
                    activated_at TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    last_generated_at TEXT NOT NULL,
                    base_gen_per_sec NUMERIC NOT NULL,
                    generated_kwh NUMERIC NOT NULL DEFAULT 0,
                    is_active INTEGER NOT NULL DEFAULT 1,
                    archived_at TEXT
                )
                """
            )
        )

    await engine.dispose()


def _reload_panels_service_for_sqlite():
    os.environ["DB_SCHEMA_CORE"] = "main"
    os.environ["ADMIN_BANK_TELEGRAM_ID"] = "900100"
    from backend.app.core import config_core

    importlib.reload(config_core)
    from backend.app.services import panels_service

    importlib.reload(panels_service)
    return panels_service


@pytest.mark.asyncio
async def test_panels_idempotency_create_same_key_same_panel() -> None:
    panels_service = _reload_panels_service_for_sqlite()

    fd, path = tempfile.mkstemp(prefix="efhc_panels_", suffix=".db")
    os.close(fd)
    db_url = _get_async_db_url()

    try:
        await _init_sqlite_schema(db_url)

        engine = create_async_engine(
            db_url,
            future=True,
            connect_args={"check_same_thread": False},
        )
        Session = sessionmaker(
            engine,
            class_=AsyncSession,
            expire_on_commit=False,
        )

        tg_id = 1001
        idem = "panels-test-idem-1"

        async with Session() as db:
            await db.execute(
                text(
                    """
                    INSERT INTO main.users (tg_id, main_balance, bonus_balance)
                    VALUES (:tg_id, 200.0, 0.0)
                    """
                ),
                {"tg_id": tg_id},
            )
            await db.commit()

        async with Session() as db:
            out1 = await panels_service.create_panel_for_user(
                db,
                tg_id=tg_id,
                idempotency_key=idem,
            )
            await db.commit()

        async with Session() as db:
            out2 = await panels_service.create_panel_for_user(
                db,
                tg_id=tg_id,
                idempotency_key=idem,
            )
            await db.commit()

            assert out1["id"] == out2["id"]
            assert out1["public_id"] == out2["public_id"]

            r = await db.execute(
                text("SELECT COUNT(*) FROM main.panels WHERE tg_id=:tg"),
                {"tg": tg_id},
            )
            assert int(r.scalar() or 0) == 1

            bal = await db.execute(
                text(
                    """
                    SELECT main_balance, bonus_balance
                    FROM main.users
                    WHERE tg_id=:tg
                    """
                ),
                {"tg": tg_id},
            )
            row = bal.fetchone()
            assert row is not None
            # списание должно произойти один раз на сумму 100
            assert float(row[0]) == pytest.approx(100.0)
            assert float(row[1]) == pytest.approx(0.0)

        await engine.dispose()
    finally:
        try:
            os.unlink(path)
        except Exception:
            pass
