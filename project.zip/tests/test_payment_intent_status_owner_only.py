from __future__ import annotations

import importlib
import os
import tempfile
from datetime import datetime, timezone

import pytest


pytest.importorskip("sqlalchemy")

from sqlalchemy import event, text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker


async def _init_sqlite_payment_intents(db_url: str) -> None:
    engine = create_async_engine(
        db_url,
        future=True,
        connect_args={"check_same_thread": False},
    )

    @event.listens_for(engine.sync_engine, "connect")
    def _sqlite_now(dbapi_conn, _rec) -> None:  # pragma: no cover
        try:
            dbapi_conn.create_function(
                "now",
                0,
                lambda: datetime.now(timezone.utc).isoformat(),
            )
        except Exception:
            pass

    async with engine.begin() as conn:
        await conn.execute(text("PRAGMA journal_mode=WAL"))
        await conn.execute(text("PRAGMA synchronous=NORMAL"))
        await conn.execute(text("PRAGMA busy_timeout=5000"))

        await conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS main.payment_intents (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tg_id INTEGER NOT NULL,
                    purpose TEXT NOT NULL,
                    package_id INTEGER,
                    asset TEXT NOT NULL,
                    amount_asset_d8 TEXT NOT NULL,
                    efhc_amount_d8 TEXT,
                    status TEXT NOT NULL,
                    idempotency_key TEXT NOT NULL,
                    payload TEXT NOT NULL UNIQUE,
                    to_address TEXT NOT NULL,
                    external_tx_hash TEXT,
                    created_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """
            )
        )

    await engine.dispose()


def _reload_for_sqlite() -> object:
    os.environ["DB_SCHEMA_CORE"] = "main"
    from backend.app.core import config_core

    config_core.get_settings.cache_clear()
    import backend.app.services.payment_intents_service as pis

    return importlib.reload(pis)


@pytest.mark.asyncio
async def test_get_intent_status_owner_only() -> None:
    with tempfile.TemporaryDirectory() as td:
        db_url = f"sqlite+aiosqlite:///{td}/pi.sqlite"
        await _init_sqlite_payment_intents(db_url)
        pis = _reload_for_sqlite()

        engine = create_async_engine(
            db_url,
            future=True,
            connect_args={"check_same_thread": False},
        )
        Session = sessionmaker(
            engine,
            expire_on_commit=False,
            class_=AsyncSession,
        )

        async with Session() as db:
            await db.execute(
                text(
                    """
                    INSERT INTO main.payment_intents (
                        id, tg_id, purpose, package_id, asset,
                        amount_asset_d8, efhc_amount_d8, status,
                        idempotency_key, payload, to_address,
                        external_tx_hash, created_at, expires_at, updated_at
                    ) VALUES (
                        9, 5001, 'deposit_efhc', 1, 'TON',
                        '1.00000000', '10.00000000', 'SENT',
                        'k1', 'EFHC:deposit_efhc:9:5001',
                        'EQ_RECEIVER', NULL, now(), now(), now()
                    )
                    """
                )
            )
            await db.commit()

            ok = await pis.get_intent_status_for_user(
                db,
                tg_id=5001,
                intent_id=9,
            )
            assert ok is not None
            assert ok["id"] == 9
            assert ok["tg_id"] == 5001

            other = await pis.get_intent_status_for_user(
                db,
                tg_id=5002,
                intent_id=9,
            )
            assert other is None

        await engine.dispose()
