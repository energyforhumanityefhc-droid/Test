import pathlib


ROOT = pathlib.Path(__file__).resolve().parents[1]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_migration_has_sale_packages_and_payment_intents():
    txt = _read("backend/migrations/versions/0001_init.py")
    assert "efhc_sale_packages" in txt
    assert "payment_intents" in txt
    assert "uq_payment_intents_idempo" in txt


def test_deposit_routes_has_packages_and_intent_tx():
    txt = _read("backend/app/routes/deposit_routes.py")
    assert "/packages" in txt
    assert "create_intent_deposit_by_package" in txt
    assert "tonconnect_tx" in txt


def test_shop_order_external_returns_tonconnect_tx():
    txt = _read("backend/app/routes/shop_routes.py")
    assert "/order-external" in txt
    assert "create_intent_shop_external" in txt
    assert "tonconnect_tx" in txt


def test_watcher_matches_payment_intent_payload():
    txt = _read("backend/app/services/watcher_service.py")
    assert "EFHC:<purpose>:<intent_id>:<tg_id>" in txt
    assert "_RE_INTENT" in txt
    assert "deposit_efhc_confirm" in txt
    # Финансовая чистота: депозит кредитует MAIN.
    assert "credit_user_from_bank" in txt
    assert "credit_user_bonus_from_bank" not in txt
