from __future__ import annotations

import importlib
import os
import tempfile
from datetime import datetime, timezone

import pytest

def _get_async_db_url() -> str:
    db_url = os.getenv("DATABASE_URL") or os.getenv("ASYNC_DATABASE_URL")
    if not db_url:
        pytest.skip("DATABASE_URL is required for Postgres-only CI", allow_module_level=True)
    # forbid sqlite in canon
    if db_url.startswith("sqlite"):
        pytest.fail("SQLite is forbidden in CI canon (Postgres-only)")
    # normalize to async psycopg driver for SQLAlchemy
    if db_url.startswith("postgresql://"):
        return "postgresql+psycopg://" + db_url[len("postgresql://"):]
    if db_url.startswith("postgres://"):
        return "postgresql+psycopg://" + db_url[len("postgres://"):]
    if db_url.startswith("postgresql+psycopg://"):
        return db_url
    return db_url


pytest.importorskip("sqlalchemy")

from sqlalchemy import event, text
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.ext.asyncio import create_async_engine
from sqlalchemy.orm import sessionmaker


async def _init_sqlite_schema(db_url: str) -> None:
    # SQLite is forbidden in Postgres-only CI
    pytest.fail("SQLite is forbidden in CI canon (Postgres-only)")

async def test_two_intents_two_confirms_credit_twice_main() -> None:
    with tempfile.TemporaryDirectory() as td:
        db_url = _get_async_db_url()
        await _init_sqlite_schema(db_url)

        ps, ws = _reload_services_for_sqlite()
        engine = create_async_engine(
            db_url,
            future=True,
            connect_args={"check_same_thread": False},
        )
        Session = sessionmaker(
            engine,
            expire_on_commit=False,
            class_=AsyncSession,
        )

        calls: list[tuple[int, str]] = []

        async def _credit_mock(
            _db,
            *,
            tg_id: int,
            amount_efhc,
            reason: str,
            idempotency_key: str,
        ) -> None:
            calls.append((tg_id, str(amount_efhc)))

        ws.credit_user_from_bank = _credit_mock

        async with Session() as db:
            tg_id = 99887766
            i1 = await ps.create_intent_deposit_by_package(
                db,
                tg_id=tg_id,
                idempotency_key="k1",
                package_id=1,
            )
            i2 = await ps.create_intent_deposit_by_package(
                db,
                tg_id=tg_id,
                idempotency_key="k2",
                package_id=1,
            )
            assert i1["intent_id"] != i2["intent_id"]
            assert i1["payload"] != i2["payload"]

            st1 = await ws._confirm_payment_intent(
                db,
                intent_id=int(i1["intent_id"]),
                tg_id=tg_id,
                purpose="deposit_efhc",
                payload=str(i1["payload"]),
                tx_hash="tx1",
                amount_asset=ps.d8("1.00000000"),
                asset="TON",
                to_address=str(i1["to_address"]),
            )
            st2 = await ws._confirm_payment_intent(
                db,
                intent_id=int(i2["intent_id"]),
                tg_id=tg_id,
                purpose="deposit_efhc",
                payload=str(i2["payload"]),
                tx_hash="tx2",
                amount_asset=ps.d8("1.00000000"),
                asset="TON",
                to_address=str(i2["to_address"]),
            )
            assert st1 == ws.STATUS_CREDITED
            assert st2 == ws.STATUS_CREDITED

        assert len(calls) == 2
        assert calls[0][0] == 99887766
        assert calls[1][0] == 99887766

        await engine.dispose()


@pytest.mark.asyncio
async def test_same_tx_hash_cannot_confirm_second_intent() -> None:
    with tempfile.TemporaryDirectory() as td:
        db_url = _get_async_db_url()
        await _init_sqlite_schema(db_url)

        ps, ws = _reload_services_for_sqlite()
        engine = create_async_engine(
            db_url,
            future=True,
            connect_args={"check_same_thread": False},
        )
        Session = sessionmaker(
            engine,
            expire_on_commit=False,
            class_=AsyncSession,
        )

        calls: list[str] = []

        async def _credit_mock(
            _db,
            *,
            tg_id: int,
            amount_efhc,
            reason: str,
            idempotency_key: str,
        ) -> None:
            calls.append(idempotency_key)

        ws.credit_user_from_bank = _credit_mock

        async with Session() as db:
            tg_id = 1
            i1 = await ps.create_intent_deposit_by_package(
                db,
                tg_id=tg_id,
                idempotency_key="k1",
                package_id=1,
            )
            i2 = await ps.create_intent_deposit_by_package(
                db,
                tg_id=tg_id,
                idempotency_key="k2",
                package_id=1,
            )

            st1 = await ws._confirm_payment_intent(
                db,
                intent_id=int(i1["intent_id"]),
                tg_id=tg_id,
                purpose="deposit_efhc",
                payload=str(i1["payload"]),
                tx_hash="tx_same",
                amount_asset=ps.d8("1.00000000"),
                asset="TON",
                to_address=str(i1["to_address"]),
            )
            st2 = await ws._confirm_payment_intent(
                db,
                intent_id=int(i2["intent_id"]),
                tg_id=tg_id,
                purpose="deposit_efhc",
                payload=str(i2["payload"]),
                tx_hash="tx_same",
                amount_asset=ps.d8("1.00000000"),
                asset="TON",
                to_address=str(i2["to_address"]),
            )

            assert st1 == ws.STATUS_CREDITED
            assert st2 == ws.STATUS_ERROR_SYS

        assert len(calls) == 1
        await engine.dispose()
