# -*- coding: utf-8 -*-

from __future__ import annotations

from decimal import Decimal

from backend.app.core.config_core import get_settings
from backend.app.core.system_locks import (
    assert_per_sec_canon,
    get_rate_base_d8,
    get_rate_vip_d8,
)


def test_settings_have_canon_defaults_and_lock_ok() -> None:
    s = get_settings()

    assert s.GEN_PER_SEC_BASE_KWH == "0.00000692"
    assert s.GEN_PER_SEC_VIP_KWH == "0.00000741"
    assert s.EFHC_KWH_RATE == "1.0"

    # Не должно падать на каноничных значениях.
    assert_per_sec_canon()

    # И ставки должны быть d8 (ROUND_DOWN), tz/time не участвует.
    assert isinstance(get_rate_base_d8(), Decimal)
    assert isinstance(get_rate_vip_d8(), Decimal)