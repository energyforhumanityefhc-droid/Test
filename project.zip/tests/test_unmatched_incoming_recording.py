from __future__ import annotations

import importlib
import os
from decimal import Decimal

import pytest

pytest.importorskip("sqlalchemy")

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

from tests.conftest import get_async_db_url, get_postgres_schema_default, truncate_schema_all_tables


def _reload_watcher_service_postgres() -> object:
    if (os.getenv("DATABASE_URL") or "").startswith("sqlite"):
        pytest.fail("SQLite is forbidden by CANON")
    from backend.app.core import config_core
    config_core.get_settings.cache_clear()

    import backend.app.services.watcher_service as ws
    return importlib.reload(ws)


@pytest.mark.asyncio
async def test_unmatched_incoming_is_idempotent_by_tx_hash() -> None:
    ws = _reload_watcher_service_postgres()

    db_url = get_async_db_url()
    engine = create_async_engine(db_url, future=True)
    schema = getattr(ws, "SCHEMA", None) or get_postgres_schema_default()
    await truncate_schema_all_tables(engine, schema)

    Session = sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)

    async with Session() as db:
        await ws._record_unmatched_incoming(
            db,
            tx_hash="tx_u1",
            asset="TON",
            amount_asset=Decimal("1.23000000"),
            from_address="EQ_FROM",
            to_address="EQ_TO",
            memo="BAD",
            utime=1,
            reason="unmatched_payload",
        )
        await ws._record_unmatched_incoming(
            db,
            tx_hash="tx_u1",
            asset="TON",
            amount_asset=Decimal("1.23000000"),
            from_address="EQ_FROM",
            to_address="EQ_TO",
            memo="BAD",
            utime=1,
            reason="unmatched_payload",
        )
        await db.commit()

        r = await db.execute(text(f"SELECT COUNT(1) FROM {schema}.unmatched_incoming"))
        assert int(r.scalar() or 0) == 1

    await engine.dispose()


@pytest.mark.asyncio
async def test_process_incoming_tx_unmatched_does_not_credit() -> None:
    ws = _reload_watcher_service_postgres()

    db_url = get_async_db_url()
    engine = create_async_engine(db_url, future=True)
    schema = getattr(ws, "SCHEMA", None) or get_postgres_schema_default()
    await truncate_schema_all_tables(engine, schema)

    Session = sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)

    # Не даём тесту зависеть от ton_inbox_logs и других таблиц.
    async def _no_log(*_a, **_k) -> None:
        return None

    async def _false(*_a, **_k) -> bool:
        return False

    async def _none(*_a, **_k):
        return None

    ws._ton_log_upsert = _no_log  # type: ignore[attr-defined]
    ws._ton_log_exists_final = _false  # type: ignore[attr-defined]
    ws._find_intent_by_payload_substring = _none  # type: ignore[attr-defined]

    async with Session() as db:
        # create user + bank to ensure no accidental credit
        await db.execute(
            text(
                f"""
                INSERT INTO {schema}.users (tg_id, username, is_active, is_vip, main_balance, bonus_balance, total_generated_kwh, exchanged_kwh_total, available_kwh)
                VALUES (7001, 'u', 1, 0, '0.00000000', '0.00000000', '0.00000000', '0.00000000', '0.00000000')
                """
            )
        )
        await db.commit()

        out = await ws.process_incoming_tx(
            db,
            asset="TON",
            tx_hash="tx_u2",
            amount_asset=Decimal("1.00000000"),
            from_address="EQ_FROM",
            to_address="EQ_TO",
            memo="SOME_BAD_PAYLOAD",
            utime=1,
        )
        await db.commit()

        assert out is None

        bal = (await db.execute(text(f"SELECT main_balance FROM {schema}.users WHERE tg_id=7001"))).scalar_one()
        assert str(bal) in ("0", "0.0", "0.00000000")

    await engine.dispose()
