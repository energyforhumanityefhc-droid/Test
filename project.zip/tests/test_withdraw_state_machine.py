# tests/test_withdraw_state_machine.py
#
# Мониторинг SSOT для withdraw_requests.
# Цель: защитить главный фикс (атомарные переходы из PENDING)
# без сетевых/DB зависимостей.

from __future__ import annotations

from pathlib import Path

import yaml


ROOT = Path(__file__).resolve().parents[1]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_withdraw_ssot_final_has_canceled() -> None:
    rules = yaml.safe_load(_read("ops/canon_rules.yaml"))
    guard = rules.get("guard", {}) if isinstance(rules, dict) else {}
    ssot = guard.get("withdraw_requests_ssot", {})
    final = ssot.get("final_statuses", [])
    assert "CANCELED" in list(final)


def test_admin_approve_atomic_where_pending() -> None:
    text = _read("backend/app/services/withdraw_service.py")
    assert "async def admin_approve_withdraw" in text
    assert "AND status = :pending" in text
    assert "WITHDRAW_REQ_PAID" in text


def test_admin_reject_atomic_where_pending() -> None:
    text = _read("backend/app/services/withdraw_service.py")
    assert "async def admin_reject_withdraw" in text
    assert "AND status = :pending" in text
    assert "WITHDRAW_REQ_REJECTED" in text


def test_admin_mark_paid_atomic_where_pending() -> None:
    text = _read("backend/app/services/withdraw_service.py")
    assert "async def admin_mark_paid" in text
    assert "AND status = :pending" in text
    assert "WITHDRAW_REQ_PAID" in text


def test_cancel_atomic_where_pending() -> None:
    text = _read("backend/app/services/withdraw_service.py")
    assert "async def cancel_withdraw" in text
    assert "AND status = :pending" in text
    assert "WITHDRAW_REQ_CANCELED" in text


def test_transition_forbidden_guard_present() -> None:
    text = _read("backend/app/services/withdraw_service.py")
    assert text.count("transition forbidden") >= 4


def test_final_statuses_include_canceled_in_admin_service() -> None:
    text = _read(
        "backend/app/services/admin/"
        "admin_withdrawals_service.py"
    )
    assert "CANCELED" in text
